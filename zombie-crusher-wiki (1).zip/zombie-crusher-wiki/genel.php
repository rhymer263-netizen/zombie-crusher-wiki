<?php
require __DIR__ . '/inc/baslat.php';

$slug = isset($_GET['s']) ? (string)$_GET['s'] : '';
$makaleler = tumu('SELECT id, slug, baslik, kategori, ikon, ozet, sira FROM genel ORDER BY sira, id');

// Kategorileri ilk görünme sırasına göre grupla
$kategoriler = [];
foreach ($makaleler as $m) $kategoriler[$m['kategori']][] = $m;

if ($slug === '') {
    sayfa_ust('Genel', 'genel', ['aciklama' => 'Zombie Crusher rehberi: kontroller, zorluklar, dalgalar, mağaza, yetenek ağacı, savunma ve daha fazlası.']);
    afis('05', 'Genel', 'Saha el kitabı: oyunun kuralları, sistemleri ve bilinmesi gereken her şey.', [['Genel']],
        '<span class="cip"><i style="--c:var(--sun)"></i>' . count($makaleler) . ' sayfa</span><span class="cip">' . count($kategoriler) . ' bölüm</span>');
    echo '<div class="sar">';
    if (!$makaleler) echo '<div class="bos-durum">' . ikon('kitap') . '<p>Henüz sayfa yok. Yönetim panelinden ekleyebilirsin.</p></div>';
    foreach ($kategoriler as $kategori => $liste) {
        echo '<div class="kategori-bas"><h2>' . e($kategori) . '</h2><span class="cizgi"></span><span class="cip">' . count($liste) . ' sayfa</span></div>';
        echo '<div class="makale-izgara">';
        foreach ($liste as $m) {
            echo '<a class="makale-karti" href="' . e(genel_url($m['slug'])) . '"><span class="simge">' . ikon($m['ikon'] ?: 'kitap') . '</span>'
               . '<span><b>' . e($m['baslik']) . '</b><span>' . e($m['ozet']) . '</span></span></a>';
        }
        echo '</div>';
    }
    echo '</div>';
    sayfa_alt();
    exit;
}

$m = tek('SELECT * FROM genel WHERE slug = ?', [$slug]);
if (!$m) bulunamadi('Bu sayfa', 'genel.php', 'Genel bilgilere dön');

$basliklar = [];
$govde = md($m['icerik'], $basliklar);
$kardesler = $kategoriler[$m['kategori']] ?? [];
$i = array_search($m['slug'], array_column($makaleler, 'slug'), true);
$onceki = $i > 0 ? $makaleler[$i - 1] : null;
$sonraki = $i !== false && $i < count($makaleler) - 1 ? $makaleler[$i + 1] : null;

sayfa_ust($m['baslik'], 'genel', ['aciklama' => $m['ozet']]);
afis(str_pad((string)($i + 1), 2, '0', STR_PAD_LEFT), $m['baslik'], $m['ozet'], [['Genel', 'genel.php'], [$m['kategori'], 'genel.php'], [$m['baslik']]], '', 'ince');
?>
<div class="sar">
  <div class="makale-duzen">
    <aside class="icindekiler" aria-label="İçindekiler">
      <?php if ($basliklar): ?>
        <b>Bu sayfada</b>
        <?php foreach ($basliklar as $b): ?><a href="#<?= e($b['id']) ?>" class="<?= $b['seviye'] > 2 ? 'alt-baslik' : '' ?>" data-toc><?= e($b['yazi']) ?></a><?php endforeach; ?>
      <?php endif; ?>
      <div class="digerleri">
        <b><?= e($m['kategori']) ?></b>
        <?php foreach ($kardesler as $k): ?><a href="<?= e(genel_url($k['slug'])) ?>"<?= $k['slug'] === $m['slug'] ? ' aria-current="page"' : '' ?>><?= e($k['baslik']) ?></a><?php endforeach; ?>
      </div>
    </aside>
    <article class="yazi">
      <?= $govde !== '' ? $govde : '<p>Bu sayfa henüz boş.</p>' ?>
      <p class="guncelleme-notu">Son güncelleme: <?= e(date('d.m.Y H:i', strtotime($m['guncelleme']))) ?></p>
    </article>
  </div>
  <nav class="sayfalama" aria-label="Diğer sayfalar" style="margin-top:0">
    <?php if ($onceki): ?><a href="<?= e(genel_url($onceki['slug'])) ?>"><span>← Önceki</span><b><?= e($onceki['baslik']) ?></b></a><?php endif; ?>
    <?php if ($sonraki): ?><a class="sonraki" href="<?= e(genel_url($sonraki['slug'])) ?>"><span>Sonraki →</span><b><?= e($sonraki['baslik']) ?></b></a><?php endif; ?>
  </nav>
</div>
<?php sayfa_alt();
