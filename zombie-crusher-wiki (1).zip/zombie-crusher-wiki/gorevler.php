<?php
require __DIR__ . '/inc/baslat.php';

$gorevler = tumu('SELECT * FROM gorevler ORDER BY sira, id');
$formul = formuller();
$varsayilanDalga = 12;

function gorev_hedefi(array $g, int $dalga): int
{
    $n = (int)$g['hedef_taban'];
    if ((int)$g['hedef_bolen'] > 0) $n += intdiv($dalga, (int)$g['hedef_bolen']);
    $n += (int)round((float)$g['hedef_carpan'] * $dalga);
    if ((int)$g['hedef_tavan'] > 0) $n = min($n, (int)$g['hedef_tavan']);
    return $n;
}

function gorev_formulu(array $g): string
{
    $p = [];
    if ((int)$g['hedef_taban'] > 0) $p[] = (string)(int)$g['hedef_taban'];
    if ((int)$g['hedef_bolen'] > 0) $p[] = 'dalga ÷ ' . (int)$g['hedef_bolen'];
    if ((float)$g['hedef_carpan'] > 0) $p[] = 'dalga × ' . sayi($g['hedef_carpan']);
    if (!$p) return '';
    $f = implode(' + ', $p);
    if ((int)$g['hedef_tavan'] > 0) $f = 'en fazla ' . (int)$g['hedef_tavan'] . ' · ' . $f;
    return 'Hedef = ' . $f;
}

$odul = function (int $dalga, bool $anahtar) use ($formul): int {
    $z = $formul['zorluklar'][0];
    foreach ($formul['zorluklar'] as $zz) if ($zz['varsayilan']) $z = $zz;
    $ham = ($formul['gorevTaban'] + $dalga * $formul['gorevDalga']) * $z['para'] * ($anahtar ? $formul['gorevAnahtarPara'] : 1);
    return (int)(round($ham / 5) * 5);
};

$egimler = ['-1.2deg', '.8deg', '-.5deg', '1.1deg', '-.9deg', '.4deg', '1deg', '-1.4deg'];

sayfa_ust('Görevler', 'gorev', ['aciklama' => 'Zombie Crusher dalga görevleri: hedefleri, ödülleri ve ipuçları.']);
afis('04', 'Görevler', 'Bazı dalgalarda geri sayım sırasında bir görev emri gelir. Dalga bitmeden tamamlarsan para ya da kasa anahtarı kazanırsın.', [['Görevler']],
    '<span class="cip"><i style="--c:var(--hazard)"></i>' . count($gorevler) . ' görev türü</span><span class="cip">~3 dalgada bir</span>');
?>
<script type="application/json" id="zc-formul"><?= json_encode($formul, JSON_UNESCAPED_UNICODE | JSON_HEX_TAG | JSON_HEX_AMP) ?></script>
<div class="sar" data-sayfa="gorevler">
  <div class="hesap" data-hesap style="margin-top:-36px;position:relative;z-index:5;box-shadow:0 18px 40px rgba(0,0,0,.35)">
    <div class="hesap-baslik"><?= ikon('gorev') ?>Görev hesaplayıcı</div>
    <div class="kaydirac">
      <input type="range" min="2" max="60" value="<?= $varsayilanDalga ?>" data-dalga aria-label="Dalga numarası">
      <output data-dalga-cikti><small>DALGA</small><?= $varsayilanDalga ?></output>
    </div>
    <label class="alan">Zorluk
      <select data-zorluk>
        <?php foreach ($formul['zorluklar'] as $i => $z): ?><option value="<?= $i ?>"<?= $z['varsayilan'] ? ' selected' : '' ?>><?= e($z['ad']) ?></option><?php endforeach; ?>
      </select>
    </label>
    <span class="cip" data-boss-uyari hidden><?= ikon('tac') ?>Boss dalgası: görev çıkmaz</span>
    <p class="hesap-not">Hedefler ve ödüller seçtiğin dalgaya göre hesaplanır. Ödül %<?= sayi(100 - $formul['gorevAnahtar'] * 100) ?> ihtimalle para, %<?= sayi($formul['gorevAnahtar'] * 100) ?> ihtimalle kasa anahtarı + paranın %<?= sayi($formul['gorevAnahtarPara'] * 100) ?>'ıdır.</p>
  </div>

  <section class="bolum" style="padding-top:20px">
    <div class="kural-listesi">
      <div class="kural"><?= ikon('saat') ?><b>Ne zaman?</b><p>2. dalgadan itibaren, boss dalgaları hariç. Bir dalgada görev çıkma şansı %40; bir önceki dalgada görev varsa %18.</p></div>
      <div class="kural"><?= ikon('ses') ?><b>Duyuru</b><p>Görev geri sayımda duyurulur; dalga boyunca sol üstte bir ilerleme çubuğu görünür.</p></div>
      <div class="kural"><?= ikon('para') ?><b>Ödül</b><p>Tamamladığın an ödül hesabına geçer: para ya da kasa anahtarı. Ödül dalgayla ve zorlukla büyür.</p></div>
      <div class="kural"><?= ikon('uyari') ?><b>Başarısızlık</b><p>"Anlık" görevler dalga bitince tamamlanmamışsa kaybedilir. "Dalga sonu" görevleri ise kural bozulduğu an biter.</p></div>
    </div>
  </section>

  <div class="gorev-izgara">
    <?php foreach ($gorevler as $i => $g):
        $hedef = gorev_hedefi($g, $varsayilanDalga);
        $metin = e($g['sablon']);
        $metin = str_replace('{N}', '<b data-hedef>' . $hedef . '</b>', $metin);
        $formulYazi = gorev_formulu($g);
        ?>
      <article class="emir" id="gorev-<?= e($g['slug']) ?>" style="--egim:<?= $egimler[$i % count($egimler)] ?>"
               data-taban="<?= (int)$g['hedef_taban'] ?>" data-bolen="<?= (int)$g['hedef_bolen'] ?>" data-carpan="<?= (float)$g['hedef_carpan'] ?>" data-tavan="<?= (int)$g['hedef_tavan'] ?>">
        <div class="emir-ust"><span>Görev emri · G-<?= str_pad((string)($i + 1), 2, '0', STR_PAD_LEFT) ?></span><span><?= $g['tur'] === 'dalga-sonu' ? 'Dalga sonu' : 'Anlık' ?></span></div>
        <div class="emir-bas">
          <span class="emir-ikon"><?= ikon($g['ikon'] ?: 'nisan') ?></span>
          <div><h3><?= e($g['kod_adi']) ?></h3><p class="oyunda">“<?= $metin ?>”</p></div>
        </div>
        <p><?= md_satir((string)$g['aciklama']) ?></p>
        <?php if ($g['kosul'] !== ''): ?><p class="kosul"><?= ikon('uyari') ?><?= e($g['kosul']) ?></p><?php endif; ?>
        <?php if ($formulYazi !== ''): ?><p class="kosul" style="color:#4d4436;font-weight:500"><?= ikon('dalga') ?><span class="mono" style="font-size:12.5px"><?= e($formulYazi) ?></span></p><?php endif; ?>
        <?php if (trim((string)$g['ipucu']) !== ''): ?><p class="ipucu-yazi">İpucu: <?= md_satir((string)$g['ipucu']) ?></p><?php endif; ?>
        <div class="emir-alt">
          <div class="odul"><span data-odul-para><?= para($odul($varsayilanDalga, false)) ?></span><span class="anahtar">ya da <?= ikon('anahtar') ?> + <b data-odul-anahtar><?= para($odul($varsayilanDalga, true)) ?></b></span></div>
          <span class="zorluk-noktalari" role="img" aria-label="Zorluk <?= (int)$g['zorluk'] ?> / 5"><?php for ($k = 1; $k <= 5; $k++): ?><i class="<?= $k <= (int)$g['zorluk'] ? 'dolu' : '' ?>"></i><?php endfor; ?></span>
        </div>
        <?php if ((int)$g['zorluk'] >= 4): ?><span class="gorev-damga" aria-hidden="true">ZORLU</span><?php endif; ?>
      </article>
    <?php endforeach; ?>
  </div>
</div>
<?php sayfa_alt();
