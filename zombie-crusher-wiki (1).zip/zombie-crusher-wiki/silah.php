<?php
require __DIR__ . '/inc/baslat.php';

$slug = (string)($_GET['s'] ?? '');
$s = tek('SELECT * FROM silahlar WHERE slug = ?', [$slug]);
if (!$s) bulunamadi('Bu silah', 'silahlar.php', 'Silahlara dön');

$tum = tumu('SELECT slug, ad FROM silahlar ORDER BY sira, id');
$sira = array_search($s['slug'], array_column($tum, 'slug'), true);
$onceki = $sira > 0 ? $tum[$sira - 1] : null;
$sonraki = $sira < count($tum) - 1 ? $tum[$sira + 1] : null;

$c = sinif_rengi($s['sinif']);
$dps = silah_dps($s);
$sdps = silah_surekli_dps($s);
$yakin = $s['sinif'] === 'Yakın Dövüş';
$formul = formuller();
$yaratiklar = tumu("SELECT slug, ad, can, kategori, ilk_dalga FROM yaratiklar WHERE kategori <> 'hayatta-kalan' ORDER BY sira, id");
$renkSkin = (int)deger("SELECT COUNT(*) FROM skinler WHERE nadirlik <> 'Varsayılan' AND sadece_bicak = 0");
$bicakSkin = (int)deger("SELECT COUNT(*) FROM skinler WHERE sadece_bicak = 1");

$sag = '<span class="cip"><i style="--c:' . e($c) . '"></i>' . e($s['sinif']) . '</span>'
     . ((int)$s['fiyat'] > 0 ? '<span class="cip">' . para($s['fiyat']) . '</span>' : '<span class="cip">' . e($s['kilit'] ?: 'Bedava') . '</span>');

sayfa_ust($s['ad'], 'silah', ['aciklama' => $s['kisa_aciklama']]);
afis(str_pad((string)($sira + 1), 2, '0', STR_PAD_LEFT), $s['ad'], $s['kisa_aciklama'], [['Silahlar', 'silahlar.php'], [$s['ad']]], $sag, 'ince');
?>
<script type="application/json" id="zc-formul"><?= json_encode($formul, JSON_UNESCAPED_UNICODE | JSON_HEX_TAG | JSON_HEX_AMP) ?></script>
<script type="application/json" id="zc-yaratiklar"><?= json_encode($yaratiklar, JSON_UNESCAPED_UNICODE | JSON_HEX_TAG | JSON_HEX_AMP) ?></script>
<div class="sar" data-sayfa="silah" data-hasar="<?= (float)$s['hasar'] ?>" data-sacma="<?= max(1, (int)$s['sacma']) ?>" data-atis="<?= (float)$s['atis_hizi'] ?>"
     data-sarjor="<?= (int)$s['sarjor'] ?>" data-doldurma="<?= (float)$s['doldurma'] ?>" data-alan="<?= (float)$s['alan_hasari'] ?>">
  <div class="silah-vitrin" style="--c:<?= e($c) ?>">
    <div class="olcek"><?= e($s['sinif']) ?><br>Hareket <b>x<?= sayi($s['hareket']) ?></b></div>
    <?= gorsel($s['gorsel'], $s['ad'], '', false) ?: '<div class="yok-gorsel">' . ikon('silah') . 'Görsel yok</div>' ?>
  </div>

  <div class="iki-kolon" style="padding-top:30px">
    <div>
      <dl class="istatistik">
        <div><dt>Hasar</dt><dd><?= (int)$s['sacma'] > 1 ? (int)$s['sacma'] . '×' . sayi($s['hasar']) : sayi($s['hasar']) ?><?= (float)$s['alan_hasari'] > 0 ? '<small>+' . sayi($s['alan_hasari']) . ' alan</small>' : '' ?></dd></div>
        <div><dt><?= $yakin ? 'Vuruş/sn' : 'Atış/sn' ?></dt><dd><?= sayi($s['atis_hizi']) ?></dd></div>
        <div><dt>Hasar/sn</dt><dd><?= sayi($dps, 0) ?></dd></div>
        <div><dt>Sürekli hasar/sn</dt><dd><?= sayi($sdps, 0) ?></dd></div>
        <div><dt><?= $s['slug'] === 'av-yayi' ? 'Sadak' : 'Şarjör' ?></dt><dd><?= (int)$s['sarjor'] > 0 ? (int)$s['sarjor'] : '—' ?></dd></div>
        <div><dt>Doldurma</dt><dd><?= (float)$s['doldurma'] > 0 ? sayi($s['doldurma']) . '<small>sn</small>' : '—' ?></dd></div>
        <div><dt>Delme</dt><dd><?= (int)$s['delme'] >= 99 ? 'Sınırsız' : (int)$s['delme'] . '<small>zombi</small>' ?></dd></div>
        <div><dt>Menzil</dt><dd><?= sayi($s['menzil']) ?><small>m</small></dd></div>
        <div><dt>Ateş modu</dt><dd style="font-size:18px"><?= $yakin ? 'Yakın dövüş' : ((int)$s['otomatik'] ? 'Otomatik' : 'Tek atış') ?></dd></div>
        <div><dt>Nişan</dt><dd style="font-size:18px"><?= (int)$s['durbun'] ? 'Dürbün' : ((int)$s['nisan'] ? 'Var' : 'Yok') ?></dd></div>
        <div><dt>Sekme</dt><dd><?= sayi($s['sekme']) ?><small>°</small></dd></div>
        <div><dt>Fiyat</dt><dd><?= (int)$s['fiyat'] > 0 ? para($s['fiyat']) : 'Bedava' ?></dd></div>
      </dl>
      <?php if ($s['kilit'] !== '' && (int)$s['fiyat'] > 0): ?>
        <div class="ipucu"><?= ikon('kilit') ?><b>Kilit</b><p><?= e($s['kilit']) ?>. Öncesinde mağazada kilitli görünür.</p></div>
      <?php endif; ?>
      <?php if (trim((string)$s['ozellik']) !== ''): ?>
        <section class="blok"><h2><?= ikon('nisan') ?>Özellik</h2><div class="yazi"><?= md($s['ozellik']) ?></div></section>
      <?php endif; ?>
      <?php if (trim((string)$s['ses']) !== ''): ?>
        <section class="blok"><h2><?= ikon('ses') ?>Ses</h2><div class="yazi"><?= md($s['ses']) ?></div></section>
      <?php endif; ?>
      <?php if (trim((string)$s['aciklama']) !== ''): ?>
        <section class="blok"><h2><?= ikon('kitap') ?>Saha notu</h2><div class="yazi"><?= md($s['aciklama']) ?></div></section>
      <?php endif; ?>
      <div class="ipucu" style="border-left-color:var(--destansi);background:linear-gradient(90deg,rgba(191,89,255,.09),transparent 70%)"><?= ikon('skin') ?><b style="color:var(--destansi)">Görünümler</b>
        <p>Bu <?= $yakin ? 'bıçak' : 'silah' ?> için kasadan <?= $renkSkin ?> renk görünümü<?= $yakin && $bicakSkin ? ' ve ' . $bicakSkin . ' özel bıçak modeli (Karambit)' : '' ?> çıkabilir. <a href="skinler.php">Bütün skinleri gör →</a></p></div>
    </div>

    <aside class="yan-kutu" data-hesap>
      <h3>Hesaplayıcı</h3>
      <div class="kaydirac" style="margin-bottom:10px">
        <input type="range" min="0" max="10" value="0" data-guc aria-label="Mermi Gücü seviyesi">
        <output data-guc-cikti><small>MERMİ GÜCÜ</small>0</output>
      </div>
      <div class="kaydirac" style="margin-bottom:12px">
        <input type="range" min="1" max="60" value="10" data-dalga aria-label="Dalga numarası">
        <output data-dalga-cikti><small>DALGA</small>10</output>
      </div>
      <label class="alan" style="margin-bottom:14px">Zorluk
        <select data-zorluk>
          <?php foreach ($formul['zorluklar'] as $i => $z): ?><option value="<?= $i ?>"<?= $z['varsayilan'] ? ' selected' : '' ?>><?= e($z['ad']) ?></option><?php endforeach; ?>
        </select>
      </label>
      <p class="hesap-not" style="margin-bottom:10px">Geliştirmeyle: <b data-guclu-hasar></b> hasar · <b data-guclu-dps></b> hasar/sn</p>
      <div class="tablo-kap">
        <table class="tablo" data-ttk>
          <thead><tr><th>Hedef</th><th class="s">Gövde</th><th class="s">Kafa</th><th class="s">Süre</th></tr></thead>
          <tbody></tbody>
        </table>
      </div>
      <p class="hesap-not">Atış sayısı seçili dalgadaki cana göre. Bosslar sadece kendi dalgalarında gelir; kafa vuruşu 2 kat hasar verir.</p>
    </aside>
  </div>

  <nav class="sayfalama" aria-label="Diğer silahlar">
    <?php if ($onceki): ?><a href="<?= e(silah_url($onceki['slug'])) ?>"><span>← Önceki</span><b><?= e($onceki['ad']) ?></b></a><?php endif; ?>
    <?php if ($sonraki): ?><a class="sonraki" href="<?= e(silah_url($sonraki['slug'])) ?>"><span>Sonraki →</span><b><?= e($sonraki['ad']) ?></b></a><?php endif; ?>
  </nav>
</div>
<?php sayfa_alt();
