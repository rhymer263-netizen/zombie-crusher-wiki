<?php
require __DIR__ . '/inc/baslat.php';

$slug = (string)($_GET['s'] ?? '');
$y = tek('SELECT * FROM yaratiklar WHERE slug = ?', [$slug]);
if (!$y) bulunamadi('Bu yaratık', 'yaratiklar.php', 'Yaratıklara dön');

$tum = tumu('SELECT slug, ad, sira, id FROM yaratiklar ORDER BY sira, id');
$sira = array_search($y['slug'], array_column($tum, 'slug'), true);
$onceki = $sira > 0 ? $tum[$sira - 1] : null;
$sonraki = $sira < count($tum) - 1 ? $tum[$sira + 1] : null;

$formul = formuller();
$sabit = $y['kategori'] === 'hayatta-kalan';
$silahlar = tumu('SELECT slug, ad, sinif, hasar, sacma, atis_hizi, sarjor, doldurma, alan_hasari FROM silahlar ORDER BY sira, id');
$etiketler = array_filter(array_map('trim', explode(',', $y['etiketler'])));
$no = ($y['kategori'] === 'boss' ? 'B' : ($sabit ? 'S' : 'Z')) . '-' . str_pad((string)($sira + 1), 2, '0', STR_PAD_LEFT);

$sag = '<span class="cip"><i style="--c:' . e($y['renk']) . '"></i>' . e(kategori_adi($y['kategori'])) . '</span>' . tehdit_gostergesi((int)$y['tehdit']);

sayfa_ust($y['ad'], 'yaratik', ['aciklama' => $y['kisa_aciklama']]);
afis($no, $y['ad'], $y['unvan'], [['Yaratıklar', 'yaratiklar.php'], [$y['ad']]], $sag, 'ince');
?>
<script type="application/json" id="zc-formul"><?= json_encode($formul, JSON_UNESCAPED_UNICODE | JSON_HEX_TAG | JSON_HEX_AMP) ?></script>
<script type="application/json" id="zc-silahlar"><?= json_encode($silahlar, JSON_UNESCAPED_UNICODE | JSON_HEX_TAG | JSON_HEX_AMP) ?></script>
<div class="sar" data-sayfa="yaratik" data-can="<?= (float)$y['can'] ?>" data-hiz="<?= (float)$y['hiz'] ?>" data-hasar="<?= (float)$y['hasar'] ?>" data-odul="<?= (float)$y['odul'] ?>" data-ilk="<?= (int)$y['ilk_dalga'] ?>"<?= $y['kategori'] === 'boss' ? ' data-boss="1"' : '' ?><?= $sabit ? ' data-sabit="1"' : '' ?>>
  <div class="ayrinti">
    <div class="vitrin-buyuk" style="--c:<?= e($y['renk']) ?>">
      <div class="olcek">Dosya <b><?= e($no) ?></b><br>Boyut <b>x<?= sayi($y['boyut']) ?></b></div>
      <?= gorsel($y['gorsel'], $y['ad'], '', false) ?: '<div class="yok-gorsel">' . ikon('yaratik') . 'Görsel yok</div>' ?>
    </div>

    <div>
      <?php if ($etiketler): ?><div class="kunye"><?php foreach ($etiketler as $et): ?><span class="cip"><?= e($et) ?></span><?php endforeach; ?></div><?php endif; ?>
      <p class="ozet-buyuk"><?= e($y['kisa_aciklama']) ?></p>

      <p class="tablo-etiket">Taban değerler · dalga ve zorluk çarpanları uygulanmadan</p>
      <dl class="istatistik">
        <div><dt>Can</dt><dd><?= sayi($y['can']) ?></dd></div>
        <div><dt>Hız</dt><dd><?= sayi($y['hiz']) ?><small>m/sn</small></dd></div>
        <div><dt><?= $sabit ? 'Bıçak hasarı' : 'Hasar' ?></dt><dd><?= sayi($y['hasar'], 1) ?></dd></div>
        <div><dt><?= $sabit ? 'Bıçak bekleme' : 'Saldırı aralığı' ?></dt><dd><?= sayi($y['saldiri_araligi']) ?><small>sn</small></dd></div>
        <?php if (!$sabit): ?>
        <div><dt>Ödül</dt><dd><?= para($y['odul']) ?></dd></div>
        <div><dt>Fark etme</dt><dd><?= sayi($y['fark_etme']) ?><small>m</small></dd></div>
        <div><dt>Saldırı menzili</dt><dd><?= (float)$y['saldiri_menzili'] > 0 ? sayi($y['saldiri_menzili']) . '<small>m</small>' : 'Yakın' ?></dd></div>
        <div><dt><?= $y['kategori'] === 'boss' ? 'Dalgalar' : 'İlk dalga' ?></dt><dd><?= $y['kategori'] === 'boss' ? e($y['dalgalar']) : (int)$y['ilk_dalga'] ?></dd></div>
        <?php else: ?>
        <div><dt>Bıçak menzili</dt><dd><?= sayi($y['saldiri_menzili']) ?><small>m</small></dd></div>
        <div><dt>Yeniden doğma</dt><dd>5<small>sn</small></dd></div>
        <div><dt>Silah slotu</dt><dd>2<small>+ bıçak</small></dd></div>
        <div><dt>Boyut</dt><dd>x<?= sayi($y['boyut']) ?></dd></div>
        <?php endif; ?>
      </dl>

      <?php if ($y['cikma_sansi'] !== '' && !$sabit): ?>
        <p class="hesap-not" style="margin:-12px 0 24px"><?= ikon('zar') ?> Çıkma şansı: <?= e($y['cikma_sansi']) ?></p>
      <?php endif; ?>

      <?php if (trim((string)$y['gorunus']) !== ''): ?>
        <section class="blok"><h2><?= ikon('goz') ?>Görünüş</h2><div class="yazi"><?= md($y['gorunus']) ?></div></section>
      <?php endif; ?>
      <?php if (trim((string)$y['davranis']) !== ''): ?>
        <section class="blok"><h2><?= ikon('yaratik') ?>Davranış</h2><div class="yazi"><?= md($y['davranis']) ?></div></section>
      <?php endif; ?>
      <?php if (trim((string)$y['ipucu']) !== ''): ?>
        <div class="ipucu"><?= ikon('nisan') ?><b><?= $y['kategori'] === 'boss' ? 'Oyun içi ipucu' : 'Taktik' ?></b><p><?= md_satir($y['ipucu']) ?></p></div>
      <?php endif; ?>
      <?php if (trim((string)$y['aciklama']) !== ''): ?>
        <div class="yazi blok"><?= md($y['aciklama']) ?></div>
      <?php endif; ?>

      <?php if (!$sabit): ?>
      <section class="blok" id="hesap">
        <h2><?= ikon('dalga') ?>Dalga hesaplayıcı</h2>
        <div class="hesap" data-hesap style="margin-bottom:14px">
          <div class="kaydirac" style="grid-column:1/-1">
            <input type="range" min="1" max="60" value="<?= max(1, (int)$y['ilk_dalga']) ?>" data-dalga aria-label="Dalga numarası">
            <output data-dalga-cikti><small>DALGA</small><?= max(1, (int)$y['ilk_dalga']) ?></output>
          </div>
          <label class="alan">Zorluk
            <select data-zorluk>
              <?php foreach ($formul['zorluklar'] as $i => $z): ?><option value="<?= $i ?>"<?= $z['varsayilan'] ? ' selected' : '' ?>><?= e($z['ad']) ?></option><?php endforeach; ?>
            </select>
          </label>
          <label class="anahtar-dugme"><input type="checkbox" data-gece> Gece</label>
        </div>
        <dl class="istatistik canli">
          <div><dt>Can</dt><dd data-deger="can"><?= sayi($y['can']) ?></dd></div>
          <div><dt>Hasar</dt><dd data-deger="hasar"><?= sayi($y['hasar'], 1) ?></dd></div>
          <div><dt>Hız</dt><dd><span data-deger="hiz"><?= sayi($y['hiz']) ?></span><small>m/sn</small></dd></div>
          <div><dt>Ödül</dt><dd data-deger="odul"><?= para($y['odul']) ?></dd></div>
        </dl>
        <div class="tablo-kap">
          <table class="tablo" data-kilometre>
            <thead><tr><th>Dalga</th><th class="s">Can</th><th class="s">Hasar</th><th class="s">Hız</th><th class="s">Ödül</th></tr></thead>
            <tbody></tbody>
          </table>
        </div>
      </section>

      <section class="blok" id="atis">
        <h2><?= ikon('nisan') ?>Kaç atışta ölür?</h2>
        <p class="hesap-not" style="margin-bottom:12px">Yukarıda seçtiğin dalgada, geliştirmesiz silahlarla. Pompalılarda bütün saçmaların isabet ettiği, RPG-7'de doğrudan isabet + alan hasarı varsayılır. Süreye doldurmalar dahildir.</p>
        <div class="tablo-kap">
          <table class="tablo" data-atis-tablo>
            <thead><tr><th>Silah</th><th class="s">Atış başı</th><th class="s">Gövde</th><th class="s">Kafa</th><th class="s">Süre</th></tr></thead>
            <tbody></tbody>
          </table>
        </div>
      </section>
      <?php endif; ?>

      <p class="guncelleme-notu">Son güncelleme: <?= e(date('d.m.Y H:i', strtotime($y['guncelleme']))) ?></p>
    </div>
  </div>

  <nav class="sayfalama" aria-label="Diğer yaratıklar">
    <?php if ($onceki): ?><a href="<?= e(yaratik_url($onceki['slug'])) ?>"><span>← Önceki dosya</span><b><?= e($onceki['ad']) ?></b></a><?php endif; ?>
    <?php if ($sonraki): ?><a class="sonraki" href="<?= e(yaratik_url($sonraki['slug'])) ?>"><span>Sonraki dosya →</span><b><?= e($sonraki['ad']) ?></b></a><?php endif; ?>
  </nav>
</div>
<?php sayfa_alt();
