<?php
/*
 * Zombie Crusher Wiki — veritabanı ayarları
 * -----------------------------------------
 * XAMPP'ın varsayılan MySQL/MariaDB kullanıcısı "root", şifresi boştur.
 * phpMyAdmin'de root kullanıcısına şifre koyduysan DB_PASS'e yaz.
 */

define('DB_HOST', 'localhost');
define('DB_PORT', 3306);
define('DB_NAME', 'zombie_crusher_wiki');
define('DB_USER', 'root');
define('DB_PASS', '');

// Yüklenen görseller için en büyük dosya boyutu (bayt). 4 MB.
define('YUKLEME_SINIRI', 4 * 1024 * 1024);
