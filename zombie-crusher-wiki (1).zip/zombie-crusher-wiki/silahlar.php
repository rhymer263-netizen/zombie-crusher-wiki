<?php
require __DIR__ . '/inc/baslat.php';

$silahlar = tumu('SELECT * FROM silahlar ORDER BY sira, id');
$bombalar = tumu('SELECT * FROM bombalar ORDER BY sira, id');

$siniflar = [];
$mx = ['vurus' => 0, 'atis' => 0, 'dps' => 0, 'sarjor' => 0];
foreach ($silahlar as &$s) {
    $s['vurus'] = (float)$s['hasar'] * max(1, (int)$s['sacma']);
    $s['dps'] = silah_dps($s);
    $s['sdps'] = silah_surekli_dps($s);
    $siniflar[$s['sinif']] = ($siniflar[$s['sinif']] ?? 0) + 1;
    $mx['vurus'] = max($mx['vurus'], $s['vurus']);
    $mx['atis'] = max($mx['atis'], (float)$s['atis_hizi']);
    $mx['dps'] = max($mx['dps'], $s['dps']);
    $mx['sarjor'] = max($mx['sarjor'], (int)$s['sarjor']);
}
unset($s);

function oran(float $v, float $m): string { return $m > 0 ? (string)round($v / $m, 3) : '0'; }

function fiyat_etiketi(array $s): string
{
    if ((int)$s['fiyat'] <= 0) return '<span class="fiyat-etiket bedava">' . e($s['kilit'] !== '' ? ($s['sinif'] === 'Yakın Dövüş' ? 'HEP YANINDA' : 'BAŞLANGIÇ') : 'BEDAVA') . '</span>';
    return '<span class="fiyat-etiket' . ($s['kilit'] !== '' ? ' kilitli' : '') . '"' . ($s['kilit'] !== '' ? ' title="' . e($s['kilit']) . '"' : '') . '>' . ($s['kilit'] !== '' ? ikon('kilit') . ' ' : '') . para($s['fiyat']) . '</span>';
}

$sag = '<span class="cip"><i style="--c:var(--ember)"></i>' . count($silahlar) . ' silah</span><span class="cip"><i style="--c:#59a63a"></i>' . count($bombalar) . ' bomba</span>';

sayfa_ust('Silahlar', 'silah', ['aciklama' => 'Zombie Crusher\'daki bütün silahlar, hasarları, saniye başı hasarları, şarjörleri ve fiyatları.']);
afis('02', 'Silahlar', 'Cephanelik envanteri: her silahın hasarı, atış hızı, saniye başı hasarı, şarjörü ve mağaza fiyatı. İki silah taşıyabilirsin; bıçak her zaman yanında.', [['Silahlar']], $sag);
?>
<div class="sar" data-sayfa="silahlar">
  <div class="arac" role="region" aria-label="Filtreler">
    <div class="secenekler" role="group" aria-label="Sınıf">
      <button class="secenek" type="button" data-filtre="hepsi" aria-pressed="true">Tümü <span class="say"><?= count($silahlar) ?></span></button>
      <?php foreach ($siniflar as $ad => $n): ?>
        <button class="secenek" type="button" data-filtre="<?= e(slugla($ad)) ?>" aria-pressed="false" style="--c:<?= e(sinif_rengi($ad)) ?>"><span class="nokta"></span><?= e($ad) ?> <span class="say"><?= $n ?></span></button>
      <?php endforeach; ?>
    </div>
    <span class="bosluk"></span>
    <label class="alan">Sırala
      <select data-sirala>
        <option value="sira">Arşiv sırası</option>
        <option value="dps">Saniye başı hasar</option>
        <option value="vurus">Atış başı hasar</option>
        <option value="atis">Atış hızı</option>
        <option value="sarjor">Şarjör</option>
        <option value="fiyat">Fiyat</option>
        <option value="ad">Ad (A–Z)</option>
      </select>
    </label>
    <div class="goruntu" role="group" aria-label="Görünüm">
      <button type="button" data-goruntu="kart" aria-pressed="true" title="Kartlar"><?= ikon('kart') ?><span class="gizli">Kartlar</span></button>
      <button type="button" data-goruntu="tablo" aria-pressed="false" title="Karşılaştırma tablosu"><?= ikon('liste') ?><span class="gizli">Tablo</span></button>
    </div>
  </div>

  <div class="cephane-izgara" data-liste data-gorunum="kart">
    <?php foreach ($silahlar as $s): $c = sinif_rengi($s['sinif']); ?>
      <a class="cephane" href="<?= e(silah_url($s['slug'])) ?>" style="--c:<?= e($c) ?>"
         data-kategori="<?= e(slugla($s['sinif'])) ?>" data-sira="<?= (int)$s['sira'] ?>" data-ad="<?= e(tr_kucuk($s['ad'])) ?>"
         data-dps="<?= round($s['dps'], 2) ?>" data-vurus="<?= $s['vurus'] ?>" data-atis="<?= (float)$s['atis_hizi'] ?>" data-sarjor="<?= (int)$s['sarjor'] ?>" data-fiyat="<?= (int)$s['fiyat'] ?>">
        <div class="cephane-ust"><span class="sinif-etiket"><?= e($s['sinif']) ?></span><?= fiyat_etiketi($s) ?></div>
        <div class="cephane-gorsel"><?= gorsel($s['gorsel'], $s['ad']) ?: ikon('silah') ?></div>
        <div style="display:flex;justify-content:space-between;align-items:flex-end;gap:10px">
          <h3><?= e($s['ad']) ?></h3>
          <span class="dps-rozet">HASAR/SN<b><?= sayi($s['dps'], 0) ?></b></span>
        </div>
        <p><?= e($s['kisa_aciklama']) ?></p>
        <div class="olcu">
          <span class="et">Hasar</span><span class="cubuk m-hasar"><i style="--d:<?= oran($s['vurus'], $mx['vurus']) ?>"></i></span><b><?= (int)$s['sacma'] > 1 ? (int)$s['sacma'] . '×' . sayi($s['hasar']) : sayi($s['hasar']) ?><?= (float)$s['alan_hasari'] > 0 ? '+' . sayi($s['alan_hasari']) : '' ?></b>
          <span class="et">Atış/sn</span><span class="cubuk m-atis"><i style="--d:<?= oran((float)$s['atis_hizi'], $mx['atis']) ?>"></i></span><b><?= sayi($s['atis_hizi']) ?></b>
          <span class="et">Şarjör</span><span class="cubuk m-sarjor"><i style="--d:<?= oran((int)$s['sarjor'], $mx['sarjor']) ?>"></i></span><b><?= (int)$s['sarjor'] > 0 ? (int)$s['sarjor'] : '—' ?></b>
        </div>
      </a>
    <?php endforeach; ?>
  </div>

  <div class="tablo-kap" data-tablo-gorunum hidden>
    <table class="tablo" data-siralanabilir>
      <thead>
        <tr>
          <th aria-sort="none"><button type="button" data-anahtar="ad">Silah</button></th>
          <th aria-sort="none"><button type="button" data-anahtar="sinif">Sınıf</button></th>
          <th class="s" aria-sort="none"><button type="button" data-anahtar="vurus" data-sayi>Hasar</button></th>
          <th class="s" aria-sort="none"><button type="button" data-anahtar="atis" data-sayi>Atış/sn</button></th>
          <th class="s" aria-sort="none"><button type="button" data-anahtar="dps" data-sayi>Hasar/sn</button></th>
          <th class="s" aria-sort="none"><button type="button" data-anahtar="sdps" data-sayi title="Doldurma süresi dahil">Sürekli</button></th>
          <th class="s" aria-sort="none"><button type="button" data-anahtar="sarjor" data-sayi>Şarjör</button></th>
          <th class="s" aria-sort="none"><button type="button" data-anahtar="doldurma" data-sayi>Doldurma</button></th>
          <th class="s" aria-sort="none"><button type="button" data-anahtar="delme" data-sayi>Delme</button></th>
          <th class="s" aria-sort="none"><button type="button" data-anahtar="menzil" data-sayi>Menzil</button></th>
          <th class="s" aria-sort="none"><button type="button" data-anahtar="fiyat" data-sayi>Fiyat</button></th>
        </tr>
      </thead>
      <tbody>
        <?php foreach ($silahlar as $s): ?>
          <tr data-kategori="<?= e(slugla($s['sinif'])) ?>" data-ad="<?= e(tr_kucuk($s['ad'])) ?>" data-sinif="<?= e(tr_kucuk($s['sinif'])) ?>" data-vurus="<?= $s['vurus'] ?>" data-atis="<?= (float)$s['atis_hizi'] ?>"
              data-dps="<?= round($s['dps'], 2) ?>" data-sdps="<?= round($s['sdps'], 2) ?>" data-sarjor="<?= (int)$s['sarjor'] ?>" data-doldurma="<?= (float)$s['doldurma'] ?>" data-delme="<?= (int)$s['delme'] ?>" data-menzil="<?= (float)$s['menzil'] ?>" data-fiyat="<?= (int)$s['fiyat'] ?>">
            <td><a class="kucuk-gorsel" href="<?= e(silah_url($s['slug'])) ?>"><?= gorsel($s['gorsel'], '') ?><?= e($s['ad']) ?></a></td>
            <td><span class="sinif-etiket" style="--c:<?= e(sinif_rengi($s['sinif'])) ?>"><?= e($s['sinif']) ?></span></td>
            <td class="s"><?= (int)$s['sacma'] > 1 ? (int)$s['sacma'] . '×' . sayi($s['hasar']) : sayi($s['hasar']) ?><?= (float)$s['alan_hasari'] > 0 ? ' +' . sayi($s['alan_hasari']) : '' ?></td>
            <td class="s"><?= sayi($s['atis_hizi']) ?></td>
            <td class="s"><b><?= sayi($s['dps'], 0) ?></b></td>
            <td class="s"><?= sayi($s['sdps'], 0) ?></td>
            <td class="s"><?= (int)$s['sarjor'] > 0 ? (int)$s['sarjor'] : '—' ?></td>
            <td class="s"><?= (float)$s['doldurma'] > 0 ? sayi($s['doldurma']) . ' sn' : '—' ?></td>
            <td class="s"><?= (int)$s['delme'] >= 99 ? 'Sınırsız' : (int)$s['delme'] ?></td>
            <td class="s"><?= sayi($s['menzil']) ?> m</td>
            <td class="s"><?= (int)$s['fiyat'] > 0 ? para($s['fiyat']) : 'Bedava' ?></td>
          </tr>
        <?php endforeach; ?>
      </tbody>
    </table>
  </div>
  <div class="bos-durum" data-bos hidden><?= ikon('ara') ?><p>Bu sınıfta silah yok.</p></div>
  <p class="hesap-not" style="margin-top:14px">Hasar/sn: bütün mermilerin (pompalıda bütün saçmaların) isabet ettiği anlık değer. "Sürekli" sütunu doldurma süresini de hesaba katar. Mağazadaki <b>Mermi Gücü</b> geliştirmesi bütün silahlara seviye başına +%12 hasar ekler. Fiyatlara mağazanın %25'lik fiyat çarpanı dahildir.</p>

  <section class="bolum" id="bombalar">
    <div class="bolum-bas">
      <div><span class="ust-yazi">Mağaza → Ekipman</span><h2>Bombalar</h2>
      <p>Her alımda 3 adet gelir. <b>G</b> ile seçili bombayı atar, <b>4</b> ile türünü değiştirirsin. Bomba hasarı Mermi Gücü, yetenekler ve dalga ile birlikte artar.</p></div>
    </div>
    <div class="bomba-izgara">
      <?php foreach ($bombalar as $b): ?>
        <article class="bomba" id="bomba-<?= e($b['slug']) ?>" style="--c:<?= e($b['renk']) ?>">
          <h3><?= e($b['ad']) ?></h3>
          <span class="fiyat"><?= para($b['fiyat']) ?> · <?= (int)$b['adet'] ?> adet</span>
          <p><?= e($b['etki']) ?></p>
          <div class="bomba-deger">
            <span>Hasar<b><?= sayi($b['hasar']) ?></b><?= e($b['hasar_notu']) ?></span>
            <?php if ((float)$b['alan'] > 0): ?><span>Alan<b><?= sayi($b['alan']) ?> m</b></span><?php endif; ?>
            <?php if ((float)$b['sure'] > 0): ?><span>Süre<b><?= sayi($b['sure']) ?> sn</b></span><?php endif; ?>
          </div>
        </article>
      <?php endforeach; ?>
    </div>
  </section>
</div>
<?php sayfa_alt();
