<?php
require __DIR__ . '/inc/baslat.php';

$say = [
    'yaratik' => (int)deger('SELECT COUNT(*) FROM yaratiklar'),
    'boss'    => (int)deger("SELECT COUNT(*) FROM yaratiklar WHERE kategori = 'boss'"),
    'silah'   => (int)deger('SELECT COUNT(*) FROM silahlar'),
    'bomba'   => (int)deger('SELECT COUNT(*) FROM bombalar'),
    'skin'    => (int)deger("SELECT COUNT(*) FROM skinler WHERE nadirlik <> 'Varsayılan'"),
    'gorev'   => (int)deger('SELECT COUNT(*) FROM gorevler'),
    'makale'  => (int)deger('SELECT COUNT(*) FROM genel'),
];

// Hero'daki siluetler ve bölüm kartlarının görselleri
$gorseller = [];
foreach (tumu('SELECT slug, gorsel FROM yaratiklar') as $r) $gorseller['y:' . $r['slug']] = $r['gorsel'];
foreach (tumu('SELECT slug, gorsel FROM silahlar') as $r) $gorseller['s:' . $r['slug']] = $r['gorsel'];
foreach (tumu('SELECT slug, gorsel FROM skinler') as $r) $gorseller['k:' . $r['slug']] = $r['gorsel'];
$g = function (string $k) use ($gorseller) { return $gorseller[$k] ?? ''; };

// Dalga hattı: yeni zombiler, bosslar, geceler (ilk 30 dalga)
$yeniler = [];
foreach (tumu("SELECT ad, ilk_dalga, kategori FROM yaratiklar WHERE kategori = 'zombi' AND ilk_dalga > 1") as $r) $yeniler[(int)$r['ilk_dalga']][] = $r['ad'];
$bosslar = [];
foreach (tumu("SELECT ad, ilk_dalga FROM yaratiklar WHERE kategori = 'boss' ORDER BY ilk_dalga") as $r) $bosslar[(int)$r['ilk_dalga']] = $r['ad'];
$kilitler = [];
foreach (tumu("SELECT ad, kilit FROM silahlar WHERE kilit LIKE '%dalga%'") as $r) {
    if (preg_match('/(\d+)\.?\s*dalga/u', $r['kilit'], $m)) $kilitler[(int)$m[1]][] = $r['ad'];
}

// Öne çıkanlar (her ziyarette farklı)
$tehdit = tek("SELECT * FROM yaratiklar WHERE kategori <> 'hayatta-kalan' ORDER BY RAND() LIMIT 1");
$silah = tek('SELECT * FROM silahlar ORDER BY RAND() LIMIT 1');
$nadir = tek("SELECT * FROM skinler WHERE nadirlik = 'Efsanevi' ORDER BY RAND() LIMIT 1");

// Son güncellenenler
$guncel = tumu("
    (SELECT 'Yaratık' AS tur, ad, CONCAT('yaratik.php?s=', slug) AS url, guncelleme FROM yaratiklar)
    UNION ALL (SELECT 'Silah', ad, CONCAT('silah.php?s=', slug), guncelleme FROM silahlar)
    UNION ALL (SELECT 'Skin', ad, CONCAT('skinler.php#skin-', slug), guncelleme FROM skinler)
    UNION ALL (SELECT 'Görev', kod_adi, CONCAT('gorevler.php#gorev-', slug), guncelleme FROM gorevler)
    UNION ALL (SELECT 'Genel', baslik, CONCAT('genel.php?s=', slug), guncelleme FROM genel)
    ORDER BY guncelleme DESC LIMIT 8");

$mesajlar = ['Zombiler geliyor: 3-2-1', 'KAFA VURUŞU!', 'DİKKAT: KASAP GELİYOR!', 'GECE ÇÖKTÜ — anahtar düşme şansı arttı', 'ÜS SALDIRI ALTINDA',
    'ALTIN DALGA! Zombiler 2 kat para bırakır', 'GÖLGE ARKANDA!', 'ÖFKE!', 'KÖPEK SÜRÜSÜ!', '+1 ANAHTAR', 'KASAP YENİLDİ', 'DALGA TAMAMLANDI'];
$renk = ['', 'kirmizi', 'kirmizi', 'sari', 'kirmizi', 'sari', 'kirmizi', 'kirmizi', '', 'sari', 'sari', ''];

sayfa_ust('', 'ana', ['govde' => 'ana-sayfa']);
?>
<section class="hero">
  <div class="gunes" aria-hidden="true"></div>
  <?= korlar(22, 11) ?>
  <div class="hero-zombiler" aria-hidden="true">
    <?php
    $siluet = [['y:zombi', 14, 150], ['y:tank', 25, 205], ['y:zombi-kopek', 37, 95], ['y:hucumcu', 79, 190], ['y:zombi', 88, 140], ['y:tukurucu', 58, 120]];
    foreach ($siluet as $s) {
        if (!gorsel_var($g($s[0]))) continue;
        echo '<img src="' . e($g($s[0])) . '" alt="" style="left:' . $s[1] . '%;height:' . $s[2] . 'px;transform:translateX(-50%)' . ($s[1] > 70 ? ' scaleX(-1)' : '') . '">';
    }
    ?>
  </div>
  <?= orman_svg(42, 'hero-orman', 300) ?>
  <div class="hud" aria-hidden="true">
    <div class="hud-kutu">Dalga <b>07</b></div>
    <div class="hud-kutu">Üs<div class="hud-bar"><i></i></div></div>
    <div class="hud-kutu">Can<div class="hud-bar can"><i></i></div></div>
  </div>
  <div class="hero-ic">
    <div class="hero-etiket"><?= e(ayar('alt_baslik', 'Saha Arşivi')) ?> · Resmî Wiki</div>
    <h1 lang="en">Zombie<span>Crusher</span></h1>
    <p><?= e(ayar('hero_metin')) ?></p>
    <div class="hero-dugmeler">
      <a class="dugme" href="yaratiklar.php"><?= ikon('yaratik') ?>Yaratıkları incele</a>
      <a class="dugme ikincil" href="silahlar.php"><?= ikon('silah') ?>Cephaneliğe git</a>
    </div>
  </div>
</section>

<div class="akis" aria-label="Oyun içi mesajlar">
  <div class="akis-ic" aria-hidden="true">
    <?php for ($k = 0; $k < 2; $k++) foreach ($mesajlar as $i => $m): ?><span class="<?= $renk[$i] ?>"><?= e($m) ?></span><?php endforeach; ?>
  </div>
</div>

<div class="sar">
  <section class="bolum">
    <div class="sayaclar">
      <div class="sayac"><b><?= $say['yaratik'] ?></b><span>Yaratık · <?= $say['boss'] ?> boss</span></div>
      <div class="sayac"><b><?= $say['silah'] ?></b><span>Silah · <?= $say['bomba'] ?> bomba</span></div>
      <div class="sayac"><b><?= $say['skin'] ?></b><span>Silah görünümü</span></div>
      <div class="sayac"><b><?= $say['gorev'] ?></b><span>Görev türü</span></div>
      <div class="sayac"><b><?= $say['makale'] ?></b><span>Rehber sayfası</span></div>
    </div>
  </section>

  <?php if (ayar('duyuru') !== ''): ?>
    <div class="not" style="margin-top:-24px"><p><strong>Saha raporu:</strong> <?= e(ayar('duyuru')) ?></p></div>
  <?php endif; ?>

  <section class="bolum">
    <div class="bolum-bas">
      <div><span class="ust-yazi">Arşiv bölümleri</span><h2>Ne arıyorsun?</h2></div>
    </div>
    <div class="dosyalar">
      <a class="bolum-karti" href="yaratiklar.php">
        <span class="no">01</span><h3>Yaratıklar</h3>
        <p>Bütün zombiler, altı boss ve sen: can, hız, hasar, ödül ve dalga dalga güçlenmeleri.</p>
        <span class="sayi"><?= $say['yaratik'] ?> kayıt <?= ikon('ok') ?></span>
        <?= gorsel($g('y:kasap'), '') ?>
      </a>
      <a class="bolum-karti genis" href="silahlar.php">
        <span class="no">02</span><h3>Silahlar</h3>
        <p>Glock'tan Lazer Tüfeği'ne bütün silahların hasarı, atış hızı, saniye başı hasarı ve fiyatı. Bombalar da burada.</p>
        <span class="sayi"><?= $say['silah'] ?> silah · <?= $say['bomba'] ?> bomba <?= ikon('ok') ?></span>
        <?= gorsel($g('s:ak-74'), '') ?>
      </a>
      <a class="bolum-karti genis" href="skinler.php">
        <span class="no">03</span><h3>Skinler</h3>
        <p>Kasadan çıkan yaygın, destansı ve efsanevi görünümler. Kasa açma simülatörünü dene.</p>
        <span class="sayi"><?= $say['skin'] ?> görünüm <?= ikon('ok') ?></span>
        <?= gorsel($g('k:24k'), '') ?>
      </a>
      <a class="bolum-karti" href="gorevler.php">
        <span class="no">04</span><h3>Görevler</h3>
        <p>Dalga sırasında çıkan mini görevler, hedefleri ve ödülleri.</p>
        <span class="sayi"><?= $say['gorev'] ?> görev <?= ikon('ok') ?></span>
        <span class="doku"><?= ikon('gorev') ?></span>
      </a>
      <a class="bolum-karti" href="genel.php">
        <span class="no">05</span><h3>Genel</h3>
        <p>Kontroller, zorluklar, gece ve özel dalgalar, mağaza, yetenek ağacı ve savunma.</p>
        <span class="sayi"><?= $say['makale'] ?> sayfa <?= ikon('ok') ?></span>
        <?= gorsel($g('y:asker'), '') ?>
      </a>
    </div>
  </section>

  <section class="bolum">
    <div class="bolum-bas">
      <div><span class="ust-yazi">İlk 30 dalga</span><h2>Dalga hattı</h2><p>Hangi dalgada ne olur: geceler, bosslar, yeni zombiler ve kilidi açılan silahlar. Üstüne gel ya da dokun.</p></div>
    </div>
    <div class="hat">
      <div class="hat-izgara">
        <?php for ($d = 1; $d <= 30; $d++):
            $boss = $bosslar[$d] ?? null;
            $gece = ($d % 5 === 3);
            $yeni = $yeniler[$d] ?? [];
            $kilit = $kilitler[$d] ?? [];
            $parcalar = [];
            if ($boss) $parcalar[] = 'Boss: ' . $boss;
            if ($gece) $parcalar[] = 'Gece dalgası';
            foreach ($yeni as $y) $parcalar[] = 'Yeni: ' . $y;
            foreach ($kilit as $k) $parcalar[] = 'Açılır: ' . $k;
            $ipucu = $parcalar ? implode(' · ', $parcalar) : 'Normal dalga';
            ?>
          <div class="hat-dalga<?= $boss ? ' boss' : '' ?><?= $gece ? ' gece' : '' ?>" tabindex="0" data-ipucu="<?= e($d . '. dalga|' . $ipucu) ?>">
            <?php if ($yeni || $kilit): ?><span class="hat-yeni"></span><?php endif; ?>
            <span class="isaret"><?php if ($boss) echo ikon('tac'); if ($gece) echo ikon('ay'); if ($kilit) echo ikon('kilit'); ?></span>
            <?= $d ?>
          </div>
        <?php endfor; ?>
      </div>
      <div class="hat-aciklama">
        <span><i style="background:rgba(216,64,47,.55)"></i>Boss dalgası (her 5 dalgada)</span>
        <span><i style="background:rgba(57,135,229,.45)"></i>Gece dalgası (3, 8, 13…)</span>
        <span><i style="background:var(--toxic);height:4px"></i>Yeni zombi ya da silah</span>
      </div>
    </div>
  </section>

  <section class="bolum">
    <div class="bolum-bas"><div><span class="ust-yazi">Rastgele seçildi</span><h2>Öne çıkanlar</h2></div></div>
    <div class="one-cikan">
      <?php if ($tehdit): ?>
      <a class="vitrin kose" href="<?= e(yaratik_url($tehdit['slug'])) ?>">
        <span class="ust-yazi">Günün tehdidi</span>
        <h3><?= e($tehdit['ad']) ?></h3>
        <span class="alt-yazi"><?= e($tehdit['unvan']) ?> · <?= sayi($tehdit['can']) ?> can</span>
        <div class="resim"><?= gorsel($tehdit['gorsel'], $tehdit['ad']) ?></div>
      </a>
      <?php endif; ?>
      <?php if ($silah): ?>
      <a class="vitrin kose" href="<?= e(silah_url($silah['slug'])) ?>">
        <span class="ust-yazi">Cephanelikten</span>
        <h3><?= e($silah['ad']) ?></h3>
        <span class="alt-yazi"><?= e($silah['sinif']) ?> · <?= sayi(silah_dps($silah), 0) ?> hasar/sn</span>
        <div class="resim"><?= gorsel($silah['gorsel'], $silah['ad']) ?></div>
      </a>
      <?php endif; ?>
      <?php if ($nadir): ?>
      <a class="vitrin kose" href="skinler.php#skin-<?= e($nadir['slug']) ?>">
        <span class="ust-yazi">Nadir bulgu · %<?= sayi(6) ?> şans</span>
        <h3><?= e($nadir['ad']) ?></h3>
        <span class="alt-yazi">Efsanevi · <?= e($nadir['efekt']) ?></span>
        <div class="resim"><?= gorsel($nadir['gorsel'], $nadir['ad']) ?></div>
      </a>
      <?php endif; ?>
    </div>
  </section>

  <section class="bolum">
    <div class="bolum-bas"><div><span class="ust-yazi">Arşiv kayıtları</span><h2>Son güncellenenler</h2></div></div>
    <div class="guncel-liste">
      <?php foreach ($guncel as $r): ?>
        <a href="<?= e($r['url']) ?>"><span class="tur"><?= e($r['tur']) ?></span><?= e($r['ad']) ?><time datetime="<?= e(date('c', strtotime($r['guncelleme']))) ?>"><?= e(date('d.m.Y', strtotime($r['guncelleme']))) ?></time></a>
      <?php endforeach; ?>
    </div>
  </section>
</div>
<?php sayfa_alt();
