<?php
require __DIR__ . '/inc/baslat.php';

$yaratiklar = tumu('SELECT * FROM yaratiklar ORDER BY sira, id');
$formul = formuller();

// Kategori sayıları ve kategori içi en yüksek değerler (çubuklar için)
$sayilar = ['zombi' => 0, 'boss' => 0, 'hayatta-kalan' => 0];
$enYuksek = [];
foreach ($yaratiklar as $y) {
    $k = $y['kategori'];
    $sayilar[$k] = ($sayilar[$k] ?? 0) + 1;
    foreach (['can', 'hiz', 'hasar', 'odul'] as $s) {
        $enYuksek[$k][$s] = max($enYuksek[$k][$s] ?? 0, (float)$y[$s]);
    }
}

/** Bir dalgadaki zombi türlerinin yüzdeleri (WaveManager.BeginWave ile aynı mantık). */
function dalga_paylari(array $zombiler, int $dalga): array
{
    $paylar = [];
    $toplam = 0.0;
    $kalanlar = [];
    foreach ($zombiler as $z) {
        if ($dalga < (int)$z['ilk_dalga']) { $paylar[$z['slug']] = 0.0; continue; }
        if ((float)$z['sans_taban'] <= 0) { $kalanlar[] = $z['slug']; continue; }
        $tavan = (float)$z['sans_tavan'] > 0 ? (float)$z['sans_tavan'] : 100.0;
        $p = min((float)$z['sans_taban'] + (float)$z['sans_artis'] * ($dalga - (int)$z['ilk_dalga']), $tavan);
        $paylar[$z['slug']] = $p;
        $toplam += $p;
    }
    if ($toplam > 100) {
        foreach ($paylar as $k => $p) $paylar[$k] = $p * 100 / $toplam;
        $toplam = 100;
    }
    foreach ($kalanlar as $k) $paylar[$k] = (100 - $toplam) / count($kalanlar);
    return $paylar;
}

$zombiler = array_values(array_filter($yaratiklar, function ($y) { return $y['kategori'] === 'zombi'; }));
$bossDalgalari = [];
foreach ($yaratiklar as $y) if ($y['kategori'] === 'boss') $bossDalgalari[(int)$y['ilk_dalga']] = $y['ad'];
ksort($bossDalgalari);
$gosterilecek = [1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 12, 15, 18, 20, 25, 30, 40, 50];

$sag = '<span class="cip"><i style="--c:var(--s1)"></i>' . $sayilar['zombi'] . ' zombi</span>'
     . '<span class="cip"><i style="--c:var(--blood)"></i>' . $sayilar['boss'] . ' boss</span>'
     . (!empty($sayilar['hayatta-kalan']) ? '<span class="cip"><i style="--c:var(--toxic)"></i>' . $sayilar['hayatta-kalan'] . ' hayatta kalan</span>' : '');

sayfa_ust('Yaratıklar', 'yaratik', ['aciklama' => 'Zombie Crusher\'daki bütün zombiler, bosslar ve istatistikleri.']);
afis('01', 'Yaratıklar', 'Ormandan çıkıp üssüne yürüyen her şey: can, hız, hasar, ödül ve dalga dalga nasıl güçlendikleri.', [['Yaratıklar']], $sag);
?>
<script type="application/json" id="zc-formul"><?= json_encode($formul, JSON_UNESCAPED_UNICODE | JSON_HEX_TAG | JSON_HEX_AMP) ?></script>
<div class="sar" data-sayfa="yaratiklar">
  <div class="arac" role="region" aria-label="Filtreler">
    <div class="secenekler" role="group" aria-label="Kategori">
      <button class="secenek" type="button" data-filtre="hepsi" aria-pressed="true">Tümü <span class="say"><?= count($yaratiklar) ?></span></button>
      <button class="secenek" type="button" data-filtre="zombi" aria-pressed="false">Zombiler <span class="say"><?= $sayilar['zombi'] ?></span></button>
      <button class="secenek" type="button" data-filtre="boss" aria-pressed="false">Bosslar <span class="say"><?= $sayilar['boss'] ?></span></button>
      <?php if (!empty($sayilar['hayatta-kalan'])): ?><button class="secenek" type="button" data-filtre="hayatta-kalan" aria-pressed="false">Hayatta kalan <span class="say"><?= $sayilar['hayatta-kalan'] ?></span></button><?php endif; ?>
    </div>
    <span class="bosluk"></span>
    <label class="alan">Sırala
      <select data-sirala>
        <option value="sira">Arşiv sırası</option>
        <option value="can">Can (çoktan aza)</option>
        <option value="hasar">Hasar (çoktan aza)</option>
        <option value="hiz">Hız (hızlıdan yavaşa)</option>
        <option value="odul">Ödül (çoktan aza)</option>
        <option value="ilk">İlk dalga</option>
        <option value="ad">Ad (A–Z)</option>
      </select>
    </label>
    <label class="alan"><span class="gizli">Ara</span><input type="search" data-ara placeholder="Ad ya da özellik…"></label>
  </div>

  <div class="hesap" data-hesap>
    <div class="hesap-baslik"><?= ikon('dalga') ?>Dalga hesaplayıcı</div>
    <div class="kaydirac">
      <input type="range" min="1" max="60" value="1" data-dalga aria-label="Dalga numarası">
      <output data-dalga-cikti><small>DALGA</small>1</output>
    </div>
    <label class="alan">Zorluk
      <select data-zorluk>
        <?php foreach ($formul['zorluklar'] as $i => $z): ?><option value="<?= $i ?>"<?= $z['varsayilan'] ? ' selected' : '' ?>><?= e($z['ad']) ?></option><?php endforeach; ?>
      </select>
    </label>
    <label class="anahtar-dugme"><input type="checkbox" data-gece> Gece</label>
    <p class="hesap-not" data-hesap-not>Kartlardaki değerler seçtiğin dalgada ve zorlukta hesaplanır: can her dalga +%<?= sayi($formul['dalgaCan'] * 100, 1) ?>, hasar ≈ +%<?= sayi($formul['dalgaCan'] / $formul['hasarBolen'] * 100, 1) ?>, hız +%<?= sayi($formul['dalgaHiz'] * 100, 1) ?> (en fazla x<?= sayi($formul['hizTavan']) ?>). Bosslar sadece kendi dalgalarında gelir.</p>
  </div>

  <div class="dosya-izgara" data-liste>
    <?php foreach ($yaratiklar as $i => $y):
        $k = $y['kategori'];
        $sabit = $k === 'hayatta-kalan';
        $mx = $enYuksek[$k];
        $no = ($k === 'boss' ? 'B' : ($sabit ? 'S' : 'Z')) . '-' . str_pad((string)($i + 1), 2, '0', STR_PAD_LEFT);
        $ara = tr_kucuk($y['ad'] . ' ' . $y['unvan'] . ' ' . $y['etiketler'] . ' ' . $y['kisa_aciklama']);
        ?>
      <a class="dosya" href="<?= e(yaratik_url($y['slug'])) ?>" style="--c:<?= e($y['renk']) ?>"
         data-kategori="<?= e($k) ?>" data-ara="<?= e($ara) ?>" data-sira="<?= (int)$y['sira'] ?>" data-ad="<?= e(tr_kucuk($y['ad'])) ?>"
         data-can="<?= (float)$y['can'] ?>" data-hiz="<?= (float)$y['hiz'] ?>" data-hasar="<?= (float)$y['hasar'] ?>" data-odul="<?= (float)$y['odul'] ?>"
         data-ilk="<?= (int)$y['ilk_dalga'] ?>"<?= $sabit ? ' data-sabit="1"' : '' ?>>
        <span class="kose" aria-hidden="true" style="position:absolute;inset:6px;pointer-events:none"></span>
        <div class="dosya-ust"><span>Dosya <?= e($no) ?></span><span class="kat"><?= e(tr_buyuk(kategori_adi($k))) ?></span></div>
        <?php if ($k === 'boss'): ?><span class="damga" aria-hidden="true">BOSS</span><?php elseif ($sabit): ?><span class="damga yesil" aria-hidden="true">DOST</span><?php endif; ?>
        <div class="dosya-gorsel"><?= gorsel($y['gorsel'], $y['ad']) ?: '<div class="yok-gorsel">' . ikon('yaratik') . '</div>' ?></div>
        <div class="dosya-govde">
          <div class="dosya-ad"><h3><?= e($y['ad']) ?></h3><?= tehdit_gostergesi((int)$y['tehdit']) ?></div>
          <?php if ($y['unvan'] !== ''): ?><div class="unvan"><?= e($y['unvan']) ?></div><?php endif; ?>
          <p class="ozet"><?= e($y['kisa_aciklama']) ?></p>
          <div class="olcu">
            <span class="et">Can</span><span class="cubuk m-can"><i style="--d:<?= $mx['can'] > 0 ? round($y['can'] / $mx['can'], 3) : 0 ?>"></i></span><b data-deger="can"><?= sayi($y['can']) ?></b>
            <span class="et">Hız</span><span class="cubuk m-hiz"><i style="--d:<?= $mx['hiz'] > 0 ? round($y['hiz'] / $mx['hiz'], 3) : 0 ?>"></i></span><b data-deger="hiz"><?= sayi($y['hiz']) ?></b>
            <span class="et"><?= $sabit ? 'Bıçak' : 'Hasar' ?></span><span class="cubuk m-hasar"><i style="--d:<?= $mx['hasar'] > 0 ? round($y['hasar'] / $mx['hasar'], 3) : 0 ?>"></i></span><b data-deger="hasar"><?= sayi($y['hasar'], 1) ?></b>
            <?php if (!$sabit): ?><span class="et">Ödül</span><span class="cubuk m-odul"><i style="--d:<?= $mx['odul'] > 0 ? round($y['odul'] / $mx['odul'], 3) : 0 ?>"></i></span><b data-deger="odul"><?= para($y['odul']) ?></b><?php endif; ?>
          </div>
          <div class="dosya-alt">
            <?php if ($k === 'boss'): ?><span class="cip"><?= ikon('tac') ?>Dalga <?= e($y['dalgalar']) ?></span>
            <?php elseif (!$sabit): ?><span class="cip">İlk dalga <?= (int)$y['ilk_dalga'] ?></span><?php endif; ?>
            <?php foreach (array_slice(array_filter(array_map('trim', explode(',', $y['etiketler']))), 0, 2) as $et): ?><span class="cip"><?= e($et) ?></span><?php endforeach; ?>
          </div>
        </div>
      </a>
    <?php endforeach; ?>
  </div>
  <div class="bos-durum" data-bos hidden><?= ikon('ara') ?><p>Bu filtreye uyan yaratık yok.</p></div>

  <section class="bolum" id="kompozisyon">
    <div class="bolum-bas">
      <div><span class="ust-yazi">Hangi dalgada ne gelir?</span><h2>Dalga kompozisyonu</h2>
      <p>Her satır bir dalgadaki normal zombilerin türlere göre dağılımı (Normal zorluk). Boss dalgalarında zombi sayısı %60 azalır ve dalganın başında boss gelir.</p></div>
    </div>
    <div class="kompozisyon">
      <div class="lejant">
        <?php foreach ($zombiler as $z): ?><span><i style="--c:<?= e($z['renk']) ?>"></i><?= e($z['ad']) ?></span><?php endforeach; ?>
      </div>
      <?php
      $tabloSatirlari = [];
      foreach ($gosterilecek as $d):
          $paylar = dalga_paylari($zombiler, $d);
          $adet = (int)round($formul['sayiTaban'] + $d * $formul['sayiDalga']);
          $boss = isset($bossDalgalari[$d]) ? $bossDalgalari[$d] : (($d % 5 === 0 && $bossDalgalari) ? array_values($bossDalgalari)[(int)($d / 5 - 1) % count($bossDalgalari)] : null);
          if ($d % 5 === 0) $adet = max(4, (int)round($adet * 0.4));
          $gece = $d % 5 === 3;
          $etiket = [];
          foreach ($zombiler as $z) if ($paylar[$z['slug']] > 0) $etiket[] = $z['ad'] . ' %' . sayi($paylar[$z['slug']], 0);
          $tabloSatirlari[] = [$d, $adet, $paylar, $boss, $gece];
          ?>
        <div class="komp-satir" role="img" aria-label="<?= e($d . '. dalga, ' . $adet . ' zombi: ' . implode(', ', $etiket)) ?>">
          <span class="no">D<?= $d ?></span>
          <span class="adet"><?= $adet ?></span>
          <span class="komp-cubuk" aria-hidden="true">
            <?php foreach ($zombiler as $z): $p = $paylar[$z['slug']]; if ($p <= 0) continue; ?>
              <span style="--c:<?= e($z['renk']) ?>;flex:<?= round($p, 2) ?>" data-ipucu="<?= e($z['ad'] . '|%' . sayi($p, 1) . ' · yaklaşık ' . sayi($adet * $p / 100, 1) . ' zombi') ?>"></span>
            <?php endforeach; ?>
          </span>
          <span class="notlar"><?php if ($boss): ?><em class="boss">Boss: <?= e($boss) ?></em><?php endif; ?><?php if ($gece): ?><em class="gece">Gece</em><?php endif; ?></span>
        </div>
      <?php endforeach; ?>
      <details class="komp-tablo">
        <summary>Tablo olarak göster</summary>
        <div class="tablo-kap">
          <table class="tablo">
            <thead><tr><th>Dalga</th><th class="s">Zombi</th><?php foreach ($zombiler as $z): ?><th class="s"><?= e($z['ad']) ?></th><?php endforeach; ?><th>Not</th></tr></thead>
            <tbody>
              <?php foreach ($tabloSatirlari as $r): ?>
                <tr><td><?= $r[0] ?></td><td class="s"><?= $r[1] ?></td>
                  <?php foreach ($zombiler as $z): ?><td class="s">%<?= sayi($r[2][$z['slug']], 1) ?></td><?php endforeach; ?>
                  <td><?= e(trim(($r[3] ? 'Boss: ' . $r[3] : '') . ($r[4] ? ' · Gece' : ''), ' ·')) ?></td></tr>
              <?php endforeach; ?>
            </tbody>
          </table>
        </div>
      </details>
    </div>
  </section>
</div>
<?php sayfa_alt();
