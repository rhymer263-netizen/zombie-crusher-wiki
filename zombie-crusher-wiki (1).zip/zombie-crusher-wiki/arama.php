<?php
require __DIR__ . '/inc/baslat.php';

$q = trim((string)($_GET['q'] ?? ''));
$q = mb_substr($q, 0, 80);

/** Eşleşen yerin etrafından kısa bir parça alır ve eşleşmeleri <mark> ile işaretler. */
function parca_vurgula(string $metin, string $q, int $cevre = 90): string
{
    $metin = duz_metin($metin);
    $k = tr_kucuk($metin);
    $kq = tr_kucuk($q);
    $konum = $kq === '' ? false : mb_strpos($k, $kq);
    if ($konum !== false && mb_strlen($metin) > $cevre * 2) {
        $bas = max(0, $konum - $cevre);
        $metin = ($bas > 0 ? '…' : '') . mb_substr($metin, $bas, $cevre * 2 + mb_strlen($q)) . '…';
    } elseif (mb_strlen($metin) > $cevre * 2) {
        $metin = mb_substr($metin, 0, $cevre * 2) . '…';
    }
    if ($kq === '') return e($metin);
    // Türkçe büyük/küçük harf duyarsız işaretleme
    $k = tr_kucuk($metin);
    $cikti = '';
    $i = 0;
    $uz = mb_strlen($kq);
    while (($p = mb_strpos($k, $kq, $i)) !== false) {
        $cikti .= e(mb_substr($metin, $i, $p - $i)) . '<mark>' . e(mb_substr($metin, $p, $uz)) . '</mark>';
        $i = $p + $uz;
    }
    return $cikti . e(mb_substr($metin, $i));
}

$gruplar = [];
$toplam = 0;
if (mb_strlen($q) >= 2) {
    $like = '%' . str_replace(['\\', '%', '_'], ['\\\\', '\\%', '\\_'], $q) . '%';
    $ara = function (string $sql, int $alan) use ($like) { return tumu($sql, array_fill(0, $alan, $like)); };

    $gruplar['Yaratıklar'] = array_map(function ($r) use ($q) {
        return ['url' => yaratik_url($r['slug']), 'baslik' => $r['ad'] . ($r['unvan'] ? ' — ' . $r['unvan'] : ''), 'gorsel' => $r['gorsel'], 'ikon' => 'yaratik',
                'metin' => $r['kisa_aciklama'] . ' ' . $r['davranis'] . ' ' . $r['aciklama']];
    }, $ara('SELECT * FROM yaratiklar WHERE ad LIKE ? OR unvan LIKE ? OR etiketler LIKE ? OR kisa_aciklama LIKE ? OR gorunus LIKE ? OR davranis LIKE ? OR ipucu LIKE ? OR aciklama LIKE ? ORDER BY sira', 8));

    $gruplar['Silahlar'] = array_map(function ($r) {
        return ['url' => silah_url($r['slug']), 'baslik' => $r['ad'] . ' — ' . $r['sinif'], 'gorsel' => $r['gorsel'], 'ikon' => 'silah',
                'metin' => $r['kisa_aciklama'] . ' ' . $r['ozellik'] . ' ' . $r['aciklama']];
    }, $ara('SELECT * FROM silahlar WHERE ad LIKE ? OR sinif LIKE ? OR kisa_aciklama LIKE ? OR ozellik LIKE ? OR ses LIKE ? OR aciklama LIKE ? ORDER BY sira', 6));

    $gruplar['Bombalar'] = array_map(function ($r) {
        return ['url' => 'silahlar.php#bomba-' . $r['slug'], 'baslik' => $r['ad'], 'gorsel' => '', 'ikon' => 'bomba', 'metin' => $r['etki']];
    }, $ara('SELECT * FROM bombalar WHERE ad LIKE ? OR etki LIKE ? ORDER BY sira', 2));

    $gruplar['Skinler'] = array_map(function ($r) {
        return ['url' => 'skinler.php#skin-' . $r['slug'], 'baslik' => $r['ad'] . ' — ' . $r['nadirlik'], 'gorsel' => $r['gorsel'], 'ikon' => 'skin', 'metin' => $r['aciklama']];
    }, $ara('SELECT * FROM skinler WHERE ad LIKE ? OR nadirlik LIKE ? OR desen LIKE ? OR efekt LIKE ? OR aciklama LIKE ? ORDER BY sira', 5));

    $gruplar['Görevler'] = array_map(function ($r) {
        return ['url' => 'gorevler.php#gorev-' . $r['slug'], 'baslik' => $r['kod_adi'], 'gorsel' => '', 'ikon' => 'gorev',
                'metin' => str_replace('{N}', 'N', $r['sablon']) . ' · ' . $r['aciklama']];
    }, $ara('SELECT * FROM gorevler WHERE kod_adi LIKE ? OR sablon LIKE ? OR aciklama LIKE ? OR ipucu LIKE ? OR kosul LIKE ? ORDER BY sira', 5));

    $gruplar['Genel'] = array_map(function ($r) {
        return ['url' => genel_url($r['slug']), 'baslik' => $r['baslik'], 'gorsel' => '', 'ikon' => $r['ikon'] ?: 'kitap', 'metin' => $r['ozet'] . ' ' . $r['icerik']];
    }, $ara('SELECT * FROM genel WHERE baslik LIKE ? OR ozet LIKE ? OR icerik LIKE ? OR kategori LIKE ? ORDER BY sira', 4));

    $gruplar = array_filter($gruplar);
    foreach ($gruplar as $g) $toplam += count($g);
}

sayfa_ust($q !== '' ? '“' . $q . '” araması' : 'Arama', '');
afis('??', 'Arama', $q === '' ? 'Yaratık, silah, skin, görev ya da rehber sayfası ara.' : ($toplam > 0 ? '“' . $q . '” için ' . $toplam . ' sonuç bulundu.' : '“' . $q . '” için sonuç yok.'), [['Arama']]);
?>
<div class="sar">
  <form class="arama-buyuk" action="arama.php" method="get" role="search">
    <input type="search" name="q" value="<?= e($q) ?>" placeholder="Örn. kafa vuruşu, gece, Kasap, minigun…" aria-label="Aranacak kelime" autofocus>
    <button class="dugme" type="submit"><?= ikon('ara') ?>Ara</button>
  </form>

  <?php if ($q !== '' && mb_strlen($q) < 2): ?>
    <div class="bos-durum"><?= ikon('ara') ?><p>En az 2 harf yaz.</p></div>
  <?php elseif ($q !== '' && !$gruplar): ?>
    <div class="bos-durum"><?= ikon('yaratik') ?><p>Hiçbir şey bulunamadı. Zombiler bu kaydı yemiş olabilir.<br>Başka bir kelime dene ya da <a href="genel.php">rehber sayfalarına</a> göz at.</p></div>
  <?php endif; ?>

  <?php foreach ($gruplar as $baslik => $liste): ?>
    <section class="sonuc-grubu">
      <h2><?= e($baslik) ?> <span class="say"><?= count($liste) ?></span></h2>
      <?php foreach ($liste as $r): ?>
        <a class="sonuc" href="<?= e($r['url']) ?>">
          <span class="resimcik"><?= gorsel($r['gorsel'], '') ?: ikon($r['ikon']) ?></span>
          <span><b><?= parca_vurgula($r['baslik'], $q, 200) ?></b><span><?= parca_vurgula($r['metin'], $q) ?></span></span>
        </a>
      <?php endforeach; ?>
    </section>
  <?php endforeach; ?>
</div>
<?php sayfa_alt();
