# Zombie Crusher Wiki

**Zombie Crusher** oyununun resmî wikisi. PHP + MySQL (MariaDB) ile yazıldı, **XAMPP** üzerinde çalışır.
Bütün değerler (zombi canları, silah hasarları, skin şansları, görev formülleri…) oyunun kaynak kodundan alındı;
yaratık, silah ve skin görselleri de oyunun kendi model kodundan çizildi.

## Bölümler

| Sayfa | İçerik |
|---|---|
| **Ana sayfa** (`index.php`) | Gün batımı + çam ormanı afişi, oyun içi mesaj şeridi, sayaçlar, ilk 30 dalganın hattı, öne çıkanlar |
| **Yaratıklar** (`yaratiklar.php`, `yaratik.php`) | 6 zombi, 6 boss ve oyuncu: can, hız, hasar, ödül. Dalga + zorluk + gece hesaplayıcısı, dalga kompozisyonu grafiği, her silahla "kaç atışta ölür?" tablosu |
| **Silahlar** (`silahlar.php`, `silah.php`) | 16 silah: hasar, atış hızı, saniye başı hasar, şarjör, fiyat. Kart/tablo görünümü, sıralama, Mermi Gücü hesaplayıcısı, 5 bomba |
| **Skinler** (`skinler.php`) | 19 görünüm, nadirlik şansları, efsanevi efektler ve **kasa açma simülatörü** |
| **Görevler** (`gorevler.php`) | 8 dalga görevi; seçtiğin dalgaya göre hedef ve ödül hesaplayıcısı |
| **Genel** (`genel.php`) | 17 rehber sayfası: kontroller, zorluklar, dalgalar, gece/özel dalgalar, bosslar, ekonomi, mağaza, yetenek ağacı, savunma, hile konsolu… |
| **Arama** (`arama.php`) | Bütün bölümlerde Türkçe karakter duyarlı arama |
| **Yönetim paneli** (`admin/`) | Her şeyi ekle / düzenle / sil, görsel yükle, site ayarları ve oyun formülleri |

## Kurulum (XAMPP)

1. `zombie-crusher-wiki` klasörünü XAMPP'ın `htdocs` klasörüne kopyala:
   `C:\xampp\htdocs\zombie-crusher-wiki`
2. **XAMPP Control Panel**'de **Apache** ve **MySQL**'i **Start** ile başlat.
3. Tarayıcıda aç: <http://localhost/zombie-crusher-wiki/kurulum.php>
4. Bir yönetici kullanıcı adı ve şifre belirle, **Kurulumu başlat**'a bas.
   Sihirbaz `zombie_crusher_wiki` veritabanını oluşturur, oyunun bütün verilerini yükler ve hesabını açar.
5. Wiki: <http://localhost/zombie-crusher-wiki/> · Yönetim: <http://localhost/zombie-crusher-wiki/admin/>

Kurulum bitince klasörde `kurulum.kilit` dosyası oluşur ve sihirbaz kilitlenir. Veritabanını sıfırlayıp baştan
kurmak istersen bu dosyayı silip `kurulum.php`'yi tekrar aç.

### MySQL şifren varsa
XAMPP'ta `root` kullanıcısının şifresi varsayılan olarak boştur. Şifre koyduysan ya da başka bir kullanıcı
kullanıyorsan `config.php` dosyasındaki `DB_USER` ve `DB_PASS` değerlerini düzenle.

### Elle kurulum (phpMyAdmin)
1. <http://localhost/phpmyadmin> → **Yeni** → veritabanı adı `zombie_crusher_wiki`, karşılaştırma `utf8mb4_turkish_ci` → **Oluştur**.
2. Veritabanını seç → **İçe aktar** → `database.sql` dosyasını seç → **Git**.
3. <http://localhost/zombie-crusher-wiki/admin/> adresine git; hiç yönetici olmadığı için sayfa ilk yönetici hesabını
   oluşturmanı ister.

## Yönetim paneli

- **İçerik:** Yaratıklar, Silahlar, Bombalar, Skinler, Görevler, Genel bilgiler ve Zorluklar için ekleme, düzenleme, silme.
- **Görsel yükleme:** PNG, JPG, WEBP ya da GIF (en fazla 4 MB). Dosyalar `uploads/` klasörüne rastgele bir adla kaydedilir.
  Şeffaf arka planlı görseller en iyi görünür.
- **Site ayarları:** site adı, ana sayfa yazısı, duyuru, kasa şansları ve **oyun formülleri**. Oyunda dengeyi
  değiştirirsen (ör. zombilerin dalga başı can artışı) buradan güncelle; bütün hesaplayıcılar bu sayıları kullanır.
- **Hesap ve yöneticiler:** şifre değiştirme, yeni yönetici ekleme.

### Uzun metinlerde Markdown
| Yazdığın | Görünen |
|---|---|
| `**kalın**`, `*italik*`, `` `kod` `` | **kalın**, *italik*, `kod` |
| `## Başlık`, `### Alt başlık` | Başlıklar (sayfanın içindekiler listesine de eklenir) |
| `- madde` ya da `1. madde` | Liste |
| `\| a \| b \|` satırları + `\|---\|---\|` | Tablo |
| `> not` | Turuncu not kutusu |
| `[[Tank]]` ya da `[[Tank\|tank zombisi]]` | Wiki bağlantısı (yaratık, silah, skin, görev, bomba ya da sayfa adı) |
| `[yazı](https://...)` | Bağlantı |
| `![Açıklama](assets/img/genel/savas-dronu.webp)` | Görsel |

Düzenleme sayfasındaki **Önizle** düğmesi metni kaydetmeden nasıl görüneceğini gösterir.

## Klasör yapısı

```
zombie-crusher-wiki/
├── index.php, yaratiklar.php, yaratik.php, silahlar.php, silah.php,
│   skinler.php, gorevler.php, genel.php, arama.php      ← sayfalar
├── kurulum.php        ← kurulum sihirbazı
├── config.php         ← veritabanı ayarları
├── database.sql       ← tablolar + oyunun verileri
├── inc/               ← ortak kod (veritabanı, Markdown, şablon, ikonlar)
├── admin/             ← yönetim paneli
├── assets/css, js     ← tasarım ve etkileşimler (kütüphane yok)
├── assets/fonts       ← yazı tipleri (internet gerekmez)
├── assets/img         ← oyunun modellerinden çizilmiş görseller, çam ormanları, favicon
└── uploads/           ← panelden yüklenen görseller
```

## Sorun giderme

- **"Wiki henüz kurulmamış" sayfası:** MySQL çalışmıyor ya da kurulum yapılmadı. XAMPP'ta MySQL'i başlat, sonra `kurulum.php`'yi aç.
- **Apache başlamıyor (port 80 dolu):** Skype/IIS gibi bir program 80 numaralı portu kullanıyor olabilir. XAMPP'ta
  Apache → Config → `httpd.conf` içinde `Listen 80` satırını `Listen 8080` yap, adresi `http://localhost:8080/zombie-crusher-wiki/` olarak kullan.
- **Görsel yüklenmiyor:** `php.ini` içindeki `upload_max_filesize` ve `post_max_size` değerlerini kontrol et;
  `uploads` klasörünün yazılabilir olduğundan emin ol.
- **Türkçe karakterler bozuk:** Veritabanını elle oluşturduysan karşılaştırmanın `utf8mb4_turkish_ci` olduğundan emin ol.

## Güvenlik notları

- Şifreler `password_hash` ile saklanır; bütün formlarda CSRF anahtarı, bütün sorgularda hazır ifadeler (prepared statements) kullanılır.
- `uploads/` klasöründe betik çalıştırılamaz (`.htaccess`); `database.sql` ve `kurulum.kilit` tarayıcıdan indirilemez.
- Wiki yerel ağ için tasarlandı. İnternete açacaksan güçlü bir şifre kullan ve işin bitince `kurulum.php`'yi sil.
