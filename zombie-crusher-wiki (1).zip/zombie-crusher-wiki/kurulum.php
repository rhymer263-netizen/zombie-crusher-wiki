<?php
/*
 * Zombie Crusher Wiki — kurulum sihirbazı
 * Veritabanını oluşturur, tabloları ve örnek verileri yükler, ilk yönetici hesabını açar.
 * Kurulum bitince "kurulum.kilit" dosyası oluşur; tekrar kurmak için bu dosyayı sil.
 */
define('KOK', __DIR__);
require KOK . '/config.php';
require KOK . '/inc/fonksiyonlar.php';
require KOK . '/inc/ikonlar.php';

header('Content-Type: text/html; charset=utf-8');
session_name('zcwiki');
session_start();

$kilit = KOK . '/kurulum.kilit';
$hatalar = [];
$bitti = false;
$kilitli = is_file($kilit);

// Ön kontroller
if (version_compare(PHP_VERSION, '7.4.0', '<')) $hatalar[] = 'PHP 7.4 ya da daha yeni bir sürüm gerekli (şu an: ' . PHP_VERSION . ').';
if (!extension_loaded('pdo_mysql')) $hatalar[] = 'PHP\'de pdo_mysql eklentisi açık değil (php.ini → extension=pdo_mysql).';
if (!is_file(KOK . '/database.sql')) $hatalar[] = 'database.sql dosyası bulunamadı.';

$sunucu = null;
if (!$hatalar) {
    try {
        $sunucu = new PDO('mysql:host=' . DB_HOST . ';port=' . DB_PORT . ';charset=utf8mb4', DB_USER, DB_PASS, [
            PDO::ATTR_ERRMODE => PDO::ERRMODE_EXCEPTION,
        ]);
    } catch (Throwable $h) {
        $hatalar[] = 'MySQL sunucusuna bağlanılamadı: ' . $h->getMessage()
            . ' — XAMPP Kontrol Paneli\'nde MySQL\'i başlattığından ve config.php\'deki kullanıcı/şifrenin doğru olduğundan emin ol.';
    }
}

$form = ['kullanici' => 'admin', 'ornek' => true];

if (!$hatalar && !$kilitli && $_SERVER['REQUEST_METHOD'] === 'POST') {
    if (!hash_equals((string)($_SESSION['kurulum_csrf'] ?? ''), (string)($_POST['csrf'] ?? ''))) {
        $hatalar[] = 'Form süresi dolmuş, sayfayı yenileyip tekrar dene.';
    }
    $form['kullanici'] = trim((string)($_POST['kullanici'] ?? ''));
    $form['ornek'] = !empty($_POST['ornek']);
    $sifre = (string)($_POST['sifre'] ?? '');
    $sifre2 = (string)($_POST['sifre2'] ?? '');
    if (!preg_match('/^[A-Za-z0-9_.-]{3,30}$/', $form['kullanici'])) $hatalar[] = 'Kullanıcı adı 3–30 karakter olmalı (harf, rakam, _ . -).';
    if (mb_strlen($sifre) < 6) $hatalar[] = 'Şifre en az 6 karakter olmalı.';
    if ($sifre !== $sifre2) $hatalar[] = 'Şifreler aynı değil.';

    if (!$hatalar) {
        try {
            $vt = str_replace('`', '', DB_NAME);
            $sunucu->exec("CREATE DATABASE IF NOT EXISTS `$vt` CHARACTER SET utf8mb4 COLLATE utf8mb4_turkish_ci");
            $sunucu->exec("USE `$vt`");
            $sunucu->exec('SET NAMES utf8mb4');

            $komut = '';
            foreach (file(KOK . '/database.sql') as $satir) {
                $t = trim($satir);
                if ($komut === '' && ($t === '' || str_starts_with($t, '--'))) continue;
                $komut .= $satir;
                if (substr(rtrim($satir), -1) === ';') {
                    $k = trim($komut);
                    $komut = '';
                    // Örnek veri istenmediyse sadece ayarlar ve zorluklar yüklenir (site bunlarsız çalışmaz)
                    if (!$form['ornek'] && preg_match('/^INSERT INTO `(\w+)`/', $k, $m) && !in_array($m[1], ['ayarlar', 'zorluklar'], true)) continue;
                    $sunucu->exec($k);
                }
            }

            $ekle = $sunucu->prepare('INSERT INTO yoneticiler (kullanici_adi, sifre_hash) VALUES (?, ?) ON DUPLICATE KEY UPDATE sifre_hash = VALUES(sifre_hash)');
            $ekle->execute([$form['kullanici'], password_hash($sifre, PASSWORD_DEFAULT)]);

            if (!is_dir(KOK . '/uploads')) @mkdir(KOK . '/uploads', 0775, true);
            @file_put_contents($kilit, 'Kurulum: ' . date('c') . "\nTekrar kurmak için bu dosyayı sil.\n");
            $bitti = true;
            unset($_SESSION['kurulum_csrf']);
        } catch (Throwable $h) {
            $hatalar[] = 'Kurulum sırasında hata: ' . $h->getMessage();
        }
    }
}

if (empty($_SESSION['kurulum_csrf'])) $_SESSION['kurulum_csrf'] = bin2hex(random_bytes(16));
$css = 'assets/css/site.css?v=' . (is_file(KOK . '/assets/css/site.css') ? filemtime(KOK . '/assets/css/site.css') : 1);
?>
<!doctype html>
<html lang="tr">
<head>
<meta charset="utf-8">
<meta name="viewport" content="width=device-width, initial-scale=1">
<title>Kurulum · Zombie Crusher Wiki</title>
<link rel="icon" href="assets/img/favicon.svg" type="image/svg+xml">
<link rel="stylesheet" href="<?= e($css) ?>">
<style>
  .kurulum{max-width:620px;margin:0 auto;padding:48px 20px 80px}
  .kurulum .kart{border:1px solid var(--line-2);background:var(--panel);padding:28px;box-shadow:0 20px 50px rgba(0,0,0,.45)}
  .kurulum h1{font-size:48px;margin:18px 0 6px}
  .kurulum label{display:block;font:600 13px/1 var(--font-ui);letter-spacing:.1em;text-transform:uppercase;color:var(--muted);margin:18px 0 8px}
  .kurulum .girdi{width:100%;font-size:16px;padding:12px}
  .kurulum .adimlar{display:grid;gap:8px;margin:18px 0 6px;font-size:15px;color:var(--ink-2)}
  .kurulum .adimlar span{display:flex;gap:10px;align-items:center}
  .kurulum .adimlar .ikon{color:var(--toxic)}
  .kurulum .onay{display:flex;gap:10px;align-items:flex-start;margin:20px 0;font-size:15px;color:var(--ink-2);text-transform:none;letter-spacing:0;font-family:var(--font-body)}
  .kurulum .onay input{margin-top:4px;width:18px;height:18px;accent-color:var(--blood)}
  .kurulum .hata{padding:12px 16px;border-left:3px solid var(--blood);background:rgba(216,64,47,.1);margin:0 0 12px;font-size:15px}
  .kurulum .mono-kutu{font:500 13px/1.7 var(--font-mono);background:var(--bg-2);border:1px solid var(--line);padding:12px 14px;color:var(--ink-2)}
</style>
</head>
<body>
<main class="kurulum">
  <a class="logo" href="index.php"><?= logo_svg() ?><span class="logo-yazi"><b>ZOMBIE <span>CRUSHER</span></b><small>WİKİ KURULUMU</small></span></a>
  <h1><?= $bitti ? 'Kurulum tamam!' : ($kilitli ? 'Zaten kurulu' : 'Kurulum') ?></h1>

  <div class="kart">
  <?php if ($bitti): ?>
    <div class="bildirim">Veritabanı <b><?= e(DB_NAME) ?></b> hazır<?= $form['ornek'] ? ', oyunun bütün verileri yüklendi' : '' ?>. Yönetici hesabı: <b><?= e($form['kullanici']) ?></b></div>
    <p>Güvenlik için bu sihirbaz artık kilitli. Tekrar kurmak istersen klasördeki <code>kurulum.kilit</code> dosyasını sil.</p>
    <p><a class="dugme" href="index.php"><?= ikon('ev') ?>Wikiyi aç</a> <a class="dugme ikincil" href="admin/"><?= ikon('kilit') ?>Yönetim paneli</a></p>
  <?php elseif ($kilitli): ?>
    <p>Bu wiki daha önce kurulmuş. Veritabanını sıfırlayıp yeniden kurmak istersen proje klasöründeki <code>kurulum.kilit</code> dosyasını silip bu sayfayı yenile.</p>
    <p><a class="dugme" href="index.php"><?= ikon('ev') ?>Wikiyi aç</a> <a class="dugme ikincil" href="admin/"><?= ikon('kilit') ?>Yönetim paneli</a></p>
  <?php else: ?>
    <?php foreach ($hatalar as $h): ?><div class="hata"><?= e($h) ?></div><?php endforeach; ?>
    <p>Sihirbaz <b><?= e(DB_NAME) ?></b> veritabanını oluşturacak (varsa wiki tablolarını sıfırlar), oyunun verilerini yükleyecek ve senin için bir yönetici hesabı açacak.</p>
    <div class="mono-kutu">Sunucu: <?= e(DB_HOST . ':' . DB_PORT) ?> · Kullanıcı: <?= e(DB_USER) ?> · PHP <?= e(PHP_VERSION) ?></div>
    <?php if ($sunucu): ?>
    <div class="adimlar">
      <span><?= ikon('nisan') ?>MySQL bağlantısı çalışıyor</span>
    </div>
    <form method="post" autocomplete="off">
      <input type="hidden" name="csrf" value="<?= e($_SESSION['kurulum_csrf']) ?>">
      <label for="kullanici">Yönetici kullanıcı adı</label>
      <input class="girdi" id="kullanici" name="kullanici" value="<?= e($form['kullanici']) ?>" required pattern="[A-Za-z0-9_.\-]{3,30}">
      <label for="sifre">Şifre (en az 6 karakter)</label>
      <input class="girdi" id="sifre" name="sifre" type="password" required minlength="6">
      <label for="sifre2">Şifre (tekrar)</label>
      <input class="girdi" id="sifre2" name="sifre2" type="password" required minlength="6">
      <label class="onay"><input type="checkbox" name="ornek" value="1" <?= $form['ornek'] ? 'checked' : '' ?>> <span>Oyunun verilerini yükle: 13 yaratık, 16 silah, 5 bomba, 19 skin, 8 görev ve 17 rehber sayfası (önerilir).</span></label>
      <button class="dugme" type="submit"><?= ikon('indir') ?>Kurulumu başlat</button>
    </form>
    <?php endif; ?>
  <?php endif; ?>
  </div>
</main>
</body>
</html>
