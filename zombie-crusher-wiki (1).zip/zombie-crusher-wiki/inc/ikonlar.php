<?php
/*
 * Satır içi SVG ikonlar (24×24, çizgi). Kullanım: echo ikon('ara');
 */

function ikon(string $ad, string $sinif = ''): string
{
    static $yollar = [
        'ara'      => '<circle cx="11" cy="11" r="7"/><path d="M20 20l-4.2-4.2"/>',
        'menu'     => '<path d="M4 7h16M4 12h16M4 17h16"/>',
        'kapat'    => '<path d="M6 6l12 12M18 6L6 18"/>',
        'yaratik'  => '<path d="M12 3c-4.4 0-8 3.1-8 7.4 0 2.6 1.3 4.5 3 5.6V20h2v-2h2v2h2v-2h2v2h2v-4c1.7-1.1 3-3 3-5.6C20 6.1 16.4 3 12 3z"/><circle cx="9" cy="11" r="1.6"/><circle cx="15" cy="11" r="1.6"/>',
        'kafatasi' => '<path d="M12 3c-4.4 0-8 3.1-8 7.4 0 2.6 1.3 4.5 3 5.6V20h2v-2h2v2h2v-2h2v2h2v-4c1.7-1.1 3-3 3-5.6C20 6.1 16.4 3 12 3z"/><circle cx="9" cy="11" r="1.6"/><circle cx="15" cy="11" r="1.6"/>',
        'silah'    => '<path d="M2 10h13l2-2h5v3h-3l-1.2 2.2H12l-1.4 1.6V19H7.6l.8-6H2z"/><path d="M9 10V8"/>',
        'skin'     => '<path d="M12 3a9 9 0 1 0 0 18c1.1 0 1.6-.8 1.6-1.6 0-1-.8-1.4-.8-2.3 0-.9.7-1.6 1.6-1.6H17a4 4 0 0 0 4-4C21 6.6 17 3 12 3z"/><circle cx="7.5" cy="11" r="1.2"/><circle cx="10" cy="7" r="1.2"/><circle cx="15" cy="7.5" r="1.2"/>',
        'gorev'    => '<path d="M5 21V4M5 4h12l-2.5 4L17 12H5"/>',
        'genel'    => '<path d="M4 5a2 2 0 0 1 2-2h13v16H6a2 2 0 0 0-2 2z"/><path d="M4 19V5M8 7h7M8 11h5"/>',
        'kitap'    => '<path d="M4 5a2 2 0 0 1 2-2h13v16H6a2 2 0 0 0-2 2z"/><path d="M4 19V5M8 7h7M8 11h5"/>',
        'klavye'   => '<rect x="2" y="6" width="20" height="12" rx="2"/><path d="M6 10h.01M10 10h.01M14 10h.01M18 10h.01M7 14h10"/>',
        'ayar'     => '<circle cx="12" cy="12" r="3.2"/><path d="M12 2v3M12 19v3M2 12h3M19 12h3M4.9 4.9 7 7M17 17l2.1 2.1M4.9 19.1 7 17M17 7l2.1-2.1"/>',
        'dalga'    => '<path d="M2 9c2.5 0 2.5-2 5-2s2.5 2 5 2 2.5-2 5-2 2.5 2 5 2M2 15c2.5 0 2.5-2 5-2s2.5 2 5 2 2.5-2 5-2 2.5 2 5 2"/>',
        'ay'       => '<path d="M20 14.5A8 8 0 1 1 9.5 4 6.5 6.5 0 0 0 20 14.5z"/>',
        'bulut'    => '<path d="M7 18h10a4 4 0 0 0 .6-8A6 6 0 0 0 6 9.6 4.2 4.2 0 0 0 7 18z"/>',
        'tac'      => '<path d="M3 8l4.5 4L12 5l4.5 7L21 8l-2 11H5z"/>',
        'para'     => '<circle cx="12" cy="12" r="9"/><path d="M15 9.5c-.5-1-1.6-1.5-3-1.5-1.7 0-3 .9-3 2s1.3 1.7 3 2 3 .9 3 2-1.3 2-3 2c-1.4 0-2.5-.5-3-1.5M12 6v2M12 16v2"/>',
        'kemik'    => '<path d="M8.5 8.5l7 7"/><circle cx="5.5" cy="7.5" r="2"/><circle cx="7.5" cy="5.5" r="2"/><circle cx="16.5" cy="18.5" r="2"/><circle cx="18.5" cy="16.5" r="2"/>',
        'magaza'   => '<path d="M3 4h2l2.4 10.2a1 1 0 0 0 1 .8h8.8a1 1 0 0 0 1-.8L20 7H6.2"/><circle cx="9.5" cy="19" r="1.5"/><circle cx="17" cy="19" r="1.5"/>',
        'agac'     => '<circle cx="12" cy="5" r="2"/><circle cx="6" cy="19" r="2"/><circle cx="18" cy="19" r="2"/><circle cx="12" cy="12.5" r="2"/><path d="M12 7v3.5M10.6 14l-3.2 3.4M13.4 14l3.2 3.4"/>',
        'kalkan'   => '<path d="M12 3l8 3v6c0 4.5-3.4 8-8 9-4.6-1-8-4.5-8-9V6z"/>',
        'kosu'     => '<circle cx="14" cy="4.5" r="2"/><path d="M9 21l2.5-6 3 3V22M6 12l3-4h5l2 4h3M11.5 15 10 9"/>',
        'terminal' => '<rect x="3" y="4" width="18" height="16" rx="2"/><path d="M7 9l3 3-3 3M12 15h5"/>',
        'ses'      => '<path d="M4 9h4l5-4v14l-5-4H4z"/><path d="M16.5 8.5a5 5 0 0 1 0 7M19 6a8.5 8.5 0 0 1 0 12"/>',
        'indir'    => '<path d="M12 3v12M7 10l5 5 5-5M4 20h16"/>',
        'nisan'    => '<circle cx="12" cy="12" r="7"/><path d="M12 2v5M12 17v5M2 12h5M17 12h5"/><circle cx="12" cy="12" r="1"/>',
        'bicak'    => '<path d="M3.5 20.5l6-6M9.5 14.5 19.8 4.2c.8-.8 1.9-.1 1.6 1-.9 3.6-3.6 6.7-7.6 8.4L12.4 15.6z"/><path d="M8 13l3 3"/>',
        'bomba'    => '<circle cx="11" cy="14" r="7"/><path d="M14.5 8l2-2.5h3M17 4l2 2"/>',
        'alev'     => '<path d="M12 22c4 0 7-2.8 7-6.8 0-3.6-2.4-5.6-3.6-8.6-1 2.4-2 3.2-3.4 3.6.4-2.6-.4-5.6-2.8-8.2C9 6.2 5 9.4 5 15.2 5 19.2 8 22 12 22z"/>',
        'kalp'     => '<path d="M12 20s-7-4.4-7-10a4 4 0 0 1 7-2.6A4 4 0 0 1 19 10c0 5.6-7 10-7 10z"/>',
        'simsek'   => '<path d="M13 2 4 14h7l-1 8 9-12h-7z"/>',
        'ok'       => '<path d="M5 12h14M13 6l6 6-6 6"/>',
        'ok-sol'   => '<path d="M19 12H5M11 6l-6 6 6 6"/>',
        'ok-asagi' => '<path d="M12 5v14M6 13l6 6 6-6"/>',
        'kilit'    => '<rect x="5" y="11" width="14" height="10" rx="2"/><path d="M8 11V8a4 4 0 0 1 8 0v3"/>',
        'yildiz'   => '<path d="M12 3l2.7 5.6 6.1.9-4.4 4.3 1 6.1L12 17l-5.4 2.9 1-6.1-4.4-4.3 6.1-.9z"/>',
        'kasa'     => '<path d="M3 7l9-4 9 4v10l-9 4-9-4z"/><path d="M3 7l9 4 9-4M12 11v10"/>',
        'anahtar'  => '<circle cx="8" cy="15" r="4"/><path d="M11 12l9-9M17 6l3 3M15 8l2 2"/>',
        'kart'     => '<rect x="3" y="3" width="7" height="7" rx="1"/><rect x="14" y="3" width="7" height="7" rx="1"/><rect x="3" y="14" width="7" height="7" rx="1"/><rect x="14" y="14" width="7" height="7" rx="1"/>',
        'liste'    => '<path d="M8 6h13M8 12h13M8 18h13M3.5 6h.01M3.5 12h.01M3.5 18h.01"/>',
        'duzenle'  => '<path d="M4 20h4L19 9l-4-4L4 16z"/><path d="M13.5 6.5l4 4"/>',
        'sil'      => '<path d="M4 7h16M10 11v6M14 11v6M6 7l1 13h10l1-13M9 7V4h6v3"/>',
        'arti'     => '<path d="M12 5v14M5 12h14"/>',
        'cikis'    => '<path d="M15 4h4v16h-4M10 8l-4 4 4 4M6 12h10"/>',
        'ev'       => '<path d="M3 11l9-7 9 7v9h-6v-6H9v6H3z"/>',
        'goz'      => '<path d="M2 12s3.5-7 10-7 10 7 10 7-3.5 7-10 7S2 12 2 12z"/><circle cx="12" cy="12" r="3"/>',
        'saat'     => '<circle cx="12" cy="12" r="9"/><path d="M12 7v5l3 2"/>',
        'zar'      => '<rect x="4" y="4" width="16" height="16" rx="3"/><circle cx="9" cy="9" r=".8"/><circle cx="15" cy="15" r=".8"/><circle cx="15" cy="9" r=".8"/><circle cx="9" cy="15" r=".8"/>',
        'us'       => '<path d="M4 21V9l8-5 8 5v12M9 21v-6h6v6M3 21h18"/>',
        'dis'      => '<path d="M14 4h6v6M20 4l-9 9M18 14v6H4V6h6"/>',
        'uyari'    => '<path d="M12 3l10 18H2z"/><path d="M12 10v5M12 18h.01"/>',
        'resim'    => '<rect x="3" y="4" width="18" height="16" rx="2"/><circle cx="9" cy="10" r="2"/><path d="M21 16l-5-5-9 9"/>',
        'kullanici'=> '<circle cx="12" cy="8" r="4"/><path d="M4 21c1.5-4 4.5-6 8-6s6.5 2 8 6"/>',
        'cark'     => '<circle cx="12" cy="12" r="3"/><path d="M19.4 15a1.6 1.6 0 0 0 .3 1.8l.1.1a2 2 0 1 1-2.8 2.8l-.1-.1a1.6 1.6 0 0 0-1.8-.3 1.6 1.6 0 0 0-1 1.5V21a2 2 0 0 1-4 0v-.1a1.6 1.6 0 0 0-1-1.5 1.6 1.6 0 0 0-1.8.3l-.1.1a2 2 0 1 1-2.8-2.8l.1-.1a1.6 1.6 0 0 0 .3-1.8 1.6 1.6 0 0 0-1.5-1H3a2 2 0 0 1 0-4h.1a1.6 1.6 0 0 0 1.5-1 1.6 1.6 0 0 0-.3-1.8l-.1-.1a2 2 0 1 1 2.8-2.8l.1.1a1.6 1.6 0 0 0 1.8.3H9a1.6 1.6 0 0 0 1-1.5V3a2 2 0 0 1 4 0v.1a1.6 1.6 0 0 0 1 1.5 1.6 1.6 0 0 0 1.8-.3l.1-.1a2 2 0 1 1 2.8 2.8l-.1.1a1.6 1.6 0 0 0-.3 1.8V9a1.6 1.6 0 0 0 1.5 1H21a2 2 0 0 1 0 4h-.1a1.6 1.6 0 0 0-1.5 1z"/>',
    ];
    $y = $yollar[$ad] ?? $yollar['nisan'];
    return '<svg class="ikon' . ($sinif !== '' ? ' ' . e($sinif) : '') . '" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.8" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true" focusable="false">' . $y . '</svg>';
}

/** Wiki logosu: nişangâh + pençe izi. */
function logo_svg(string $sinif = 'logo-isaret'): string
{
    return '<svg class="' . e($sinif) . '" viewBox="0 0 48 48" aria-hidden="true" focusable="false">'
        . '<circle cx="24" cy="24" r="16.5" fill="none" stroke="currentColor" stroke-width="3"/>'
        . '<path d="M24 1.5v10M24 36.5v10M1.5 24h10M36.5 24h10" stroke="currentColor" stroke-width="3"/>'
        . '<path d="M14.5 33.5 28 11M19.5 37 34 13.5M25.5 38.5 37.5 19" stroke="#d8402f" stroke-width="3.4" stroke-linecap="round"/>'
        . '</svg>';
}
