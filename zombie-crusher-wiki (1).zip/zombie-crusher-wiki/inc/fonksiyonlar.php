<?php
/*
 * Ortak yardımcı fonksiyonlar.
 * PHP 7.4 ve üstüyle çalışır (XAMPP 7.4 / 8.x).
 */

// PHP 7.4 için küçük yamalar
if (!function_exists('str_contains')) {
    function str_contains($samanlik, $igne) { return $igne === '' || strpos($samanlik, $igne) !== false; }
}
if (!function_exists('str_starts_with')) {
    function str_starts_with($samanlik, $igne) { return strncmp($samanlik, $igne, strlen($igne)) === 0; }
}

/* ------------------------------------------------------------------ veritabanı */

function db(): PDO
{
    static $pdo = null;
    if ($pdo === null) {
        $dsn = 'mysql:host=' . DB_HOST . ';port=' . DB_PORT . ';dbname=' . DB_NAME . ';charset=utf8mb4';
        $pdo = new PDO($dsn, DB_USER, DB_PASS, [
            PDO::ATTR_ERRMODE            => PDO::ERRMODE_EXCEPTION,
            PDO::ATTR_DEFAULT_FETCH_MODE => PDO::FETCH_ASSOC,
            PDO::ATTR_EMULATE_PREPARES   => false,
        ]);
        $pdo->exec('SET NAMES utf8mb4 COLLATE utf8mb4_turkish_ci');
    }
    return $pdo;
}

function sorgu(string $sql, array $p = []): PDOStatement
{
    $s = db()->prepare($sql);
    $s->execute($p);
    return $s;
}

function tumu(string $sql, array $p = []): array { return sorgu($sql, $p)->fetchAll(); }

function tek(string $sql, array $p = [])
{
    $r = sorgu($sql, $p)->fetch();
    return $r === false ? null : $r;
}

function deger(string $sql, array $p = []) { return sorgu($sql, $p)->fetchColumn(); }

/** Ayarlar tablosundan bir değer (istek başına bir kez yüklenir). */
function ayar(string $anahtar, string $varsayilan = ''): string
{
    static $ayarlar = null;
    if ($ayarlar === null) {
        $ayarlar = [];
        foreach (tumu('SELECT anahtar, deger FROM ayarlar') as $r) {
            $ayarlar[$r['anahtar']] = $r['deger'];
        }
    }
    return array_key_exists($anahtar, $ayarlar) ? $ayarlar[$anahtar] : $varsayilan;
}

function ayar_sayi(string $anahtar, float $varsayilan): float
{
    $d = str_replace(',', '.', ayar($anahtar, (string)$varsayilan));
    return is_numeric($d) ? (float)$d : $varsayilan;
}

/* ------------------------------------------------------------------ metin */

function e($s): string { return htmlspecialchars((string)$s, ENT_QUOTES | ENT_SUBSTITUTE, 'UTF-8'); }

function tr_kucuk(string $s): string { return mb_strtolower(strtr($s, ['I' => 'ı', 'İ' => 'i']), 'UTF-8'); }

function tr_buyuk(string $s): string { return mb_strtoupper(strtr($s, ['i' => 'İ', 'ı' => 'I']), 'UTF-8'); }

/** "Zombi Köpek" -> "zombi-kopek" */
function slugla(string $s): string
{
    $s = tr_kucuk($s);
    $s = strtr($s, ['ç' => 'c', 'ğ' => 'g', 'ı' => 'i', 'ö' => 'o', 'ş' => 's', 'ü' => 'u', 'â' => 'a', 'î' => 'i', 'û' => 'u']);
    $s = preg_replace('/[^a-z0-9]+/', '-', $s);
    $s = trim((string)$s, '-');
    return $s === '' ? 'sayfa' : $s;
}

/** Türkçe sayı biçimi: 1.600 · 2,3 · 0,55 */
function sayi($x, int $ondalik = 2): string
{
    $x = (float)$x;
    if (abs($x - round($x)) < 0.00001) {
        return number_format($x, 0, ',', '.');
    }
    $s = number_format($x, $ondalik, ',', '.');
    return rtrim(rtrim($s, '0'), ',');
}

function para($x): string { return '$' . sayi(round((float)$x)); }

function kisalt(string $s, int $uzunluk = 140): string
{
    $s = trim(preg_replace('/\s+/u', ' ', strip_tags($s)));
    if (mb_strlen($s) <= $uzunluk) return $s;
    return rtrim(mb_substr($s, 0, $uzunluk - 1)) . '…';
}

/** Markdown işaretlerini atıp düz metin bırakır (özetler ve arama için). */
function duz_metin(?string $md): string
{
    $s = (string)$md;
    $s = preg_replace('/\[\[([^\]|]+)\|([^\]]+)\]\]/u', '$2', $s);
    $s = preg_replace('/\[\[([^\]]+)\]\]/u', '$1', $s);
    $s = preg_replace('/!\[[^\]]*\]\([^)]*\)/u', '', $s);
    $s = preg_replace('/\[([^\]]+)\]\([^)]*\)/u', '$1', $s);
    $s = preg_replace('/^\s*(#{1,6}|>|-|\*|\d+\.)\s*/mu', '', $s);
    $s = str_replace(['**', '`', '|'], ['', '', ' '], $s);
    $s = preg_replace('/(^|\s)\*(\S)/u', '$1$2', $s);
    return trim(preg_replace('/\s+/u', ' ', $s));
}

/* ------------------------------------------------------------------ adresler ve görseller */

function yaratik_url(string $slug): string { return 'yaratik.php?s=' . rawurlencode($slug); }
function silah_url(string $slug): string { return 'silah.php?s=' . rawurlencode($slug); }
function genel_url(string $slug): string { return 'genel.php?s=' . rawurlencode($slug); }

/** Kök klasöre göre adres (admin/ içinden çağrılınca ../ ekler). */
function kok_url(string $yol): string
{
    $yol = ltrim($yol, '/');
    if (preg_match('#^(https?:)?//#i', $yol)) return $yol;
    return (defined('ADMIN') ? '../' : '') . $yol;
}

/** CSS/JS için önbellek kırıcı sürüm parametresi ekler. */
function varlik(string $yol): string
{
    $tam = KOK . '/' . $yol;
    $v = is_file($tam) ? filemtime($tam) : 1;
    return kok_url($yol) . '?v=' . $v;
}

function gorsel_var(?string $yol): bool
{
    $yol = (string)$yol;
    if ($yol === '' || str_contains($yol, '..')) return false;
    return is_file(KOK . '/' . ltrim($yol, '/'));
}

/** <img> etiketi; boyutları dosyadan okur (sayfa kayması olmasın). */
function gorsel(?string $yol, string $alt, string $sinif = '', bool $tembel = true): string
{
    if (!gorsel_var($yol)) return '';
    $tam = KOK . '/' . ltrim((string)$yol, '/');
    $boyut = @getimagesize($tam);
    $wh = $boyut ? ' width="' . (int)$boyut[0] . '" height="' . (int)$boyut[1] . '"' : '';
    return '<img src="' . e(kok_url((string)$yol)) . '?v=' . filemtime($tam) . '" alt="' . e($alt) . '"'
        . ($sinif !== '' ? ' class="' . e($sinif) . '"' : '') . $wh
        . ($tembel ? ' loading="lazy" decoding="async"' : '') . '>';
}

/* ------------------------------------------------------------------ oturum, güvenlik */

function csrf(): string
{
    if (empty($_SESSION['csrf'])) {
        $_SESSION['csrf'] = bin2hex(random_bytes(32));
    }
    return $_SESSION['csrf'];
}

function csrf_alani(): string { return '<input type="hidden" name="csrf" value="' . e(csrf()) . '">'; }

function csrf_dogrula(): void
{
    $gelen = (string)($_POST['csrf'] ?? '');
    if (!hash_equals(csrf(), $gelen)) {
        http_response_code(400);
        exit('Güvenlik anahtarı geçersiz ya da süresi doldu. Sayfayı yenileyip tekrar dene.');
    }
}

function bildirim(string $metin, string $tur = 'tamam'): void { $_SESSION['bildirim'][] = [$tur, $metin]; }

function bildirimleri_yaz(): string
{
    if (empty($_SESSION['bildirim'])) return '';
    $h = '';
    foreach ($_SESSION['bildirim'] as $b) {
        $h .= '<div class="bildirim bildirim-' . e($b[0]) . '" role="status">' . e($b[1]) . '</div>';
    }
    unset($_SESSION['bildirim']);
    return $h;
}

function yonlendir(string $adres): void
{
    header('Location: ' . $adres);
    exit;
}

function yonetici(): ?array { return isset($_SESSION['yonetici']) && is_array($_SESSION['yonetici']) ? $_SESSION['yonetici'] : null; }

/* ------------------------------------------------------------------ oyun hesapları */

/** Silahın anlık saniye başı hasarı (doğrudan isabet, bütün saçmalar isabet ederse). */
function silah_dps(array $s): float
{
    return (float)$s['hasar'] * max(1, (int)$s['sacma']) * (float)$s['atis_hizi'];
}

/** Doldurma süresi dahil sürekli saniye başı hasar. */
function silah_surekli_dps(array $s): float
{
    $dps = silah_dps($s);
    $sarjor = (int)$s['sarjor'];
    $atis = (float)$s['atis_hizi'];
    $dold = (float)$s['doldurma'];
    if ($sarjor <= 0 || $atis <= 0 || $dold <= 0) return $dps;
    $sure = $sarjor / $atis;
    return $dps * $sure / ($sure + $dold);
}

/** Hesaplayıcıların (JS) kullandığı formüller ve zorluk çarpanları. */
function formuller(): array
{
    $zorluklar = [];
    foreach (tumu('SELECT * FROM zorluklar ORDER BY sira, id') as $z) {
        $zorluklar[] = [
            'ad' => $z['ad'], 'can' => (float)$z['can_carpani'], 'hasar' => (float)$z['hasar_carpani'],
            'hiz' => (float)$z['hiz_carpani'], 'sayi' => (float)$z['sayi_carpani'], 'para' => (float)$z['para_carpani'],
            'anahtar' => (float)$z['anahtar_carpani'], 'us' => (float)$z['us_carpani'], 'renk' => $z['renk'],
            'varsayilan' => (int)$z['varsayilan'] === 1,
        ];
    }
    if (!$zorluklar) {
        $zorluklar[] = ['ad' => 'Normal', 'can' => 1, 'hasar' => 1, 'hiz' => 1, 'sayi' => 1, 'para' => 1, 'anahtar' => 1, 'us' => 1, 'renk' => '#ffd64d', 'varsayilan' => true];
    }
    return [
        'dalgaCan'      => ayar_sayi('f_dalga_can', 0.13),
        'dalgaHiz'      => ayar_sayi('f_dalga_hiz', 0.022),
        'hizTavan'      => ayar_sayi('f_hiz_tavan', 1.7),
        'hasarBolen'    => ayar_sayi('f_hasar_bolen', 3.5),
        'hasarCarpan'   => ayar_sayi('f_hasar_carpan', 0.92),
        'geceCan'       => ayar_sayi('f_gece_can', 1.12),
        'geceHiz'       => ayar_sayi('f_gece_hiz', 1.08),
        'gecePara'      => ayar_sayi('f_gece_para', 1.2),
        'kafa'          => ayar_sayi('f_kafa_carpan', 2),
        'gorevTaban'    => ayar_sayi('f_gorev_odul_taban', 120),
        'gorevDalga'    => ayar_sayi('f_gorev_odul_dalga', 20),
        'gorevAnahtar'  => ayar_sayi('f_gorev_anahtar_sans', 0.3),
        'gorevAnahtarPara' => ayar_sayi('f_gorev_anahtar_para', 0.4),
        'bonusTaban'    => ayar_sayi('f_dalga_bonus_taban', 60),
        'bonusDalga'    => ayar_sayi('f_dalga_bonus_dalga', 18),
        'sayiTaban'     => ayar_sayi('f_zombi_sayi_taban', 5),
        'sayiDalga'     => ayar_sayi('f_zombi_sayi_dalga', 2.7),
        'zorluklar'     => $zorluklar,
    ];
}

function json_html($veri): string
{
    return htmlspecialchars(json_encode($veri, JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES), ENT_QUOTES, 'UTF-8');
}

/* ------------------------------------------------------------------ wiki bağlantıları */

/** [[Ad]] bağlantıları için ad → adres tablosu. */
function wiki_harita(): array
{
    static $h = null;
    if ($h !== null) return $h;
    $h = [];
    $ekle = function (string $ad, string $url) use (&$h) {
        $k = tr_kucuk(trim($ad));
        if ($k !== '' && !isset($h[$k])) $h[$k] = $url;
    };
    foreach (tumu('SELECT slug, ad FROM yaratiklar') as $r) $ekle($r['ad'], yaratik_url($r['slug']));
    foreach (tumu('SELECT slug, ad FROM silahlar') as $r) $ekle($r['ad'], silah_url($r['slug']));
    foreach (tumu('SELECT slug, ad FROM bombalar') as $r) $ekle($r['ad'], 'silahlar.php#bomba-' . $r['slug']);
    foreach (tumu('SELECT slug, ad FROM skinler') as $r) $ekle($r['ad'], 'skinler.php#skin-' . $r['slug']);
    foreach (tumu('SELECT slug, kod_adi FROM gorevler') as $r) $ekle($r['kod_adi'], 'gorevler.php#gorev-' . $r['slug']);
    foreach (tumu('SELECT slug, baslik FROM genel') as $r) $ekle($r['baslik'], genel_url($r['slug']));
    return $h;
}

/* ------------------------------------------------------------------ Markdown */

/**
 * Küçük ve güvenli bir Markdown çevirici. Önce bütün HTML kaçırılır, sonra şunlar desteklenir:
 * başlıklar (## ###), kalın (**), italik (*), `kod`, [metin](adres), [[Wiki Bağlantısı]] veya [[Ad|metin]],
 * listeler (- ve 1.), tablolar (| a | b |), alıntı/not (>), ![görsel](yol), --- çizgi ve ``` kod blokları.
 */
function md(?string $metin, ?array &$basliklar = null): string
{
    $basliklar = [];
    $metin = str_replace(["\r\n", "\r"], "\n", (string)$metin);
    if (trim($metin) === '') return '';
    $s = explode("\n", $metin);
    $n = count($s);
    $i = 0;
    $html = '';
    $kullanilan_idler = [];

    while ($i < $n) {
        $t = trim($s[$i]);
        if ($t === '') { $i++; continue; }

        // kod bloğu
        if (str_starts_with($t, '```')) {
            $kod = [];
            $i++;
            while ($i < $n && !str_starts_with(trim($s[$i]), '```')) { $kod[] = $s[$i]; $i++; }
            $i++;
            $html .= '<pre><code>' . e(implode("\n", $kod)) . '</code></pre>';
            continue;
        }
        // başlık
        if (preg_match('/^(#{1,6})\s+(.+)$/u', $t, $m)) {
            $seviye = min(4, max(2, strlen($m[1])));
            $yazi = trim($m[2], " #");
            $id = slugla(duz_metin($yazi));
            $taban = $id; $k = 2;
            while (isset($kullanilan_idler[$id])) { $id = $taban . '-' . $k++; }
            $kullanilan_idler[$id] = true;
            if ($seviye <= 3) $basliklar[] = ['id' => $id, 'yazi' => duz_metin($yazi), 'seviye' => $seviye];
            $html .= '<h' . $seviye . ' id="' . e($id) . '">' . md_satir($yazi) . '</h' . $seviye . '>';
            $i++;
            continue;
        }
        // yatay çizgi
        if (preg_match('/^(-{3,}|\*{3,}|_{3,})$/', $t)) { $html .= '<hr>'; $i++; continue; }
        // alıntı / not kutusu
        if (str_starts_with($t, '>')) {
            $q = [];
            while ($i < $n && str_starts_with(trim($s[$i]), '>')) {
                $q[] = ltrim(substr(trim($s[$i]), 1));
                $i++;
            }
            $html .= '<blockquote class="not">' . md(implode("\n", $q)) . '</blockquote>';
            continue;
        }
        // tablo
        if (str_starts_with($t, '|') && $i + 1 < $n && preg_match('/^\|?\s*:?-{2,}:?\s*(\|\s*:?-{2,}:?\s*)*\|?$/', trim($s[$i + 1]))) {
            $baslik = md_tablo_satiri($t);
            $hizalar = [];
            foreach (md_tablo_satiri(trim($s[$i + 1])) as $hucre) {
                $hucre = trim($hucre);
                $hizalar[] = (str_ends_with_($hucre, ':') ? (str_starts_with($hucre, ':') ? 'center' : 'right') : '');
            }
            $i += 2;
            $satirlar = [];
            while ($i < $n && str_starts_with(trim($s[$i]), '|')) { $satirlar[] = md_tablo_satiri(trim($s[$i])); $i++; }
            $h = '<div class="tablo-kap"><table class="tablo"><thead><tr>';
            foreach ($baslik as $j => $hucre) $h .= '<th' . (!empty($hizalar[$j]) ? ' style="text-align:' . $hizalar[$j] . '"' : '') . '>' . md_satir($hucre) . '</th>';
            $h .= '</tr></thead><tbody>';
            foreach ($satirlar as $r) {
                $h .= '<tr>';
                foreach ($baslik as $j => $_) {
                    $hucre = $r[$j] ?? '';
                    $h .= '<td' . (!empty($hizalar[$j]) ? ' style="text-align:' . $hizalar[$j] . '"' : '') . '>' . md_satir($hucre) . '</td>';
                }
                $h .= '</tr>';
            }
            $html .= $h . '</tbody></table></div>';
            continue;
        }
        // görsel (tek başına bir satırda)
        if (preg_match('/^!\[([^\]]*)\]\(([^)\s]+)\)$/u', $t, $m)) {
            $yol = $m[2];
            if (preg_match('#^[a-z0-9_\-./]+$#i', $yol) && !str_contains($yol, '..') && gorsel_var($yol)) {
                $html .= '<figure class="md-gorsel">' . gorsel($yol, $m[1]) . ($m[1] !== '' ? '<figcaption>' . e($m[1]) . '</figcaption>' : '') . '</figure>';
            } elseif (preg_match('#^https?://#i', $yol)) {
                $html .= '<figure class="md-gorsel"><img src="' . e($yol) . '" alt="' . e($m[1]) . '" loading="lazy"></figure>';
            }
            $i++;
            continue;
        }
        // liste
        if (preg_match('/^([-*+]|\d+[.)])\s+/u', $t)) {
            $sirali = (bool)preg_match('/^\d+[.)]\s+/', $t);
            $ogeler = [];
            while ($i < $n) {
                $x = trim($s[$i]);
                if ($x === '') break;
                if (preg_match('/^([-*+]|\d+[.)])\s+(.*)$/u', $x, $m)) {
                    $ogeler[] = $m[2];
                } elseif ($ogeler && !md_blok_basi($x)) {
                    $ogeler[count($ogeler) - 1] .= ' ' . $x;   // devam satırı
                } else {
                    break;
                }
                $i++;
            }
            $etiket = $sirali ? 'ol' : 'ul';
            $html .= '<' . $etiket . '>';
            foreach ($ogeler as $o) $html .= '<li>' . md_satir($o) . '</li>';
            $html .= '</' . $etiket . '>';
            continue;
        }
        // paragraf
        $p = [$t];
        $i++;
        while ($i < $n && trim($s[$i]) !== '' && !md_blok_basi(trim($s[$i]))) { $p[] = trim($s[$i]); $i++; }
        $html .= '<p>' . md_satir(implode(' ', $p)) . '</p>';
    }
    return $html;
}

function str_ends_with_(string $s, string $son): bool { return $son === '' || substr($s, -strlen($son)) === $son; }

function md_blok_basi(string $t): bool
{
    return (bool)preg_match('/^(#{1,6}\s|>|```|\||[-*+]\s|\d+[.)]\s|!\[|-{3,}$)/u', $t);
}

function md_tablo_satiri(string $t): array
{
    $t = trim($t);
    if (str_starts_with($t, '|')) $t = substr($t, 1);
    if (str_ends_with_($t, '|')) $t = substr($t, 0, -1);
    // `kod` içindeki | işaretini korumak için basit ayrıştırma
    $hucreler = [];
    $cur = '';
    $kod = false;
    $len = strlen($t);
    for ($k = 0; $k < $len; $k++) {
        $c = $t[$k];
        if ($c === '`') $kod = !$kod;
        if ($c === '|' && !$kod) { $hucreler[] = trim($cur); $cur = ''; continue; }
        $cur .= $c;
    }
    $hucreler[] = trim($cur);
    return $hucreler;
}

/** Satır içi biçimlendirme. Girdi ham metindir; burada kaçırılır. */
function md_satir(string $s): string
{
    $korunan = [];
    $koru = function (string $html) use (&$korunan): string {
        $k = "\x01" . count($korunan) . "\x02";
        $korunan[$k] = $html;
        return $k;
    };

    // `kod`
    $s = preg_replace_callback('/`([^`]+)`/u', function ($m) use ($koru) { return $koru('<code>' . e($m[1]) . '</code>'); }, $s);

    // [[Wiki]] ve [[Wiki|metin]]
    $s = preg_replace_callback('/\[\[([^\]|]+)(?:\|([^\]]+))?\]\]/u', function ($m) use ($koru) {
        $hedef = trim($m[1]);
        $yazi = isset($m[2]) && $m[2] !== '' ? trim($m[2]) : $hedef;
        $harita = wiki_harita();
        $k = tr_kucuk($hedef);
        if (isset($harita[$k])) {
            return $koru('<a class="wiki" href="' . e(kok_url($harita[$k])) . '">' . e($yazi) . '</a>');
        }
        return $koru('<a class="wiki yok" href="' . e(kok_url('arama.php?q=' . rawurlencode($hedef))) . '" title="Bu başlıkta sayfa yok">' . e($yazi) . '</a>');
    }, $s);

    // [metin](adres) — sadece http(s) ya da göreli adresler
    $s = preg_replace_callback('/\[([^\]]+)\]\(([^)\s]+)\)/u', function ($m) use ($koru) {
        $adres = $m[2];
        $dis = (bool)preg_match('#^https?://#i', $adres);
        if (!$dis && !preg_match('#^[a-z0-9_\-./?=&\#%]+$#i', $adres)) return $m[0];
        $href = $dis ? $adres : kok_url($adres);
        return $koru('<a href="' . e($href) . '"' . ($dis ? ' target="_blank" rel="noopener noreferrer"' : '') . '>' . e($m[1]) . '</a>');
    }, $s);

    $s = e($s);
    $s = preg_replace('/\*\*(.+?)\*\*/u', '<strong>$1</strong>', $s);
    $s = preg_replace('/(?<![\w*])\*(?!\s)(.+?)(?<!\s)\*(?![\w*])/u', '<em>$1</em>', $s);

    return strtr($s, $korunan);
}

/* ------------------------------------------------------------------ hata sayfaları */

function kurulum_gerekli(Throwable $h): void
{
    http_response_code(503);
    $mesaj = $h->getMessage();
    echo '<!doctype html><html lang="tr"><head><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1">'
        . '<title>Kurulum gerekli</title><style>body{margin:0;min-height:100vh;display:grid;place-items:center;background:#0b0e0c;color:#ece6d6;font:16px/1.6 system-ui,sans-serif;padding:24px}'
        . '.k{max-width:560px;border:1px solid #29342d;background:#141a16;padding:32px;border-radius:6px}h1{margin:0 0 8px;font-size:24px}code{background:#1f2923;padding:2px 6px;border-radius:3px;word-break:break-word}'
        . 'a.d{display:inline-block;margin-top:16px;background:#d8402f;color:#fff;padding:10px 18px;border-radius:4px;text-decoration:none;font-weight:600}</style></head><body><div class="k">'
        . '<h1>Wiki henüz kurulmamış</h1><p>Veritabanına bağlanılamadı ya da tablolar yok. XAMPP Kontrol Paneli\'nde <b>Apache</b> ve <b>MySQL</b>\'in çalıştığından emin ol, sonra kurulum sihirbazını aç.</p>'
        . '<p style="color:#8a9488;font-size:14px">Ayrıntı: <code>' . e($mesaj) . '</code></p>'
        . '<a class="d" href="' . e(kok_url('kurulum.php')) . '">Kurulumu başlat</a></div></body></html>';
    exit;
}
