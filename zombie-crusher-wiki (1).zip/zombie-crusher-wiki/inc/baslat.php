<?php
/*
 * Her sayfanın en başında çağrılır: ayarlar, oturum, veritabanı ve yardımcılar.
 */

define('KOK', dirname(__DIR__));

require_once KOK . '/config.php';
require_once KOK . '/inc/fonksiyonlar.php';
require_once KOK . '/inc/ikonlar.php';
require_once KOK . '/inc/sablon.php';

date_default_timezone_set('Europe/Istanbul');
mb_internal_encoding('UTF-8');
header('Content-Type: text/html; charset=utf-8');
header('X-Content-Type-Options: nosniff');
header('Referrer-Policy: same-origin');

if (session_status() === PHP_SESSION_NONE) {
    session_set_cookie_params([
        'lifetime' => 0,
        'path'     => '/',
        'httponly' => true,
        'samesite' => 'Lax',
    ]);
    session_name('zcwiki');
    session_start();
}

/*
 * Veritabanına bağlanılamıyorsa ya da tablolar yoksa kurulum sayfasına yönlendir.
 * (kurulum.php kendisi bu dosyayı kullanmaz.)
 */
try {
    db()->query('SELECT 1 FROM ayarlar LIMIT 1');
} catch (Throwable $h) {
    kurulum_gerekli($h);
}
