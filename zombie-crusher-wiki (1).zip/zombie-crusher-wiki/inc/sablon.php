<?php
/*
 * Sayfa iskeleti: üst bilgi, gezinme, afiş, çam ormanı silueti ve alt bilgi.
 */

const MENU = [
    ['yaratiklar.php', 'Yaratıklar', '01', 'yaratik'],
    ['silahlar.php',   'Silahlar',   '02', 'silah'],
    ['skinler.php',    'Skinler',    '03', 'skin'],
    ['gorevler.php',   'Görevler',   '04', 'gorev'],
    ['genel.php',      'Genel',      '05', 'genel'],
];

function sayfa_ust(string $baslik, string $aktif = '', array $ops = []): void
{
    $site = ayar('site_adi', 'Zombie Crusher Wiki');
    $tam_baslik = $baslik === '' ? $site : $baslik . ' · ' . $site;
    $aciklama = $ops['aciklama'] ?? ayar('hero_metin');
    $govde = $ops['govde'] ?? '';
    $q = isset($_GET['q']) ? (string)$_GET['q'] : '';
    ?>
<!doctype html>
<html lang="tr">
<head>
<meta charset="utf-8">
<meta name="viewport" content="width=device-width, initial-scale=1">
<title><?= e($tam_baslik) ?></title>
<meta name="description" content="<?= e(kisalt($aciklama, 160)) ?>">
<meta name="theme-color" content="#0b0e0c">
<link rel="icon" href="<?= e(varlik('assets/img/favicon.svg')) ?>" type="image/svg+xml">
<link rel="stylesheet" href="<?= e(varlik('assets/css/site.css')) ?>">
</head>
<body class="<?= e($govde) ?>">
<a class="atla" href="#icerik">İçeriğe geç</a>
<header class="ust" id="ust">
  <div class="ust-ic">
    <a class="logo" href="<?= e(kok_url('index.php')) ?>" aria-label="<?= e($site) ?> ana sayfa">
      <?= logo_svg() ?>
      <span class="logo-yazi"><b>ZOMBIE <span>CRUSHER</span></b><small><?= e(tr_buyuk(ayar('alt_baslik', 'Saha Arşivi'))) ?></small></span>
    </a>
    <nav class="nav" id="nav" aria-label="Ana menü">
      <?php foreach (MENU as $m): ?>
        <a href="<?= e(kok_url($m[0])) ?>" class="<?= $aktif === $m[3] ? 'aktif' : '' ?>"<?= $aktif === $m[3] ? ' aria-current="page"' : '' ?>><i><?= e($m[2]) ?></i><?= e($m[1]) ?></a>
      <?php endforeach; ?>
      <form class="ara-kutu" action="<?= e(kok_url('arama.php')) ?>" method="get" role="search">
        <?= ikon('ara') ?>
        <input type="search" name="q" value="<?= e($q) ?>" placeholder="Arşivde ara…" aria-label="Wikide ara" autocomplete="off">
      </form>
    </nav>
    <button class="menu-dugme" type="button" aria-controls="nav" aria-expanded="false" aria-label="Menüyü aç"><?= ikon('menu') ?></button>
  </div>
</header>
<main id="icerik">
<?php
}

function sayfa_alt(): void
{
    $yil = date('Y');
    ?>
</main>
<footer class="alt">
  <?= orman_svg(7, 'alt-orman', 140) ?>
  <div class="alt-ic">
    <div class="alt-marka">
      <a class="logo" href="<?= e(kok_url('index.php')) ?>"><?= logo_svg() ?><span class="logo-yazi"><b>ZOMBIE <span>CRUSHER</span></b><small><?= e(tr_buyuk(ayar('alt_baslik', 'Saha Arşivi'))) ?></small></span></a>
      <p><?= e(ayar('alt_bilgi')) ?></p>
    </div>
    <div class="alt-linkler">
      <b>Arşiv</b>
      <?php foreach (MENU as $m): ?><a href="<?= e(kok_url($m[0])) ?>"><?= e($m[1]) ?></a><?php endforeach; ?>
    </div>
    <div class="alt-linkler">
      <b>Hızlı erişim</b>
      <a href="<?= e(kok_url(genel_url('kontroller'))) ?>">Kontroller</a>
      <a href="<?= e(kok_url(genel_url('boss-savaslari'))) ?>">Boss savaşları</a>
      <a href="<?= e(kok_url(genel_url('yetenek-agaci'))) ?>">Yetenek ağacı</a>
      <a href="<?= e(kok_url('admin/')) ?>"><?= yonetici() ? 'Yönetim paneli' : 'Yönetici girişi' ?></a>
    </div>
  </div>
  <div class="alt-cizgi"><span>© <?= e($yil) ?> <?= e(ayar('oyun_adi', 'Zombie Crusher')) ?></span><span class="mono">DALGA ∞ · ÜS AYAKTA</span></div>
</footer>
<div id="ipucu-kutu" class="ipucu-kutu" role="tooltip" hidden></div>
<script src="<?= e(varlik('assets/js/site.js')) ?>" defer></script>
</body>
</html>
<?php
}

/** Alt sayfaların başındaki afiş. $iz: [['Yaratıklar', 'yaratiklar.php'], ['Tank']] */
function afis(string $no, string $baslik, string $metin, array $iz = [], string $sag = '', string $sinif = ''): void
{
    ?>
<section class="afis <?= e($sinif) ?>">
  <div class="gunes" aria-hidden="true"></div>
  <?= orman_svg(crc32($baslik) % 997, 'afis-orman', 180) ?>
  <div class="afis-ic sar">
    <div class="afis-no" aria-hidden="true"><?= e($no) ?></div>
    <div class="afis-metin">
      <nav class="iz" aria-label="Konum">
        <a href="<?= e(kok_url('index.php')) ?>">Arşiv</a>
        <?php foreach ($iz as $parca): ?>
          <span aria-hidden="true">/</span>
          <?php if (!empty($parca[1])): ?><a href="<?= e(kok_url($parca[1])) ?>"><?= e($parca[0]) ?></a><?php else: ?><span aria-current="page"><?= e($parca[0]) ?></span><?php endif; ?>
        <?php endforeach; ?>
      </nav>
      <h1><?= e($baslik) ?></h1>
      <?php if ($metin !== ''): ?><p><?= e($metin) ?></p><?php endif; ?>
    </div>
    <?php if ($sag !== ''): ?><div class="afis-sag"><?= $sag ?></div><?php endif; ?>
  </div>
</section>
<?php
}

/**
 * Çam ormanı silueti. Ormanlar cam_yolu() ile koddan üretilip assets/img/orman/ içine
 * statik SVG olarak kaydedildi (tarayıcı önbelleğe alsın diye). Aynı tohum hep aynı ormanı seçer.
 */
function orman_svg(int $tohum, string $sinif, int $yukseklik = 180): string
{
    $tur = $sinif === 'hero-orman' ? 'hero' : ($sinif === 'alt-orman' ? 'alt' : 'afis-' . (abs($tohum) % 6));
    return '<img class="orman ' . e($sinif) . '" src="' . e(varlik('assets/img/orman/' . $tur . '.svg')) . '" alt="" aria-hidden="true" decoding="async">';
}

function cam_yolu(int $tohum, int $g, int $h, float $min, float $max, int $aralikMin, int $aralikMax): string
{
    $r = ($tohum & 0x7fffffff) ?: 1;
    $rnd = function () use (&$r): float {
        $r = ($r * 1103515245 + 12345) & 0x7fffffff;
        return $r / 0x7fffffff;
    };
    $d = '';
    $x = -20.0;
    while ($x < $g + 40) {
        $boy = $h * ($min + ($max - $min) * $rnd());
        $en = $boy * (0.34 + 0.12 * $rnd());
        $taban = (float)$h;
        $tepe = $taban - $boy;
        $kat = 4;
        $sag = [];
        for ($k = 1; $k <= $kat; $k++) {
            $y = $tepe + $boy * 0.86 * $k / $kat;
            $w = $en / 2 * $k / $kat;
            $sag[] = [$x + $w, $y];
            if ($k < $kat) $sag[] = [$x + $w * 0.42, $y - $boy * 0.015];
        }
        $govdeY = $tepe + $boy * 0.86;
        $p = [[$x, $tepe]];
        foreach ($sag as $nokta) $p[] = $nokta;
        $p[] = [$x + $en * 0.05, $govdeY];
        $p[] = [$x + $en * 0.05, $taban];
        $p[] = [$x - $en * 0.05, $taban];
        $p[] = [$x - $en * 0.05, $govdeY];
        foreach (array_reverse($sag) as $nokta) $p[] = [2 * $x - $nokta[0], $nokta[1]];
        $d .= 'M' . implode('L', array_map(function ($n) { return round($n[0], 1) . ' ' . round($n[1], 1); }, $p)) . 'Z';
        $x += $aralikMin + ($aralikMax - $aralikMin) * $rnd();
    }
    // zemin
    $zemin = max(4, (int)round($h * 0.1));
    $d .= 'M0 ' . ($h - $zemin) . 'H' . $g . 'V' . $h . 'H0Z';
    return $d;
}

/** Afişlerde ve ana sayfada süzülen korlar. */
function korlar(int $adet = 18, int $tohum = 5): string
{
    $r = $tohum;
    $rnd = function () use (&$r): float {
        $r = ($r * 1103515245 + 12345) & 0x7fffffff;
        return $r / 0x7fffffff;
    };
    $h = '<div class="korlar" aria-hidden="true">';
    for ($i = 0; $i < $adet; $i++) {
        $h .= '<i style="left:' . round($rnd() * 100, 1) . '%;--g:' . round(2 + $rnd() * 3, 1) . 'px;--s:' . round(7 + $rnd() * 9, 1) . 's;--d:-' . round($rnd() * 12, 1) . 's;--x:' . round(-40 + $rnd() * 80) . 'px"></i>';
    }
    return $h . '</div>';
}

/** Tehdit göstergesi: 5 kafatası. */
function tehdit_gostergesi(int $seviye): string
{
    if ($seviye <= 0) return '<span class="tehdit dost" title="Dost">DOST</span>';
    $h = '<span class="tehdit" role="img" aria-label="Tehdit seviyesi ' . $seviye . ' / 5">';
    for ($i = 1; $i <= 5; $i++) $h .= '<i class="' . ($i <= $seviye ? 'dolu' : '') . '"></i>';
    return $h . '</span>';
}

function kategori_adi(string $k): string
{
    switch ($k) {
        case 'boss': return 'Boss';
        case 'hayatta-kalan': return 'Hayatta Kalan';
        default: return 'Zombi';
    }
}

function sinif_rengi(string $sinif): string
{
    $renkler = [
        'Tabanca' => '#bfccd9', 'Hafif Makineli' => '#73d9ff', 'Taarruz Tüfeği' => '#80ff80', 'Pompalı' => '#ff994d',
        'Keskin Nişancı' => '#cc8cff', 'Ağır Silah' => '#ff594d', 'Özel' => '#ffcc40', 'Yakın Dövüş' => '#e6e1d3',
    ];
    return $renkler[$sinif] ?? '#e6e1d3';
}

function nadirlik_sinifi(string $n): string
{
    switch (tr_kucuk($n)) {
        case 'yaygın': return 'yaygin';
        case 'destansı': return 'destansi';
        case 'efsanevi': return 'efsanevi';
        default: return 'varsayilan';
    }
}

function efekt_sinifi(string $slug, string $efekt): string
{
    $harita = ['24k' => 'parilti', 'neon-siber' => 'neon', 'lav-cekirdegi' => 'lav', 'gokkusagi' => 'gokkusagi', 'mor-otesi' => 'galaksi', 'tropik-ada' => 'okyanus'];
    if (isset($harita[$slug])) return 'fx-' . $harita[$slug];
    $e = tr_kucuk($efekt);
    if (str_contains($e, 'parıltı') || str_contains($e, 'ışıltı')) return 'fx-isilti';
    if (str_contains($e, 'neon')) return 'fx-neon';
    if (str_contains($e, 'lav') || str_contains($e, 'kor')) return 'fx-lav';
    if (str_contains($e, 'gökkuşağı') || str_contains($e, 'renk')) return 'fx-gokkusagi';
    if (str_contains($e, 'yıldız') || str_contains($e, 'galaksi')) return 'fx-galaksi';
    if (str_contains($e, 'dalga') || str_contains($e, 'okyanus')) return 'fx-okyanus';
    return '';
}

function bulunamadi(string $ne, string $geri_url, string $geri_yazi): void
{
    http_response_code(404);
    sayfa_ust('Bulunamadı');
    afis('404', 'Kayıt bulunamadı', $ne . ' arşivde yok. Belki zombiler yemiştir.', [['Bulunamadı']]);
    echo '<div class="sar bos-durum"><p>Aradığın sayfa silinmiş ya da adı değişmiş olabilir.</p><a class="dugme" href="' . e(kok_url($geri_url)) . '">' . ikon('ok-sol') . e($geri_yazi) . '</a> <a class="dugme ikincil" href="' . e(kok_url('arama.php')) . '">' . ikon('ara') . 'Arşivde ara</a></div>';
    sayfa_alt();
    exit;
}
