<?php
require __DIR__ . '/inc/baslat.php';

$skinler = tumu('SELECT * FROM skinler ORDER BY sira, id');
$nadirliklar = ['Varsayılan', 'Yaygın', 'Destansı', 'Efsanevi'];
$gruplar = array_fill_keys($nadirliklar, []);
foreach ($skinler as $k) {
    $n = in_array($k['nadirlik'], $nadirliklar, true) ? $k['nadirlik'] : 'Yaygın';
    $gruplar[$n][] = $k;
}
$sans = ['Yaygın' => ayar_sayi('kasa_yaygin', 70), 'Destansı' => ayar_sayi('kasa_destansi', 24), 'Efsanevi' => ayar_sayi('kasa_efsanevi', 6)];
$kopya = ['Yaygın' => ayar_sayi('kopya_yaygin', 60), 'Destansı' => ayar_sayi('kopya_destansi', 180), 'Efsanevi' => ayar_sayi('kopya_efsanevi', 600)];

// Kasadan çıkabilecek eşyalar: bütün ateşli/özel silahlar + bıçak
$esyalar = array_column(tumu("SELECT ad FROM silahlar WHERE sinif <> 'Yakın Dövüş' ORDER BY sira, id"), 'ad');
$bicak = deger("SELECT ad FROM silahlar WHERE sinif = 'Yakın Dövüş' ORDER BY sira LIMIT 1") ?: 'Bıçak';
$renkSkin = count(array_filter($skinler, function ($k) { return $k['nadirlik'] !== 'Varsayılan' && !(int)$k['sadece_bicak']; }));
$bicakSkin = count(array_filter($skinler, function ($k) { return $k['nadirlik'] !== 'Varsayılan' && (int)$k['sadece_bicak']; }));
$koleksiyon = (count($esyalar) + 1) * $renkSkin + $bicakSkin;

$kasaVerisi = [
    'sans' => $sans,
    'kopya' => $kopya,
    'esyalar' => $esyalar,
    'bicak' => $bicak,
    'toplam' => $koleksiyon,
    'skinler' => array_values(array_map(function ($k) {
        return ['slug' => $k['slug'], 'ad' => $k['ad'], 'nadirlik' => $k['nadirlik'], 'bicak' => (int)$k['sadece_bicak'] === 1,
                'gorsel' => gorsel_var($k['gorsel']) ? $k['gorsel'] : ''];
    }, array_filter($skinler, function ($k) { return $k['nadirlik'] !== 'Varsayılan'; }))),
];

$sag = '';
foreach (['Yaygın', 'Destansı', 'Efsanevi'] as $n) {
    $sag .= '<span class="cip n-' . nadirlik_sinifi($n) . '" style="color:var(--n);border-color:var(--n)"><i style="--c:var(--n)"></i>' . count($gruplar[$n]) . ' ' . e(tr_kucuk($n)) . '</span>';
}

sayfa_ust('Skinler', 'skin', ['aciklama' => 'Zombie Crusher silah görünümleri: kasa sistemi, nadirlikler, şanslar ve efsanevi efektler.']);
afis('03', 'Skinler', 'Kasadan çıkan silah ve bıçak görünümleri. Yaygın kamuflajlardan ışık saçan efsanevilere kadar hepsi, şanslarıyla birlikte.', [['Skinler']], $sag);
?>
<script type="application/json" id="zc-kasa"><?= json_encode($kasaVerisi, JSON_UNESCAPED_UNICODE | JSON_HEX_TAG | JSON_HEX_AMP) ?></script>
<div class="sar" data-sayfa="skinler">
  <section class="kasa" aria-labelledby="kasa-baslik">
    <div class="kasa-ust">
      <h2 id="kasa-baslik"><?= ikon('kasa') ?>Kasa açma simülatörü</h2>
      <div class="kasa-sanslar">
        <?php foreach ($sans as $n => $p): ?><span class="cip n-<?= nadirlik_sinifi($n) ?>" style="color:var(--n);border-color:var(--n)"><?= e($n) ?> %<?= sayi($p) ?></span><?php endforeach; ?>
      </div>
    </div>
    <div class="kasa-pencere" aria-hidden="true">
      <div class="kasa-serit" data-serit></div>
      <div class="kasa-imlec"></div>
    </div>
    <div class="kasa-alt">
      <button class="dugme" type="button" data-kasa-ac><?= ikon('anahtar') ?>Kasa aç</button>
      <div class="kasa-sonuc" data-sonuc aria-live="polite">Oyundaki gibi: önce nadirlik, sonra o nadirlikten bir görünüm, sonra rastgele bir silah ya da bıçak seçilir.</div>
      <div class="koleksiyon">Koleksiyonun<br><b data-koleksiyon>0</b> / <?= $koleksiyon ?></div>
    </div>
  </section>

  <section class="bolum" style="padding-bottom:0">
    <div class="kural-listesi">
      <div class="kural"><?= ikon('anahtar') ?><b>Anahtar bul</b><p>Zombilerden %0,7 şansla altın anahtar düşer (gece 1,8 kat). Bosslar her zaman bırakır, görevler de anahtar verebilir.</p></div>
      <div class="kural"><?= ikon('kasa') ?><b>Kasayı aç</b><p>Mağazanın KASA sekmesinde kartlar kayan bir şeritte yavaşlayıp kazandığın görünümde durur.</p></div>
      <div class="kural"><?= ikon('para') ?><b>Kopya = para</b><p>Zaten sahip olduğun bir görünüm çıkarsa: Yaygın <?= para($kopya['Yaygın']) ?>, Destansı <?= para($kopya['Destansı']) ?>, Efsanevi <?= para($kopya['Efsanevi']) ?>.</p></div>
      <div class="kural"><?= ikon('skin') ?><b>Kuşan</b><p>SİLAHLAR sekmesinde kartın altındaki <b>Görünüm &lt; &gt;</b> seçicisiyle. Görünümler kalıcıdır: <?= count($esyalar) + 1 ?> eşya × <?= $renkSkin ?> renk<?= $bicakSkin ? ' + Karambit' : '' ?> = <?= $koleksiyon ?> parça.</p></div>
    </div>
  </section>

  <?php foreach ($gruplar as $n => $liste): if (!$liste) continue; $ns = nadirlik_sinifi($n);
      $tekil = isset($sans[$n]) && count($liste) ? $sans[$n] / count($liste) : 0; ?>
    <div class="nadirlik-bas n-<?= $ns ?>">
      <h2><?= e($n) ?></h2>
      <?php if (isset($sans[$n])): ?><span class="cip">%<?= sayi($sans[$n]) ?> şans</span><?php endif; ?>
      <span class="cizgi"></span>
    </div>
    <div class="skin-izgara">
      <?php foreach ($liste as $k):
          $fx = $n === 'Efsanevi' || $n === 'Destansı' ? efekt_sinifi($k['slug'], $k['efekt']) : '';
          $renkler = array_filter(array_map('trim', explode(',', $k['renkler'])), function ($r) { return preg_match('/^#[0-9a-f]{3,8}$/i', $r); });
          ?>
        <article class="skin n-<?= $ns ?> <?= e($fx) ?><?= $k['aura'] !== '' ? ' aura' : '' ?>" id="skin-<?= e($k['slug']) ?>"<?= $k['aura'] !== '' ? ' style="--aura:' . e($k['aura']) . '"' : '' ?>>
          <div class="skin-gorsel"><?= gorsel($k['gorsel'], $k['ad'] . ' görünümü') ?: ikon('skin') ?></div>
          <div class="skin-bilgi">
            <div class="ust-satir"><span class="nadir"><?= e($n) ?></span><?php if ($tekil > 0): ?><span class="cip" title="Bir kasadan bu görünümün çıkma şansı">%<?= sayi($tekil, 2) ?></span><?php endif; ?></div>
            <h3><?= e($k['ad']) ?></h3>
            <?php if ($renkler): ?><div class="palet" aria-hidden="true"><?php foreach ($renkler as $r): ?><i style="background:<?= e($r) ?>"></i><?php endforeach; ?></div><?php endif; ?>
            <p><?= md_satir((string)$k['aciklama']) ?></p>
            <div class="skin-alt">
              <?php if ($k['desen'] !== ''): ?><span class="cip"><?= e($k['desen']) ?></span><?php endif; ?>
              <?php if ($k['efekt'] !== ''): ?><span class="cip"><i style="--c:<?= e($k['aura'] ?: '#ffbf33') ?>"></i><?= e($k['efekt']) ?></span><?php endif; ?>
              <?php if ((int)$k['sadece_bicak']): ?><span class="cip"><?= ikon('bicak') ?>Sadece bıçak</span><?php endif; ?>
            </div>
          </div>
        </article>
      <?php endforeach; ?>
    </div>
  <?php endforeach; ?>
  <p class="hesap-not" style="margin-top:24px">Görsellerde görünümler AK-74 üzerinde gösterilmiştir; oyunda her silaha uygulanır. Efsanevi görünümlerin ışık, aura ve parçacık efektleri oyunda canlıdır.</p>
</div>
<?php sayfa_alt();
