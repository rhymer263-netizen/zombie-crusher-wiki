<?php
/*
 * Yönetim panelinin düzenleyebildiği tablolar ve alanları.
 * Yeni bir alan eklemek için önce veritabanına sütunu ekle, sonra buraya tanımını yaz.
 *
 * Alan tipleri: metin, uzun (Markdown destekli), sayi, secim, onay, renk, gorsel, slug
 */

$ikonlar = ['kitap', 'klavye', 'kafatasi', 'ayar', 'dalga', 'ay', 'bulut', 'tac', 'para', 'kemik', 'magaza', 'agac', 'kalkan', 'kosu',
            'terminal', 'ses', 'indir', 'nisan', 'bicak', 'bomba', 'alev', 'kalp', 'simsek', 'kilit', 'yildiz', 'kasa', 'anahtar', 'us', 'gorev', 'silah', 'skin', 'yaratik'];
$ikonSecenek = array_combine($ikonlar, $ikonlar);

return [
    'yaratiklar' => [
        'baslik' => 'Yaratıklar', 'tekil' => 'yaratık', 'ikon' => 'yaratik', 'ad' => 'ad', 'klasor' => 'yaratiklar',
        'onizleme' => 'yaratik.php?s=',
        'liste' => ['ad' => 'Ad', 'kategori' => 'Kategori', 'can' => 'Can', 'hasar' => 'Hasar', 'hiz' => 'Hız', 'ilk_dalga' => 'İlk dalga'],
        'gruplar' => [
            'Kimlik' => [
                'ad' => ['tip' => 'metin', 'etiket' => 'Ad', 'zorunlu' => true, 'uzunluk' => 80],
                'slug' => ['tip' => 'slug', 'etiket' => 'Adres adı', 'ipucu' => 'Boş bırakırsan addan üretilir (ör. zombi-kopek).'],
                'unvan' => ['tip' => 'metin', 'etiket' => 'Unvan', 'ipucu' => 'Bosslar için: "Mezbahanın Efendisi" gibi.', 'uzunluk' => 120],
                'kategori' => ['tip' => 'secim', 'etiket' => 'Kategori', 'secenekler' => ['zombi' => 'Zombi', 'boss' => 'Boss', 'hayatta-kalan' => 'Hayatta kalan (dost)']],
                'tehdit' => ['tip' => 'sayi', 'etiket' => 'Tehdit seviyesi (0–5)', 'min' => 0, 'max' => 5, 'adim' => 1],
                'renk' => ['tip' => 'renk', 'etiket' => 'Vurgu rengi', 'ipucu' => 'Kart parıltısı ve dalga kompozisyonu grafiği bu rengi kullanır.'],
                'etiketler' => ['tip' => 'metin', 'etiket' => 'Etiketler', 'ipucu' => 'Virgülle ayır: Hızlı, Sürü', 'uzunluk' => 200],
                'gorsel' => ['tip' => 'gorsel', 'etiket' => 'Görsel'],
                'sira' => ['tip' => 'sayi', 'etiket' => 'Sıra', 'adim' => 1, 'ipucu' => 'Küçük sayı önce gösterilir.'],
            ],
            'İstatistikler (1. dalga, Normal)' => [
                'can' => ['tip' => 'sayi', 'etiket' => 'Can', 'adim' => 1, 'min' => 0],
                'hiz' => ['tip' => 'sayi', 'etiket' => 'Hız (m/sn)', 'adim' => 0.01, 'min' => 0],
                'hasar' => ['tip' => 'sayi', 'etiket' => 'Hasar', 'adim' => 0.1, 'min' => 0],
                'saldiri_araligi' => ['tip' => 'sayi', 'etiket' => 'Saldırı aralığı (sn)', 'adim' => 0.01, 'min' => 0],
                'odul' => ['tip' => 'sayi', 'etiket' => 'Ödül ($)', 'adim' => 1, 'min' => 0],
                'fark_etme' => ['tip' => 'sayi', 'etiket' => 'Fark etme menzili (m)', 'adim' => 0.1, 'min' => 0],
                'saldiri_menzili' => ['tip' => 'sayi', 'etiket' => 'Saldırı menzili (m)', 'adim' => 0.1, 'min' => 0, 'ipucu' => '0 = yakın dövüş'],
                'boyut' => ['tip' => 'sayi', 'etiket' => 'Boyut çarpanı', 'adim' => 0.01, 'min' => 0],
                'ilk_dalga' => ['tip' => 'sayi', 'etiket' => 'İlk dalga', 'adim' => 1, 'min' => 1],
                'dalgalar' => ['tip' => 'metin', 'etiket' => 'Boss dalgaları', 'ipucu' => 'Ör. 5, 35, 65…', 'uzunluk' => 80],
                'cikma_sansi' => ['tip' => 'metin', 'etiket' => 'Çıkma şansı (yazı)', 'uzunluk' => 160],
                'sans_taban' => ['tip' => 'sayi', 'etiket' => 'Başlangıç şansı (%)', 'adim' => 0.01, 'min' => 0, 'ipucu' => 'Dalga kompozisyonu grafiği için. 0 = geri kalan her şey (normal zombi).'],
                'sans_artis' => ['tip' => 'sayi', 'etiket' => 'Her dalga artış (%)', 'adim' => 0.01, 'min' => 0],
                'sans_tavan' => ['tip' => 'sayi', 'etiket' => 'En fazla (%)', 'adim' => 0.01, 'min' => 0],
            ],
            'Metinler' => [
                'kisa_aciklama' => ['tip' => 'metin', 'etiket' => 'Kısa açıklama', 'uzunluk' => 255],
                'gorunus' => ['tip' => 'uzun', 'etiket' => 'Görünüş', 'satir' => 3],
                'davranis' => ['tip' => 'uzun', 'etiket' => 'Davranış', 'satir' => 4],
                'ipucu' => ['tip' => 'uzun', 'etiket' => 'İpucu / taktik', 'satir' => 3],
                'aciklama' => ['tip' => 'uzun', 'etiket' => 'Ek bilgiler (Markdown)', 'satir' => 10],
            ],
        ],
    ],

    'silahlar' => [
        'baslik' => 'Silahlar', 'tekil' => 'silah', 'ikon' => 'silah', 'ad' => 'ad', 'klasor' => 'silahlar',
        'onizleme' => 'silah.php?s=',
        'liste' => ['ad' => 'Ad', 'sinif' => 'Sınıf', 'hasar' => 'Hasar', 'atis_hizi' => 'Atış/sn', 'sarjor' => 'Şarjör', 'fiyat' => 'Fiyat'],
        'gruplar' => [
            'Kimlik' => [
                'ad' => ['tip' => 'metin', 'etiket' => 'Ad', 'zorunlu' => true, 'uzunluk' => 80],
                'slug' => ['tip' => 'slug', 'etiket' => 'Adres adı', 'ipucu' => 'Boş bırakırsan addan üretilir.'],
                'sinif' => ['tip' => 'secim', 'etiket' => 'Sınıf', 'secenekler' => array_combine(
                    ['Tabanca', 'Hafif Makineli', 'Taarruz Tüfeği', 'Pompalı', 'Keskin Nişancı', 'Ağır Silah', 'Özel', 'Yakın Dövüş'],
                    ['Tabanca', 'Hafif Makineli', 'Taarruz Tüfeği', 'Pompalı', 'Keskin Nişancı', 'Ağır Silah', 'Özel', 'Yakın Dövüş'])],
                'fiyat' => ['tip' => 'sayi', 'etiket' => 'Fiyat ($)', 'adim' => 1, 'min' => 0, 'ipucu' => '0 = bedava / başlangıç'],
                'kilit' => ['tip' => 'metin', 'etiket' => 'Kilit / not', 'ipucu' => 'Ör. "20. dalgada açılır" ya da "Başlangıç silahı"', 'uzunluk' => 120],
                'gorsel' => ['tip' => 'gorsel', 'etiket' => 'Görsel'],
                'sira' => ['tip' => 'sayi', 'etiket' => 'Sıra', 'adim' => 1],
            ],
            'İstatistikler' => [
                'hasar' => ['tip' => 'sayi', 'etiket' => 'Hasar (mermi/saçma başı)', 'adim' => 0.1, 'min' => 0],
                'atis_hizi' => ['tip' => 'sayi', 'etiket' => 'Atış / saniye', 'adim' => 0.01, 'min' => 0],
                'sarjor' => ['tip' => 'sayi', 'etiket' => 'Şarjör', 'adim' => 1, 'min' => 0],
                'doldurma' => ['tip' => 'sayi', 'etiket' => 'Doldurma (sn)', 'adim' => 0.01, 'min' => 0],
                'sacma' => ['tip' => 'sayi', 'etiket' => 'Saçma sayısı', 'adim' => 1, 'min' => 1],
                'delme' => ['tip' => 'sayi', 'etiket' => 'Delme (zombi)', 'adim' => 1, 'min' => 1, 'ipucu' => '99 = sınırsız'],
                'menzil' => ['tip' => 'sayi', 'etiket' => 'Menzil (m)', 'adim' => 0.1, 'min' => 0],
                'alan_hasari' => ['tip' => 'sayi', 'etiket' => 'Alan hasarı', 'adim' => 0.1, 'min' => 0],
                'alan_yaricapi' => ['tip' => 'sayi', 'etiket' => 'Alan yarıçapı (m)', 'adim' => 0.1, 'min' => 0],
                'sekme' => ['tip' => 'sayi', 'etiket' => 'Sekme (derece)', 'adim' => 0.01, 'min' => 0],
                'hareket' => ['tip' => 'sayi', 'etiket' => 'Hareket hızı çarpanı', 'adim' => 0.01, 'min' => 0],
                'otomatik' => ['tip' => 'onay', 'etiket' => 'Otomatik ateş'],
                'nisan' => ['tip' => 'onay', 'etiket' => 'Nişan alınabilir'],
                'durbun' => ['tip' => 'onay', 'etiket' => 'Dürbünlü'],
            ],
            'Metinler' => [
                'kisa_aciklama' => ['tip' => 'metin', 'etiket' => 'Kısa açıklama', 'uzunluk' => 255],
                'ozellik' => ['tip' => 'uzun', 'etiket' => 'Özellik', 'satir' => 3],
                'ses' => ['tip' => 'uzun', 'etiket' => 'Ses', 'satir' => 2],
                'aciklama' => ['tip' => 'uzun', 'etiket' => 'Saha notu (Markdown)', 'satir' => 6],
            ],
        ],
    ],

    'bombalar' => [
        'baslik' => 'Bombalar', 'tekil' => 'bomba', 'ikon' => 'bomba', 'ad' => 'ad',
        'onizleme' => 'silahlar.php#bomba-',
        'liste' => ['ad' => 'Ad', 'fiyat' => 'Fiyat', 'hasar' => 'Hasar', 'alan' => 'Alan', 'sure' => 'Süre'],
        'gruplar' => [
            'Bomba' => [
                'ad' => ['tip' => 'metin', 'etiket' => 'Ad', 'zorunlu' => true, 'uzunluk' => 80],
                'slug' => ['tip' => 'slug', 'etiket' => 'Adres adı'],
                'fiyat' => ['tip' => 'sayi', 'etiket' => 'Fiyat ($)', 'adim' => 1, 'min' => 0],
                'adet' => ['tip' => 'sayi', 'etiket' => 'Alım başına adet', 'adim' => 1, 'min' => 1],
                'hasar' => ['tip' => 'sayi', 'etiket' => 'Hasar', 'adim' => 0.1, 'min' => 0],
                'hasar_notu' => ['tip' => 'metin', 'etiket' => 'Hasar notu', 'ipucu' => 'Ör. "saniyede" ya da "6 parça × 70"', 'uzunluk' => 80],
                'alan' => ['tip' => 'sayi', 'etiket' => 'Alan (m)', 'adim' => 0.1, 'min' => 0],
                'sure' => ['tip' => 'sayi', 'etiket' => 'Süre (sn)', 'adim' => 0.1, 'min' => 0],
                'renk' => ['tip' => 'renk', 'etiket' => 'Renk'],
                'etki' => ['tip' => 'uzun', 'etiket' => 'Etki', 'satir' => 3],
                'sira' => ['tip' => 'sayi', 'etiket' => 'Sıra', 'adim' => 1],
            ],
        ],
    ],

    'skinler' => [
        'baslik' => 'Skinler', 'tekil' => 'skin', 'ikon' => 'skin', 'ad' => 'ad', 'klasor' => 'skinler',
        'onizleme' => 'skinler.php#skin-',
        'liste' => ['ad' => 'Ad', 'nadirlik' => 'Nadirlik', 'desen' => 'Desen', 'efekt' => 'Efekt'],
        'gruplar' => [
            'Skin' => [
                'ad' => ['tip' => 'metin', 'etiket' => 'Ad', 'zorunlu' => true, 'uzunluk' => 80],
                'slug' => ['tip' => 'slug', 'etiket' => 'Adres adı'],
                'nadirlik' => ['tip' => 'secim', 'etiket' => 'Nadirlik', 'secenekler' => ['Varsayılan' => 'Varsayılan', 'Yaygın' => 'Yaygın', 'Destansı' => 'Destansı', 'Efsanevi' => 'Efsanevi']],
                'desen' => ['tip' => 'metin', 'etiket' => 'Desen', 'ipucu' => 'Ör. Kamuflaj, Çizgili, Kaplama', 'uzunluk' => 40],
                'efekt' => ['tip' => 'metin', 'etiket' => 'Efekt', 'ipucu' => 'Ör. Kayan parıltı, Akan neon, Nabız + kor', 'uzunluk' => 40],
                'renkler' => ['tip' => 'metin', 'etiket' => 'Renk paleti', 'ipucu' => 'Virgülle ayrılmış renk kodları: #ff800d,#0d0a08', 'uzunluk' => 255],
                'aura' => ['tip' => 'metin', 'etiket' => 'Aura rengi', 'ipucu' => 'Efsaneviler için ışık rengi (#ffbf4d). Boş = aura yok.', 'uzunluk' => 7],
                'sadece_bicak' => ['tip' => 'onay', 'etiket' => 'Sadece bıçağa çıkar'],
                'gorsel' => ['tip' => 'gorsel', 'etiket' => 'Görsel'],
                'aciklama' => ['tip' => 'uzun', 'etiket' => 'Açıklama', 'satir' => 3],
                'sira' => ['tip' => 'sayi', 'etiket' => 'Sıra', 'adim' => 1],
            ],
        ],
    ],

    'gorevler' => [
        'baslik' => 'Görevler', 'tekil' => 'görev', 'ikon' => 'gorev', 'ad' => 'kod_adi',
        'onizleme' => 'gorevler.php#gorev-',
        'liste' => ['kod_adi' => 'Kod adı', 'sablon' => 'Oyundaki yazı', 'tur' => 'Tür', 'zorluk' => 'Zorluk'],
        'gruplar' => [
            'Görev' => [
                'kod_adi' => ['tip' => 'metin', 'etiket' => 'Kod adı', 'zorunlu' => true, 'uzunluk' => 80],
                'slug' => ['tip' => 'slug', 'etiket' => 'Adres adı'],
                'sablon' => ['tip' => 'metin', 'etiket' => 'Oyundaki yazı', 'zorunlu' => true, 'ipucu' => '{N} hedef sayısının yerine geçer: "{N} kafa vuruşu yap"', 'uzunluk' => 160],
                'tur' => ['tip' => 'secim', 'etiket' => 'Tür', 'secenekler' => ['anlik' => 'Anlık (hedefe ulaşınca biter)', 'dalga-sonu' => 'Dalga sonu (dalga bitince kazanılır)']],
                'kosul' => ['tip' => 'metin', 'etiket' => 'Çıkma koşulu', 'uzunluk' => 200],
                'zorluk' => ['tip' => 'sayi', 'etiket' => 'Zorluk (1–5)', 'adim' => 1, 'min' => 1, 'max' => 5],
                'ikon' => ['tip' => 'secim', 'etiket' => 'İkon', 'secenekler' => $ikonSecenek],
                'sira' => ['tip' => 'sayi', 'etiket' => 'Sıra', 'adim' => 1],
            ],
            'Hedef formülü: taban + dalga ÷ bölen + dalga × çarpan (en fazla tavan)' => [
                'hedef_taban' => ['tip' => 'sayi', 'etiket' => 'Taban', 'adim' => 1, 'min' => 0],
                'hedef_bolen' => ['tip' => 'sayi', 'etiket' => 'Bölen', 'adim' => 1, 'min' => 0, 'ipucu' => '0 = kullanılmaz'],
                'hedef_carpan' => ['tip' => 'sayi', 'etiket' => 'Çarpan', 'adim' => 0.01, 'min' => 0, 'ipucu' => '0 = kullanılmaz'],
                'hedef_tavan' => ['tip' => 'sayi', 'etiket' => 'Tavan', 'adim' => 1, 'min' => 0, 'ipucu' => '0 = sınırsız'],
            ],
            'Metinler' => [
                'aciklama' => ['tip' => 'uzun', 'etiket' => 'Açıklama', 'satir' => 3],
                'ipucu' => ['tip' => 'uzun', 'etiket' => 'İpucu', 'satir' => 2],
            ],
        ],
    ],

    'genel' => [
        'baslik' => 'Genel bilgiler', 'tekil' => 'sayfa', 'ikon' => 'genel', 'ad' => 'baslik', 'klasor' => 'genel',
        'onizleme' => 'genel.php?s=',
        'liste' => ['baslik' => 'Başlık', 'kategori' => 'Kategori', 'ozet' => 'Özet'],
        'gruplar' => [
            'Sayfa' => [
                'baslik' => ['tip' => 'metin', 'etiket' => 'Başlık', 'zorunlu' => true, 'uzunluk' => 150],
                'slug' => ['tip' => 'slug', 'etiket' => 'Adres adı'],
                'kategori' => ['tip' => 'metin', 'etiket' => 'Kategori', 'ipucu' => 'Aynı kategorideki sayfalar birlikte listelenir (Başlangıç, Oynanış, Sistemler, Ekstra…)', 'oneriler' => 'genel.kategori', 'uzunluk' => 60],
                'ikon' => ['tip' => 'secim', 'etiket' => 'İkon', 'secenekler' => $ikonSecenek],
                'ozet' => ['tip' => 'metin', 'etiket' => 'Özet', 'uzunluk' => 255],
                'gorsel' => ['tip' => 'gorsel', 'etiket' => 'Görsel (isteğe bağlı)'],
                'sira' => ['tip' => 'sayi', 'etiket' => 'Sıra', 'adim' => 1],
                'icerik' => ['tip' => 'uzun', 'etiket' => 'İçerik (Markdown)', 'satir' => 22],
            ],
        ],
    ],

    'zorluklar' => [
        'baslik' => 'Zorluklar', 'tekil' => 'zorluk', 'ikon' => 'kafatasi', 'ad' => 'ad', 'slugsuz' => true,
        'onizleme' => 'genel.php?s=zorluk-seviyeleri#',
        'liste' => ['ad' => 'Ad', 'can_carpani' => 'Can', 'hasar_carpani' => 'Hasar', 'hiz_carpani' => 'Hız', 'para_carpani' => 'Para'],
        'gruplar' => [
            'Zorluk' => [
                'ad' => ['tip' => 'metin', 'etiket' => 'Ad', 'zorunlu' => true, 'uzunluk' => 40],
                'aciklama' => ['tip' => 'metin', 'etiket' => 'Açıklama', 'uzunluk' => 255],
                'renk' => ['tip' => 'renk', 'etiket' => 'Renk'],
                'varsayilan' => ['tip' => 'onay', 'etiket' => 'Hesaplayıcılarda varsayılan'],
                'sira' => ['tip' => 'sayi', 'etiket' => 'Sıra', 'adim' => 1],
            ],
            'Çarpanlar' => [
                'can_carpani' => ['tip' => 'sayi', 'etiket' => 'Zombi canı', 'adim' => 0.01, 'min' => 0],
                'hasar_carpani' => ['tip' => 'sayi', 'etiket' => 'Zombi hasarı', 'adim' => 0.01, 'min' => 0],
                'hiz_carpani' => ['tip' => 'sayi', 'etiket' => 'Zombi hızı', 'adim' => 0.01, 'min' => 0],
                'sayi_carpani' => ['tip' => 'sayi', 'etiket' => 'Zombi sayısı', 'adim' => 0.01, 'min' => 0],
                'para_carpani' => ['tip' => 'sayi', 'etiket' => 'Para', 'adim' => 0.01, 'min' => 0],
                'anahtar_carpani' => ['tip' => 'sayi', 'etiket' => 'Anahtar şansı', 'adim' => 0.01, 'min' => 0],
                'us_carpani' => ['tip' => 'sayi', 'etiket' => 'Üs canı', 'adim' => 0.01, 'min' => 0],
            ],
        ],
    ],
];
