<?php
require __DIR__ . '/_baslat.php';
giris_gerekli();

if ($_SERVER['REQUEST_METHOD'] !== 'POST') yonlendir('index.php');
csrf_dogrula();

$t = (string)($_POST['t'] ?? '');
$id = (int)($_POST['id'] ?? 0);
$tablolar = tablolar();
if (!isset($tablolar[$t]) || $id <= 0) { bildirim('Geçersiz istek.', 'hata'); yonlendir('index.php'); }

$kayit = tek('SELECT * FROM `' . $t . '` WHERE id = ?', [$id]);
if (!$kayit) { bildirim('Kayıt zaten silinmiş.', 'hata'); yonlendir('liste.php?t=' . $t); }

if ($t === 'zorluklar' && (int)deger('SELECT COUNT(*) FROM zorluklar') <= 1) {
    bildirim('En az bir zorluk seviyesi kalmalı; hesaplayıcılar onu kullanıyor.', 'hata');
    yonlendir('liste.php?t=' . $t);
}

sorgu('DELETE FROM `' . $t . '` WHERE id = ?', [$id]);
$gorsel = (string)($kayit['gorsel'] ?? '');
if ($gorsel !== '' && str_starts_with($gorsel, 'uploads/') && !str_contains($gorsel, '..')) @unlink(KOK . '/' . $gorsel);

bildirim('“' . $kayit[$tablolar[$t]['ad']] . '” silindi.');
yonlendir('liste.php?t=' . $t);
