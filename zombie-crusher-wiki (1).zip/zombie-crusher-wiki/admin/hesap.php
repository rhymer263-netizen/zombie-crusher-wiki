<?php
require __DIR__ . '/_baslat.php';
$ben = giris_gerekli();

$hatalar = [];
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    csrf_dogrula();
    $islem = (string)($_POST['islem'] ?? '');

    if ($islem === 'sifre') {
        $kayit = tek('SELECT * FROM yoneticiler WHERE id = ?', [$ben['id']]);
        $eski = (string)($_POST['eski'] ?? '');
        $yeni = (string)($_POST['yeni'] ?? '');
        if (!$kayit || !password_verify($eski, $kayit['sifre_hash'])) $hatalar[] = 'Mevcut şifre yanlış.';
        elseif (mb_strlen($yeni) < 6) $hatalar[] = 'Yeni şifre en az 6 karakter olmalı.';
        elseif ($yeni !== (string)($_POST['yeni2'] ?? '')) $hatalar[] = 'Yeni şifreler aynı değil.';
        else {
            sorgu('UPDATE yoneticiler SET sifre_hash = ? WHERE id = ?', [password_hash($yeni, PASSWORD_DEFAULT), $ben['id']]);
            session_regenerate_id(true);
            bildirim('Şifren değiştirildi.');
            yonlendir('hesap.php');
        }
    } elseif ($islem === 'ekle') {
        $ad = trim((string)($_POST['kullanici'] ?? ''));
        $sifre = (string)($_POST['sifre'] ?? '');
        if (!preg_match('/^[A-Za-z0-9_.-]{3,30}$/', $ad)) $hatalar[] = 'Kullanıcı adı 3–30 karakter olmalı (harf, rakam, _ . -).';
        elseif (mb_strlen($sifre) < 6) $hatalar[] = 'Şifre en az 6 karakter olmalı.';
        elseif (tek('SELECT id FROM yoneticiler WHERE kullanici_adi = ?', [$ad])) $hatalar[] = 'Bu kullanıcı adı zaten var.';
        else {
            sorgu('INSERT INTO yoneticiler (kullanici_adi, sifre_hash) VALUES (?, ?)', [$ad, password_hash($sifre, PASSWORD_DEFAULT)]);
            bildirim('“' . $ad . '” yönetici olarak eklendi.');
            yonlendir('hesap.php');
        }
    } elseif ($islem === 'sil') {
        $id = (int)($_POST['id'] ?? 0);
        if ($id === (int)$ben['id']) $hatalar[] = 'Kendi hesabını silemezsin.';
        else {
            sorgu('DELETE FROM yoneticiler WHERE id = ?', [$id]);
            bildirim('Yönetici silindi.');
            yonlendir('hesap.php');
        }
    }
}

$yoneticiler = tumu('SELECT id, kullanici_adi, son_giris, olusturma FROM yoneticiler ORDER BY id');
admin_ust('Hesap ve yöneticiler', 'hesap');
?>
<div class="admin-bas"><div><span class="ust-yazi">Site</span><h1>Hesap ve yöneticiler</h1></div></div>
<?php if ($hatalar): ?><div class="bildirim bildirim-hata" role="alert"><?php foreach ($hatalar as $h): ?><div><?= e($h) ?></div><?php endforeach; ?></div><?php endif; ?>

<div class="admin-iki">
  <section class="admin-kutu">
    <h2>Şifremi değiştir</h2>
    <form method="post" class="form">
      <?= csrf_alani() ?><input type="hidden" name="islem" value="sifre">
      <label class="alan-dikey">Mevcut şifre<input class="girdi" type="password" name="eski" required autocomplete="current-password"></label>
      <label class="alan-dikey">Yeni şifre<input class="girdi" type="password" name="yeni" required minlength="6" autocomplete="new-password"></label>
      <label class="alan-dikey">Yeni şifre (tekrar)<input class="girdi" type="password" name="yeni2" required minlength="6" autocomplete="new-password"></label>
      <button class="dugme" type="submit"><?= ikon('kilit') ?>Şifreyi değiştir</button>
    </form>
  </section>
  <section class="admin-kutu">
    <h2>Yöneticiler</h2>
    <table class="tablo">
      <thead><tr><th>Kullanıcı</th><th>Son giriş</th><th class="s"></th></tr></thead>
      <tbody>
        <?php foreach ($yoneticiler as $y): ?>
          <tr>
            <td><b><?= e($y['kullanici_adi']) ?></b><?= (int)$y['id'] === (int)$ben['id'] ? ' <span class="cip">sen</span>' : '' ?></td>
            <td><?= $y['son_giris'] ? e(date('d.m.Y H:i', strtotime($y['son_giris']))) : '—' ?></td>
            <td class="s"><?php if ((int)$y['id'] !== (int)$ben['id']): ?>
              <form method="post" data-onay="“<?= e($y['kullanici_adi']) ?>” yöneticiliği silinsin mi?"><?= csrf_alani() ?><input type="hidden" name="islem" value="sil"><input type="hidden" name="id" value="<?= (int)$y['id'] ?>"><button class="ikon-dugme tehlike" type="submit" title="Sil"><?= ikon('sil') ?><span class="gizli">Sil</span></button></form>
            <?php endif; ?></td>
          </tr>
        <?php endforeach; ?>
      </tbody>
    </table>
    <h2 style="margin-top:22px">Yeni yönetici ekle</h2>
    <form method="post" class="form">
      <?= csrf_alani() ?><input type="hidden" name="islem" value="ekle">
      <label class="alan-dikey">Kullanıcı adı<input class="girdi" name="kullanici" required pattern="[A-Za-z0-9_.\-]{3,30}" autocomplete="off"></label>
      <label class="alan-dikey">Şifre<input class="girdi" type="password" name="sifre" required minlength="6" autocomplete="new-password"></label>
      <button class="dugme ikincil" type="submit"><?= ikon('arti') ?>Yönetici ekle</button>
    </form>
  </section>
</div>
<?php admin_alt();
