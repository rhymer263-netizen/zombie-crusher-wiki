<?php
require __DIR__ . '/_baslat.php';
giris_gerekli();

$t = (string)($_GET['t'] ?? '');
$tablolar = tablolar();
if (!isset($tablolar[$t])) { bildirim('Böyle bir bölüm yok.', 'hata'); yonlendir('index.php'); }
$tanim = $tablolar[$t];
$adAlani = $tanim['ad'];
$id = (int)($_GET['id'] ?? 0);

$kayit = $id > 0 ? tek('SELECT * FROM `' . $t . '` WHERE id = ?', [$id]) : null;
if ($id > 0 && !$kayit) { bildirim('Kayıt bulunamadı.', 'hata'); yonlendir('liste.php?t=' . $t); }

// Bütün alanlar (grup sırasıyla)
$alanlar = [];
foreach ($tanim['gruplar'] as $grup => $liste) foreach ($liste as $ad => $a) $alanlar[$ad] = $a;

// Varsayılan değerler
$degerler = [];
foreach ($alanlar as $ad => $a) {
    switch ($a['tip']) {
        case 'sayi': $degerler[$ad] = $ad === 'sira' ? ((int)deger('SELECT COALESCE(MAX(sira), 0) FROM `' . $t . '`') + 10) : ($a['min'] ?? 0); break;
        case 'onay': $degerler[$ad] = 0; break;
        case 'secim': $degerler[$ad] = (string)array_key_first($a['secenekler']); break;
        case 'renk': $degerler[$ad] = '#d8402f'; break;
        default: $degerler[$ad] = '';
    }
}
if ($t === 'silahlar' && !$kayit) { $degerler['sacma'] = 1; $degerler['delme'] = 1; $degerler['nisan'] = 1; $degerler['hareket'] = 1; $degerler['menzil'] = 45; }
if ($t === 'yaratiklar' && !$kayit) { $degerler['boyut'] = 1; $degerler['ilk_dalga'] = 1; $degerler['fark_etme'] = 7; $degerler['tehdit'] = 1; $degerler['saldiri_araligi'] = 1; }
if ($t === 'zorluklar' && !$kayit) foreach (['can_carpani', 'hasar_carpani', 'hiz_carpani', 'sayi_carpani', 'para_carpani', 'anahtar_carpani', 'us_carpani'] as $k) $degerler[$k] = 1;
if ($t === 'bombalar' && !$kayit) $degerler['adet'] = 3;
if ($kayit) foreach ($alanlar as $ad => $a) $degerler[$ad] = $kayit[$ad] ?? $degerler[$ad];

$hatalar = [];

/** Yüklenen görseli doğrular ve uploads/ klasörüne taşır. */
function gorsel_yukle(array $dosya, string $onek): string
{
    if ($dosya['error'] === UPLOAD_ERR_INI_SIZE || $dosya['error'] === UPLOAD_ERR_FORM_SIZE) throw new RuntimeException('Görsel çok büyük (php.ini sınırı).');
    if ($dosya['error'] !== UPLOAD_ERR_OK) throw new RuntimeException('Görsel yüklenemedi (hata kodu ' . (int)$dosya['error'] . ').');
    if ($dosya['size'] > YUKLEME_SINIRI) throw new RuntimeException('Görsel en fazla ' . round(YUKLEME_SINIRI / 1048576) . ' MB olabilir.');
    $izinli = ['image/png' => 'png', 'image/jpeg' => 'jpg', 'image/webp' => 'webp', 'image/gif' => 'gif'];
    $tur = function_exists('finfo_open') ? (string)finfo_file(finfo_open(FILEINFO_MIME_TYPE), $dosya['tmp_name']) : (string)(getimagesize($dosya['tmp_name'])['mime'] ?? '');
    if (!isset($izinli[$tur]) || @getimagesize($dosya['tmp_name']) === false) throw new RuntimeException('Sadece PNG, JPG, WEBP ya da GIF görsel yüklenebilir.');
    $klasor = KOK . '/uploads';
    if (!is_dir($klasor) && !@mkdir($klasor, 0775, true)) throw new RuntimeException('uploads klasörü oluşturulamadı.');
    $ad = $onek . '-' . bin2hex(random_bytes(5)) . '.' . $izinli[$tur];
    if (!move_uploaded_file($dosya['tmp_name'], $klasor . '/' . $ad)) throw new RuntimeException('Görsel kaydedilemedi (uploads klasörüne yazma izni var mı?).');
    return 'uploads/' . $ad;
}

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    csrf_dogrula();
    $eskiGorsel = (string)($kayit['gorsel'] ?? '');

    foreach ($alanlar as $ad => $a) {
        $etiket = $a['etiket'];
        switch ($a['tip']) {
            case 'metin':
            case 'slug':
                $v = trim(preg_replace('/\s+/u', ' ', (string)($_POST[$ad] ?? '')));
                if (!empty($a['uzunluk']) && mb_strlen($v) > $a['uzunluk']) $hatalar[] = "“$etiket” en fazla {$a['uzunluk']} karakter olabilir.";
                break;
            case 'uzun':
                $v = str_replace(["\r\n", "\r"], "\n", (string)($_POST[$ad] ?? ''));
                $v = rtrim($v);
                break;
            case 'sayi':
                $v = str_replace(',', '.', trim((string)($_POST[$ad] ?? '')));
                if ($v === '') $v = '0';
                if (!is_numeric($v)) { $hatalar[] = "“$etiket” bir sayı olmalı."; break; }
                $v = $v + 0;
                if (isset($a['min']) && $v < $a['min']) $hatalar[] = "“$etiket” en az {$a['min']} olabilir.";
                if (isset($a['max']) && $v > $a['max']) $hatalar[] = "“$etiket” en fazla {$a['max']} olabilir.";
                break;
            case 'secim':
                $v = (string)($_POST[$ad] ?? '');
                if (!array_key_exists($v, $a['secenekler'])) $hatalar[] = "“$etiket” için geçerli bir seçenek seç.";
                break;
            case 'onay':
                $v = !empty($_POST[$ad]) ? 1 : 0;
                break;
            case 'renk':
                $v = strtolower(trim((string)($_POST[$ad] ?? '')));
                if (!preg_match('/^#[0-9a-f]{6}$/', $v)) $hatalar[] = "“$etiket” #rrggbb biçiminde bir renk olmalı.";
                break;
            case 'gorsel':
                $v = trim((string)($_POST[$ad] ?? ''));
                if ($v !== '' && (!preg_match('#^(assets/img|uploads)/[A-Za-z0-9_\-./]+$#', $v) || str_contains($v, '..') || !is_file(KOK . '/' . $v))) {
                    $hatalar[] = "“$etiket” yolu bulunamadı: $v";
                }
                if (!empty($_POST[$ad . '_kaldir'])) $v = '';
                break;
            default:
                $v = (string)($_POST[$ad] ?? '');
        }
        $degerler[$ad] = $v;
        if (!empty($a['zorunlu']) && trim((string)$v) === '') $hatalar[] = "“$etiket” boş bırakılamaz.";
    }

    // Skin aura rengi isteğe bağlı ama girilirse renk kodu olmalı
    if ($t === 'skinler' && $degerler['aura'] !== '' && !preg_match('/^#[0-9a-fA-F]{6}$/', $degerler['aura'])) $hatalar[] = '“Aura rengi” #rrggbb biçiminde olmalı ya da boş bırakılmalı.';

    // Adres adı: boşsa addan üret, benzersiz yap
    if (isset($alanlar['slug']) && !$hatalar) {
        $s = slugla($degerler['slug'] !== '' ? $degerler['slug'] : (string)$degerler[$adAlani]);
        $taban = $s; $k = 2;
        while ((int)deger('SELECT COUNT(*) FROM `' . $t . '` WHERE slug = ? AND id <> ?', [$s, $id]) > 0) $s = $taban . '-' . $k++;
        $degerler['slug'] = $s;
    }

    // Görsel yükleme
    if (!$hatalar && isset($alanlar['gorsel']) && !empty($_FILES['gorsel_dosya']) && $_FILES['gorsel_dosya']['error'] !== UPLOAD_ERR_NO_FILE) {
        try {
            $degerler['gorsel'] = gorsel_yukle($_FILES['gorsel_dosya'], ($tanim['klasor'] ?? $t) . '-' . ($degerler['slug'] ?? 'gorsel'));
        } catch (RuntimeException $h) {
            $hatalar[] = $h->getMessage();
        }
    }

    if (!$hatalar) {
        $sutunlar = array_keys($alanlar);
        try {
            if ($kayit) {
                $set = implode(', ', array_map(function ($c) { return '`' . $c . '` = ?'; }, $sutunlar));
                sorgu('UPDATE `' . $t . '` SET ' . $set . ' WHERE id = ?', array_merge(array_map(function ($c) use ($degerler) { return $degerler[$c]; }, $sutunlar), [$id]));
            } else {
                sorgu('INSERT INTO `' . $t . '` (`' . implode('`, `', $sutunlar) . '`) VALUES (' . implode(', ', array_fill(0, count($sutunlar), '?')) . ')',
                    array_map(function ($c) use ($degerler) { return $degerler[$c]; }, $sutunlar));
                $id = (int)db()->lastInsertId();
            }
            if ($t === 'zorluklar' && (int)$degerler['varsayilan'] === 1) sorgu('UPDATE zorluklar SET varsayilan = 0 WHERE id <> ?', [$id]);
            // Değiştirilen eski yüklemeyi sil (sadece uploads/ içindekiler)
            if (isset($alanlar['gorsel']) && $eskiGorsel !== '' && $eskiGorsel !== $degerler['gorsel'] && str_starts_with($eskiGorsel, 'uploads/') && !str_contains($eskiGorsel, '..')) {
                @unlink(KOK . '/' . $eskiGorsel);
            }
            bildirim('“' . $degerler[$adAlani] . '” kaydedildi.');
            yonlendir('duzenle.php?t=' . rawurlencode($t) . '&id=' . $id);
        } catch (PDOException $h) {
            $hatalar[] = 'Kaydedilemedi: ' . $h->getMessage();
        }
    }
}

$oneriler = [];
foreach ($alanlar as $ad => $a) {
    if (!empty($a['oneriler'])) {
        [$ot, $os] = explode('.', $a['oneriler']);
        if (isset($tablolar[$ot])) $oneriler[$ad] = array_column(tumu('SELECT DISTINCT `' . $os . '` AS d FROM `' . $ot . '` ORDER BY d'), 'd');
    }
}

$baslik = $kayit ? (string)$kayit[$adAlani] : 'Yeni ' . $tanim['tekil'];
admin_ust($baslik, $t);
?>
<div class="admin-bas">
  <div><span class="ust-yazi"><a href="liste.php?t=<?= e($t) ?>"><?= e($tanim['baslik']) ?></a> / <?= $kayit ? 'Düzenle' : 'Yeni' ?></span><h1><?= e($baslik) ?></h1></div>
  <?php if ($kayit && !empty($tanim['onizleme'])): ?>
    <div class="admin-bas-sag"><a class="dugme ikincil" href="../<?= e($tanim['onizleme'] . (isset($kayit['slug']) ? rawurlencode($kayit['slug']) : '')) ?>" target="_blank" rel="noopener"><?= ikon('goz') ?>Sitede gör</a></div>
  <?php endif; ?>
</div>

<?php if ($hatalar): ?>
  <div class="bildirim bildirim-hata" role="alert"><b>Kaydedilmedi:</b><ul style="margin:6px 0 0;padding-left:18px"><?php foreach ($hatalar as $h): ?><li><?= e($h) ?></li><?php endforeach; ?></ul></div>
<?php endif; ?>

<form method="post" enctype="multipart/form-data" class="form duzenle-form" data-degisiklik-uyar>
  <?= csrf_alani() ?>
  <input type="hidden" name="MAX_FILE_SIZE" value="<?= (int)YUKLEME_SINIRI ?>">
  <?php foreach ($tanim['gruplar'] as $grup => $liste): ?>
    <fieldset class="admin-kutu alan-grubu">
      <legend><?= e($grup) ?></legend>
      <div class="alan-izgara">
        <?php foreach ($liste as $ad => $a): $v = $degerler[$ad]; $kimlik = 'a-' . $ad; ?>
          <?php if ($a['tip'] === 'uzun'): ?>
            <div class="alan-dikey genis">
              <div class="alan-ust"><label for="<?= $kimlik ?>"><?= e($a['etiket']) ?></label><button type="button" class="metin-dugme" data-onizle="<?= $kimlik ?>"><?= ikon('goz') ?>Önizle</button></div>
              <textarea class="girdi" id="<?= $kimlik ?>" name="<?= e($ad) ?>" rows="<?= (int)($a['satir'] ?? 4) ?>"><?= e($v) ?></textarea>
              <div class="onizleme yazi" data-onizleme-kutu="<?= $kimlik ?>" hidden></div>
              <?php if (!empty($a['ipucu'])): ?><small><?= e($a['ipucu']) ?></small><?php endif; ?>
            </div>
          <?php elseif ($a['tip'] === 'gorsel'): ?>
            <div class="alan-dikey genis">
              <label for="<?= $kimlik ?>"><?= e($a['etiket']) ?></label>
              <div class="gorsel-alani">
                <div class="gorsel-onizleme" data-gorsel-onizleme><?= gorsel((string)$v, '') ?: ikon('resim') ?></div>
                <div class="gorsel-girdiler">
                  <input class="girdi" type="file" name="gorsel_dosya" accept="image/png,image/jpeg,image/webp,image/gif" data-gorsel-dosya aria-label="Yeni görsel yükle">
                  <input class="girdi" id="<?= $kimlik ?>" name="<?= e($ad) ?>" value="<?= e($v) ?>" placeholder="assets/img/... ya da uploads/..." spellcheck="false">
                  <?php if ((string)$v !== ''): ?><label class="onay-alani"><input type="checkbox" name="<?= e($ad) ?>_kaldir" value="1"> Görseli kaldır</label><?php endif; ?>
                  <small>PNG, JPG, WEBP ya da GIF · en fazla <?= round(YUKLEME_SINIRI / 1048576) ?> MB. Şeffaf arka planlı görseller en iyi görünür.</small>
                </div>
              </div>
            </div>
          <?php elseif ($a['tip'] === 'onay'): ?>
            <label class="onay-alani"><input type="checkbox" name="<?= e($ad) ?>" value="1"<?= (int)$v ? ' checked' : '' ?>> <?= e($a['etiket']) ?></label>
          <?php else: ?>
            <div class="alan-dikey<?= in_array($ad, ['kisa_aciklama', 'ozet', 'sablon', 'kosul', 'cikma_sansi', 'renkler', 'etiketler', 'aciklama'], true) && $a['tip'] === 'metin' ? ' genis' : '' ?>">
              <label for="<?= $kimlik ?>"><?= e($a['etiket']) ?><?= !empty($a['zorunlu']) ? ' <span class="zorunlu">*</span>' : '' ?></label>
              <?php if ($a['tip'] === 'secim'): ?>
                <select class="girdi" id="<?= $kimlik ?>" name="<?= e($ad) ?>">
                  <?php foreach ($a['secenekler'] as $k => $etiket): ?><option value="<?= e($k) ?>"<?= (string)$k === (string)$v ? ' selected' : '' ?>><?= e($etiket) ?></option><?php endforeach; ?>
                </select>
              <?php elseif ($a['tip'] === 'sayi'): ?>
                <input class="girdi" id="<?= $kimlik ?>" type="number" name="<?= e($ad) ?>" value="<?= e($v) ?>" step="<?= e($a['adim'] ?? 'any') ?>"<?= isset($a['min']) ? ' min="' . e($a['min']) . '"' : '' ?><?= isset($a['max']) ? ' max="' . e($a['max']) . '"' : '' ?>>
              <?php elseif ($a['tip'] === 'renk'): ?>
                <span class="renk-alani"><input id="<?= $kimlik ?>" type="color" name="<?= e($ad) ?>" value="<?= e($v ?: '#d8402f') ?>"><code><?= e($v) ?></code></span>
              <?php else: ?>
                <input class="girdi" id="<?= $kimlik ?>" name="<?= e($ad) ?>" value="<?= e($v) ?>"<?= !empty($a['uzunluk']) ? ' maxlength="' . (int)$a['uzunluk'] . '"' : '' ?><?= $a['tip'] === 'slug' ? ' placeholder="otomatik" spellcheck="false"' : '' ?><?= !empty($a['zorunlu']) ? ' required' : '' ?><?= isset($oneriler[$ad]) ? ' list="o-' . e($ad) . '"' : '' ?>>
                <?php if (isset($oneriler[$ad])): ?><datalist id="o-<?= e($ad) ?>"><?php foreach ($oneriler[$ad] as $o): ?><option value="<?= e($o) ?>"><?php endforeach; ?></datalist><?php endif; ?>
              <?php endif; ?>
              <?php if (!empty($a['ipucu'])): ?><small><?= e($a['ipucu']) ?></small><?php endif; ?>
            </div>
          <?php endif; ?>
        <?php endforeach; ?>
      </div>
    </fieldset>
  <?php endforeach; ?>

  <div class="kaydet-cubugu">
    <button class="dugme" type="submit"><?= ikon('indir') ?>Kaydet</button>
    <a class="dugme ikincil" href="liste.php?t=<?= e($t) ?>">Listeye dön</a>
    <?php if ($kayit): ?><span class="kaydet-not">Son güncelleme: <?= isset($kayit['guncelleme']) ? e(date('d.m.Y H:i', strtotime($kayit['guncelleme']))) : '—' ?></span><?php endif; ?>
  </div>
</form>

<?php if ($kayit): ?>
  <form method="post" action="sil.php" class="sil-formu" data-onay="“<?= e($kayit[$adAlani]) ?>” silinsin mi? Bu işlem geri alınamaz.">
    <?= csrf_alani() ?><input type="hidden" name="t" value="<?= e($t) ?>"><input type="hidden" name="id" value="<?= (int)$id ?>">
    <button class="dugme ikincil kucuk tehlike" type="submit"><?= ikon('sil') ?>Bu kaydı sil</button>
  </form>
<?php endif; ?>
<?php admin_alt();
