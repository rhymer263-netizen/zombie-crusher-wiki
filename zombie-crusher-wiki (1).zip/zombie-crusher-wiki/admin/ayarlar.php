<?php
require __DIR__ . '/_baslat.php';
giris_gerekli();

// anahtar => [etiket, tür (metin|uzun|sayi), ipucu]
$gruplar = [
    'Site' => [
        'site_adi'   => ['Site adı', 'metin', 'Tarayıcı sekmesinde görünür.'],
        'oyun_adi'   => ['Oyunun adı', 'metin', ''],
        'alt_baslik' => ['Logo alt yazısı', 'metin', 'Ör. Saha Arşivi'],
        'hero_metin' => ['Ana sayfa tanıtım yazısı', 'uzun', ''],
        'duyuru'     => ['Duyuru (ana sayfa)', 'metin', 'Boş bırakırsan duyuru gizlenir.'],
        'alt_bilgi'  => ['Alt bilgi yazısı', 'metin', ''],
    ],
    'Oyun formülleri (hesaplayıcılar)' => [
        'f_dalga_can'         => ['Her dalga can artışı', 'sayi', '0.13 = %13'],
        'f_dalga_hiz'         => ['Her dalga hız artışı', 'sayi', '0.022 = %2,2'],
        'f_hiz_tavan'         => ['Hız çarpanı tavanı', 'sayi', '1.7'],
        'f_hasar_bolen'       => ['Hasar artışı böleni', 'sayi', 'Hasar artışı = can artışı ÷ bu sayı (3.5)'],
        'f_hasar_carpan'      => ['Genel hasar çarpanı', 'sayi', '0.92'],
        'f_gece_can'          => ['Gece can çarpanı', 'sayi', '1.12'],
        'f_gece_hiz'          => ['Gece hız çarpanı', 'sayi', '1.08'],
        'f_gece_para'         => ['Gece para çarpanı', 'sayi', '1.2'],
        'f_kafa_carpan'       => ['Kafa vuruşu çarpanı', 'sayi', '2'],
        'f_zombi_sayi_taban'  => ['Zombi sayısı: taban', 'sayi', 'Sayı = taban + dalga × artış'],
        'f_zombi_sayi_dalga'  => ['Zombi sayısı: dalga başı artış', 'sayi', '2.7'],
        'f_dalga_bonus_taban' => ['Dalga bonusu: taban ($)', 'sayi', '60'],
        'f_dalga_bonus_dalga' => ['Dalga bonusu: dalga başı ($)', 'sayi', '18'],
        'f_gorev_odul_taban'  => ['Görev ödülü: taban ($)', 'sayi', '120'],
        'f_gorev_odul_dalga'  => ['Görev ödülü: dalga başı ($)', 'sayi', '20'],
        'f_gorev_anahtar_sans'=> ['Görev anahtar şansı', 'sayi', '0.3 = %30'],
        'f_gorev_anahtar_para'=> ['Anahtarlı ödülde para oranı', 'sayi', '0.4 = %40'],
    ],
    'Kasa' => [
        'kasa_yaygin'    => ['Yaygın şansı (%)', 'sayi', ''],
        'kasa_destansi'  => ['Destansı şansı (%)', 'sayi', ''],
        'kasa_efsanevi'  => ['Efsanevi şansı (%)', 'sayi', ''],
        'kopya_yaygin'   => ['Yaygın kopya parası ($)', 'sayi', ''],
        'kopya_destansi' => ['Destansı kopya parası ($)', 'sayi', ''],
        'kopya_efsanevi' => ['Efsanevi kopya parası ($)', 'sayi', ''],
    ],
];

$mevcut = [];
foreach (tumu('SELECT anahtar, deger FROM ayarlar') as $r) $mevcut[$r['anahtar']] = $r['deger'];
$hatalar = [];

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    csrf_dogrula();
    $yeni = [];
    foreach ($gruplar as $alanlar) {
        foreach ($alanlar as $k => $a) {
            $v = (string)($_POST[$k] ?? '');
            $v = $a[1] === 'uzun' ? trim(str_replace(["\r\n", "\r"], "\n", $v)) : trim(preg_replace('/\s+/u', ' ', $v));
            if ($a[1] === 'sayi') {
                $v = str_replace(',', '.', $v);
                if (!is_numeric($v) || (float)$v < 0) { $hatalar[] = '“' . $a[0] . '” sıfır ya da pozitif bir sayı olmalı.'; continue; }
            }
            $yeni[$k] = $v;
        }
    }
    if (!$hatalar && isset($yeni['kasa_yaygin'])) {
        $toplam = (float)$yeni['kasa_yaygin'] + (float)$yeni['kasa_destansi'] + (float)$yeni['kasa_efsanevi'];
        if (abs($toplam - 100) > 0.01) $hatalar[] = 'Kasa şanslarının toplamı 100 olmalı (şu an ' . sayi($toplam) . ').';
    }
    if (!$hatalar) {
        $s = db()->prepare('INSERT INTO ayarlar (anahtar, deger) VALUES (?, ?) ON DUPLICATE KEY UPDATE deger = VALUES(deger)');
        foreach ($yeni as $k => $v) $s->execute([$k, $v]);
        bildirim('Ayarlar kaydedildi.');
        yonlendir('ayarlar.php');
    }
    $mevcut = array_merge($mevcut, $yeni);
}

admin_ust('Site ayarları', 'ayarlar');
?>
<div class="admin-bas"><div><span class="ust-yazi">Site</span><h1>Site ayarları</h1></div></div>
<?php if ($hatalar): ?><div class="bildirim bildirim-hata" role="alert"><?php foreach ($hatalar as $h): ?><div><?= e($h) ?></div><?php endforeach; ?></div><?php endif; ?>

<form method="post" class="form" data-degisiklik-uyar>
  <?= csrf_alani() ?>
  <?php foreach ($gruplar as $grup => $alanlar): ?>
    <fieldset class="admin-kutu alan-grubu">
      <legend><?= e($grup) ?></legend>
      <?php if (str_starts_with($grup, 'Oyun')): ?><p class="hesap-not" style="margin:0 0 14px">Oyunda dengeyi değiştirirsen buradaki sayıları da güncelle; yaratık, silah ve görev hesaplayıcıları bu formülleri kullanır. Ondalık ayırıcı olarak nokta ya da virgül kullanabilirsin.</p><?php endif; ?>
      <div class="alan-izgara">
        <?php foreach ($alanlar as $k => $a): $kimlik = 'a-' . $k; ?>
          <div class="alan-dikey<?= $a[1] === 'uzun' || in_array($k, ['duyuru', 'alt_bilgi'], true) ? ' genis' : '' ?>">
            <label for="<?= $kimlik ?>"><?= e($a[0]) ?></label>
            <?php if ($a[1] === 'uzun'): ?>
              <textarea class="girdi" id="<?= $kimlik ?>" name="<?= e($k) ?>" rows="3"><?= e($mevcut[$k] ?? '') ?></textarea>
            <?php else: ?>
              <input class="girdi" id="<?= $kimlik ?>" name="<?= e($k) ?>" value="<?= e($mevcut[$k] ?? '') ?>"<?= $a[1] === 'sayi' ? ' inputmode="decimal"' : '' ?>>
            <?php endif; ?>
            <?php if ($a[2] !== ''): ?><small><?= e($a[2]) ?></small><?php endif; ?>
          </div>
        <?php endforeach; ?>
      </div>
    </fieldset>
  <?php endforeach; ?>
  <div class="kaydet-cubugu"><button class="dugme" type="submit"><?= ikon('indir') ?>Ayarları kaydet</button></div>
</form>
<?php admin_alt();
