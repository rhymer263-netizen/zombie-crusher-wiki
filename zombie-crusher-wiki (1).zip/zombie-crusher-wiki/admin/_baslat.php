<?php
/*
 * Yönetim paneli ortak başlangıcı: giriş kontrolü ve panel iskeleti.
 */
define('ADMIN', true);
require dirname(__DIR__) . '/inc/baslat.php';

header('X-Frame-Options: DENY');
header('Cache-Control: no-store');

function giris_gerekli(): array
{
    $y = yonetici();
    if (!$y) {
        bildirim('Devam etmek için giriş yap.', 'hata');
        yonlendir('giris.php');
    }
    // Hesap silindiyse oturumu kapat
    if (!tek('SELECT id FROM yoneticiler WHERE id = ?', [$y['id']])) {
        $_SESSION = [];
        yonlendir('giris.php');
    }
    return $y;
}

function tablolar(): array
{
    static $t = null;
    if ($t === null) $t = require __DIR__ . '/tablolar.php';
    return $t;
}

function admin_ust(string $baslik, string $aktif = ''): void
{
    $y = yonetici();
    ?>
<!doctype html>
<html lang="tr">
<head>
<meta charset="utf-8">
<meta name="viewport" content="width=device-width, initial-scale=1">
<meta name="robots" content="noindex">
<title><?= e($baslik) ?> · Yönetim · <?= e(ayar('site_adi', 'Zombie Crusher Wiki')) ?></title>
<link rel="icon" href="<?= e(varlik('assets/img/favicon.svg')) ?>" type="image/svg+xml">
<link rel="stylesheet" href="<?= e(varlik('assets/css/site.css')) ?>">
<link rel="stylesheet" href="<?= e(varlik('assets/css/admin.css')) ?>">
</head>
<body class="admin">
<header class="ust">
  <div class="ust-ic">
    <a class="logo" href="index.php"><?= logo_svg() ?><span class="logo-yazi"><b>ZOMBIE <span>CRUSHER</span></b><small>YÖNETİM PANELİ</small></span></a>
    <?php if ($y): ?>
    <div class="admin-ust-sag">
      <a class="dugme ikincil kucuk" href="../index.php" target="_blank" rel="noopener"><?= ikon('goz') ?>Siteyi gör</a>
      <span class="admin-kullanici"><?= ikon('kullanici') ?><?= e($y['kullanici_adi']) ?></span>
      <form method="post" action="cikis.php"><?= csrf_alani() ?><button class="dugme ikincil kucuk" type="submit"><?= ikon('cikis') ?>Çıkış</button></form>
    </div>
    <?php endif; ?>
  </div>
</header>
<?php if ($y): ?>
<div class="admin-duzen">
  <nav class="admin-yan" aria-label="Yönetim menüsü">
    <a href="index.php" class="<?= $aktif === 'panel' ? 'aktif' : '' ?>"><?= ikon('ev') ?>Panel</a>
    <span class="baslik">İçerik</span>
    <?php foreach (tablolar() as $ad => $t): ?>
      <a href="liste.php?t=<?= e($ad) ?>" class="<?= $aktif === $ad ? 'aktif' : '' ?>"><?= ikon($t['ikon']) ?><?= e($t['baslik']) ?><span class="say"><?= (int)deger('SELECT COUNT(*) FROM `' . $ad . '`') ?></span></a>
    <?php endforeach; ?>
    <span class="baslik">Site</span>
    <a href="ayarlar.php" class="<?= $aktif === 'ayarlar' ? 'aktif' : '' ?>"><?= ikon('ayar') ?>Site ayarları</a>
    <a href="hesap.php" class="<?= $aktif === 'hesap' ? 'aktif' : '' ?>"><?= ikon('kilit') ?>Hesap ve yöneticiler</a>
  </nav>
  <main class="admin-icerik" id="icerik">
<?php else: ?>
<main class="admin-giris" id="icerik">
<?php endif;
    echo bildirimleri_yaz();
}

function admin_alt(): void
{
    ?>
  </main>
<?php if (yonetici()): ?></div><?php endif; ?>
<script src="<?= e(varlik('assets/js/admin.js')) ?>" defer></script>
</body>
</html>
<?php
}
