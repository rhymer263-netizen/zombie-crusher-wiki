<?php
require __DIR__ . '/_baslat.php';
$ben = giris_gerekli();

$son = tumu("
    (SELECT 'yaratiklar' AS t, id, ad, guncelleme FROM yaratiklar)
    UNION ALL (SELECT 'silahlar', id, ad, guncelleme FROM silahlar)
    UNION ALL (SELECT 'bombalar', id, ad, guncelleme FROM bombalar)
    UNION ALL (SELECT 'skinler', id, ad, guncelleme FROM skinler)
    UNION ALL (SELECT 'gorevler', id, kod_adi, guncelleme FROM gorevler)
    UNION ALL (SELECT 'genel', id, baslik, guncelleme FROM genel)
    ORDER BY guncelleme DESC LIMIT 10");
$eksikGorsel = (int)deger("SELECT COUNT(*) FROM yaratiklar WHERE gorsel = ''") + (int)deger("SELECT COUNT(*) FROM silahlar WHERE gorsel = ''");
$kilitVar = is_file(KOK . '/kurulum.kilit');

admin_ust('Panel', 'panel');
?>
<div class="admin-bas">
  <div><span class="ust-yazi">Hoş geldin, <?= e($ben['kullanici_adi']) ?></span><h1>Yönetim paneli</h1></div>
</div>

<?php if (!$kilitVar && is_file(KOK . '/kurulum.php')): ?>
  <div class="bildirim bildirim-hata">Güvenlik: <code>kurulum.php</code> kilitli değil. Kurulum sihirbazını tekrar çalıştırırsan veritabanı sıfırlanabilir; işin bittiyse dosyayı silebilirsin.</div>
<?php endif; ?>

<div class="panel-izgara">
  <?php foreach (tablolar() as $ad => $t): $n = (int)deger('SELECT COUNT(*) FROM `' . $ad . '`'); ?>
    <a class="panel-kart" href="liste.php?t=<?= e($ad) ?>">
      <span class="simge"><?= ikon($t['ikon']) ?></span>
      <b><?= $n ?></b>
      <span><?= e($t['baslik']) ?></span>
    </a>
  <?php endforeach; ?>
</div>

<div class="admin-iki">
  <section class="admin-kutu">
    <h2>Son düzenlenenler</h2>
    <table class="tablo">
      <thead><tr><th>Kayıt</th><th>Bölüm</th><th class="s">Tarih</th></tr></thead>
      <tbody>
        <?php foreach ($son as $r): $t = tablolar()[$r['t']]; ?>
          <tr><td><a href="duzenle.php?t=<?= e($r['t']) ?>&amp;id=<?= (int)$r['id'] ?>"><?= e($r['ad']) ?></a></td><td><?= e($t['baslik']) ?></td><td class="s"><?= e(date('d.m.Y H:i', strtotime($r['guncelleme']))) ?></td></tr>
        <?php endforeach; ?>
      </tbody>
    </table>
  </section>
  <section class="admin-kutu">
    <h2>Hızlı işlemler</h2>
    <div class="hizli">
      <a class="dugme kucuk" href="duzenle.php?t=yaratiklar"><?= ikon('arti') ?>Yaratık ekle</a>
      <a class="dugme kucuk" href="duzenle.php?t=silahlar"><?= ikon('arti') ?>Silah ekle</a>
      <a class="dugme kucuk" href="duzenle.php?t=skinler"><?= ikon('arti') ?>Skin ekle</a>
      <a class="dugme kucuk" href="duzenle.php?t=genel"><?= ikon('arti') ?>Sayfa ekle</a>
      <a class="dugme ikincil kucuk" href="ayarlar.php"><?= ikon('ayar') ?>Site ayarları</a>
    </div>
    <h2 style="margin-top:22px">İpuçları</h2>
    <ul class="admin-liste">
      <li>Uzun metin alanlarında <b>Markdown</b> kullanabilirsin: <code>**kalın**</code>, <code>## Başlık</code>, <code>- liste</code>, <code>| tablo |</code> ve <code>[[Tank]]</code> gibi wiki bağlantıları.</li>
      <li>Oyunda bir değeri değiştirdiysen (ör. zombi canı artışı) <a href="ayarlar.php">Site ayarları → Oyun formülleri</a> bölümünden hesaplayıcıları güncelle.</li>
      <?php if ($eksikGorsel > 0): ?><li><?= $eksikGorsel ?> yaratık/silahın görseli yok; düzenleme sayfasından yükleyebilirsin.</li><?php endif; ?>
    </ul>
  </section>
</div>
<?php admin_alt();
