<?php
require __DIR__ . '/_baslat.php';

if (yonetici()) yonlendir('index.php');

$hic_yok = (int)deger('SELECT COUNT(*) FROM yoneticiler') === 0;
$hata = '';
$kullanici = '';

// Basit deneme sınırı: 5 hatalı denemeden sonra 60 sn bekleme
$_SESSION['giris_deneme'] = $_SESSION['giris_deneme'] ?? ['say' => 0, 'zaman' => 0];
$bekle = $_SESSION['giris_deneme']['say'] >= 5 ? max(0, 60 - (time() - $_SESSION['giris_deneme']['zaman'])) : 0;
if ($bekle === 0 && $_SESSION['giris_deneme']['say'] >= 5) $_SESSION['giris_deneme'] = ['say' => 0, 'zaman' => 0];

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    csrf_dogrula();
    $kullanici = trim((string)($_POST['kullanici'] ?? ''));
    $sifre = (string)($_POST['sifre'] ?? '');

    if ($hic_yok) {
        // İlk yönetici hesabını oluştur (database.sql elle içe aktarıldıysa)
        $sifre2 = (string)($_POST['sifre2'] ?? '');
        if (!preg_match('/^[A-Za-z0-9_.-]{3,30}$/', $kullanici)) $hata = 'Kullanıcı adı 3–30 karakter olmalı (harf, rakam, _ . -).';
        elseif (mb_strlen($sifre) < 6) $hata = 'Şifre en az 6 karakter olmalı.';
        elseif ($sifre !== $sifre2) $hata = 'Şifreler aynı değil.';
        else {
            sorgu('INSERT INTO yoneticiler (kullanici_adi, sifre_hash) VALUES (?, ?)', [$kullanici, password_hash($sifre, PASSWORD_DEFAULT)]);
            bildirim('Yönetici hesabı oluşturuldu. Şimdi giriş yapabilirsin.');
            yonlendir('giris.php');
        }
    } elseif ($bekle > 0) {
        $hata = 'Çok fazla hatalı deneme. ' . $bekle . ' saniye sonra tekrar dene.';
    } else {
        $y = tek('SELECT * FROM yoneticiler WHERE kullanici_adi = ?', [$kullanici]);
        if ($y && password_verify($sifre, $y['sifre_hash'])) {
            session_regenerate_id(true);
            $_SESSION['yonetici'] = ['id' => (int)$y['id'], 'kullanici_adi' => $y['kullanici_adi']];
            $_SESSION['giris_deneme'] = ['say' => 0, 'zaman' => 0];
            unset($_SESSION['csrf']);
            if (password_needs_rehash($y['sifre_hash'], PASSWORD_DEFAULT)) {
                sorgu('UPDATE yoneticiler SET sifre_hash = ? WHERE id = ?', [password_hash($sifre, PASSWORD_DEFAULT), $y['id']]);
            }
            sorgu('UPDATE yoneticiler SET son_giris = NOW() WHERE id = ?', [$y['id']]);
            yonlendir('index.php');
        }
        usleep(400000);
        $_SESSION['giris_deneme']['say']++;
        $_SESSION['giris_deneme']['zaman'] = time();
        $hata = 'Kullanıcı adı ya da şifre yanlış.';
    }
}

admin_ust('Giriş');
?>
<div class="giris-kutu">
  <h1><?= $hic_yok ? 'İlk yönetici' : 'Yönetici girişi' ?></h1>
  <p class="giris-alt"><?= $hic_yok ? 'Henüz yönetici hesabı yok. Wikiyi düzenlemek için bir hesap oluştur.' : 'Wikiyi düzenlemek için giriş yap.' ?></p>
  <?php if ($hata !== ''): ?><div class="bildirim bildirim-hata" role="alert"><?= e($hata) ?></div><?php endif; ?>
  <form method="post" class="form">
    <?= csrf_alani() ?>
    <label class="alan-dikey">Kullanıcı adı<input class="girdi" name="kullanici" value="<?= e($kullanici) ?>" required autocomplete="username" autofocus></label>
    <label class="alan-dikey">Şifre<input class="girdi" type="password" name="sifre" required autocomplete="<?= $hic_yok ? 'new-password' : 'current-password' ?>"<?= $hic_yok ? ' minlength="6"' : '' ?>></label>
    <?php if ($hic_yok): ?><label class="alan-dikey">Şifre (tekrar)<input class="girdi" type="password" name="sifre2" required minlength="6" autocomplete="new-password"></label><?php endif; ?>
    <button class="dugme" type="submit"><?= ikon('kilit') ?><?= $hic_yok ? 'Hesabı oluştur' : 'Giriş yap' ?></button>
  </form>
  <p class="giris-alt"><a href="../index.php"><?= ikon('ok-sol') ?> Wikiye dön</a></p>
</div>
<?php admin_alt();
