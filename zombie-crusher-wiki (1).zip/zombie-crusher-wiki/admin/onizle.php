<?php
// Markdown önizlemesi (düzenleme sayfasındaki "Önizle" düğmesi için)
require __DIR__ . '/_baslat.php';
if (!yonetici() || $_SERVER['REQUEST_METHOD'] !== 'POST') { http_response_code(403); exit; }
csrf_dogrula();
$html = md((string)($_POST['metin'] ?? ''));
echo $html !== '' ? $html : '<p><em>Boş</em></p>';
