<?php
require __DIR__ . '/_baslat.php';
giris_gerekli();

$t = (string)($_GET['t'] ?? '');
$tablolar = tablolar();
if (!isset($tablolar[$t])) { bildirim('Böyle bir bölüm yok.', 'hata'); yonlendir('index.php'); }
$tanim = $tablolar[$t];
$adAlani = $tanim['ad'];
$q = trim((string)($_GET['q'] ?? ''));

$gorselVar = false;
foreach ($tanim['gruplar'] as $alanlar) if (isset($alanlar['gorsel'])) $gorselVar = true;

$sql = 'SELECT * FROM `' . $t . '`';
$p = [];
if ($q !== '') {
    $sql .= ' WHERE `' . $adAlani . '` LIKE ?';
    $p[] = '%' . str_replace(['\\', '%', '_'], ['\\\\', '\\%', '\\_'], $q) . '%';
}
$sql .= ' ORDER BY sira, id';
$kayitlar = tumu($sql, $p);

function hucre($v, string $alan): string
{
    if ($alan === 'fiyat') return (int)$v > 0 ? para($v) : 'Bedava';
    if (is_numeric($v) && !preg_match('/^0\d/', (string)$v)) return sayi($v);
    return e(kisalt((string)$v, 70));
}

admin_ust($tanim['baslik'], $t);
?>
<div class="admin-bas">
  <div><span class="ust-yazi">İçerik</span><h1><?= e($tanim['baslik']) ?></h1></div>
  <div class="admin-bas-sag">
    <form method="get" class="admin-ara" role="search">
      <input type="hidden" name="t" value="<?= e($t) ?>">
      <?= ikon('ara') ?><input class="girdi" type="search" name="q" value="<?= e($q) ?>" placeholder="Ada göre ara…" aria-label="Ara">
    </form>
    <a class="dugme" href="duzenle.php?t=<?= e($t) ?>"><?= ikon('arti') ?>Yeni <?= e($tanim['tekil']) ?></a>
  </div>
</div>

<?php if (!$kayitlar): ?>
  <div class="bos-durum"><?= ikon($tanim['ikon']) ?><p><?= $q !== '' ? 'Aramaya uyan kayıt yok.' : 'Henüz kayıt yok.' ?></p></div>
<?php else: ?>
<div class="tablo-kap">
  <table class="tablo admin-tablo">
    <thead>
      <tr>
        <?php if ($gorselVar): ?><th style="width:90px">Görsel</th><?php endif; ?>
        <?php foreach ($tanim['liste'] as $alan => $etiket): ?><th<?= in_array($alan, ['can', 'hasar', 'hiz', 'ilk_dalga', 'fiyat', 'atis_hizi', 'sarjor', 'alan', 'sure', 'zorluk', 'can_carpani', 'hasar_carpani', 'hiz_carpani', 'para_carpani'], true) ? ' class="s"' : '' ?>><?= e($etiket) ?></th><?php endforeach; ?>
        <th class="s">Sıra</th>
        <th class="s">İşlem</th>
      </tr>
    </thead>
    <tbody>
      <?php foreach ($kayitlar as $r): ?>
        <tr>
          <?php if ($gorselVar): ?><td><span class="admin-kucuk"><?= gorsel($r['gorsel'] ?? '', '') ?: ikon('resim') ?></span></td><?php endif; ?>
          <?php $ilk = true; foreach ($tanim['liste'] as $alan => $etiket): $sayisal = in_array($alan, ['can', 'hasar', 'hiz', 'ilk_dalga', 'fiyat', 'atis_hizi', 'sarjor', 'alan', 'sure', 'zorluk', 'can_carpani', 'hasar_carpani', 'hiz_carpani', 'para_carpani'], true); ?>
            <td<?= $sayisal ? ' class="s"' : '' ?>><?php if ($ilk): ?><a href="duzenle.php?t=<?= e($t) ?>&amp;id=<?= (int)$r['id'] ?>"><b><?= e($r[$alan]) ?></b></a><?php else: ?><?= hucre($r[$alan], $alan) ?><?php endif; ?></td>
          <?php $ilk = false; endforeach; ?>
          <td class="s"><?= (int)$r['sira'] ?></td>
          <td class="s">
            <div class="islemler">
              <a class="ikon-dugme" href="duzenle.php?t=<?= e($t) ?>&amp;id=<?= (int)$r['id'] ?>" title="Düzenle"><?= ikon('duzenle') ?><span class="gizli">Düzenle</span></a>
              <?php if (!empty($tanim['onizleme'])): ?><a class="ikon-dugme" href="../<?= e($tanim['onizleme'] . (isset($r['slug']) ? rawurlencode($r['slug']) : '')) ?>" target="_blank" rel="noopener" title="Sitede gör"><?= ikon('goz') ?><span class="gizli">Sitede gör</span></a><?php endif; ?>
              <form method="post" action="sil.php" data-onay="“<?= e($r[$adAlani]) ?>” silinsin mi? Bu işlem geri alınamaz.">
                <?= csrf_alani() ?><input type="hidden" name="t" value="<?= e($t) ?>"><input type="hidden" name="id" value="<?= (int)$r['id'] ?>">
                <button class="ikon-dugme tehlike" type="submit" title="Sil"><?= ikon('sil') ?><span class="gizli">Sil</span></button>
              </form>
            </div>
          </td>
        </tr>
      <?php endforeach; ?>
    </tbody>
  </table>
</div>
<p class="hesap-not" style="margin-top:12px"><?= count($kayitlar) ?> kayıt. Sitede “Sıra” değeri küçük olan önce gösterilir.</p>
<?php endif; ?>
<?php admin_alt();
