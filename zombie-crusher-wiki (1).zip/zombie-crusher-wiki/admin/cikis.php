<?php
require __DIR__ . '/_baslat.php';

if ($_SERVER['REQUEST_METHOD'] !== 'POST') yonlendir('index.php');
csrf_dogrula();

// Oturum verisini temizle ve kimliği yenile (çıkış bildirimi yeni oturumda gösterilir)
$_SESSION = [];
session_regenerate_id(true);
bildirim('Çıkış yapıldı.');
yonlendir('giris.php');
