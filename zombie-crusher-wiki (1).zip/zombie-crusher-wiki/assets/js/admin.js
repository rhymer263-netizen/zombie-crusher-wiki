/* Zombie Crusher Wiki — yönetim paneli küçük yardımcıları */
(function () {
  'use strict';
  var $$ = function (s, k) { return Array.prototype.slice.call((k || document).querySelectorAll(s)); };

  // Silme gibi geri alınamaz işlemlerden önce onay iste
  $$('form[data-onay]').forEach(function (f) {
    f.addEventListener('submit', function (e) {
      if (!window.confirm(f.getAttribute('data-onay'))) e.preventDefault();
    });
  });

  // Kaydedilmemiş değişiklik uyarısı
  $$('form[data-degisiklik-uyar]').forEach(function (f) {
    var degisti = false;
    f.addEventListener('input', function () { degisti = true; });
    f.addEventListener('change', function () { degisti = true; });
    f.addEventListener('submit', function () { degisti = false; });
    window.addEventListener('beforeunload', function (e) {
      if (degisti) { e.preventDefault(); e.returnValue = ''; }
    });
  });

  // Markdown önizleme
  var csrf = document.querySelector('input[name="csrf"]');
  $$('[data-onizle]').forEach(function (b) {
    b.setAttribute('aria-pressed', 'false');
    b.addEventListener('click', function () {
      var id = b.getAttribute('data-onizle');
      var alan = document.getElementById(id);
      var kutu = document.querySelector('[data-onizleme-kutu="' + id + '"]');
      if (!alan || !kutu) return;
      if (b.getAttribute('aria-pressed') === 'true') {
        b.setAttribute('aria-pressed', 'false'); kutu.hidden = true; alan.hidden = false; return;
      }
      var veri = new FormData();
      veri.append('metin', alan.value);
      if (csrf) veri.append('csrf', csrf.value);
      kutu.textContent = 'Yükleniyor…';
      kutu.hidden = false; alan.hidden = true; b.setAttribute('aria-pressed', 'true');
      fetch('onizle.php', { method: 'POST', body: veri, credentials: 'same-origin' })
        .then(function (r) { if (!r.ok) throw new Error(r.status); return r.text(); })
        .then(function (h) { kutu.innerHTML = h; })
        .catch(function () { kutu.textContent = 'Önizleme yüklenemedi.'; });
    });
  });

  // Seçilen görseli kaydetmeden önce göster
  $$('[data-gorsel-dosya]').forEach(function (inp) {
    inp.addEventListener('change', function () {
      var kutu = inp.closest('.gorsel-alani').querySelector('[data-gorsel-onizleme]');
      if (!kutu || !inp.files || !inp.files[0]) return;
      var img = document.createElement('img');
      img.alt = '';
      img.src = URL.createObjectURL(inp.files[0]);
      kutu.innerHTML = '';
      kutu.appendChild(img);
    });
  });

  // Renk seçicinin yanındaki kodu güncelle
  $$('.renk-alani input[type=color]').forEach(function (c) {
    var kod = c.parentNode.querySelector('code');
    c.addEventListener('input', function () { if (kod) kod.textContent = c.value; });
  });
})();
