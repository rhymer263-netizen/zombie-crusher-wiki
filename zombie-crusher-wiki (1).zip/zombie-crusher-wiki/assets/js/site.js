/* Zombie Crusher Wiki — sayfa etkileşimleri (kütüphanesiz) */
(function () {
  'use strict';

  var $ = function (s, k) { return (k || document).querySelector(s); };
  var $$ = function (s, k) { return Array.prototype.slice.call((k || document).querySelectorAll(s)); };
  var sayi = function (x, d) {
    return Number(x).toLocaleString('tr-TR', { maximumFractionDigits: d || 0, minimumFractionDigits: 0 });
  };
  var para = function (x) { return '$' + sayi(Math.round(x)); };
  var veri = function (id) {
    var el = document.getElementById(id);
    if (!el) return null;
    try { return JSON.parse(el.textContent); } catch (e) { return null; }
  };
  var trKucuk = function (s) { return String(s).replace(/I/g, 'ı').replace(/İ/g, 'i').toLocaleLowerCase('tr-TR'); };

  /* ---------------------------------------------------------------- menü */
  var menuDugme = $('.menu-dugme');
  var nav = $('#nav');
  if (menuDugme && nav) {
    menuDugme.addEventListener('click', function () {
      var acik = nav.classList.toggle('acik');
      menuDugme.setAttribute('aria-expanded', acik ? 'true' : 'false');
      menuDugme.setAttribute('aria-label', acik ? 'Menüyü kapat' : 'Menüyü aç');
      document.body.style.overflow = acik ? 'hidden' : '';
    });
    document.addEventListener('keydown', function (e) {
      if (e.key === 'Escape' && nav.classList.contains('acik')) menuDugme.click();
    });
  }

  /* ---------------------------------------------------------------- ipucu kutusu */
  var kutu = document.getElementById('ipucu-kutu');
  function ipucuGoster(el, x, y) {
    if (!kutu) return;
    var p = String(el.getAttribute('data-ipucu') || '').split('|');
    kutu.innerHTML = '';
    var b = document.createElement('b'); b.textContent = p[0]; kutu.appendChild(b);
    if (p[1]) kutu.appendChild(document.createTextNode(p.slice(1).join(' ')));
    kutu.hidden = false;
    var r = kutu.getBoundingClientRect();
    var left = Math.min(window.innerWidth - r.width - 8, Math.max(8, x + 14));
    var top = y + 18 + r.height > window.innerHeight ? y - r.height - 12 : y + 18;
    kutu.style.left = left + 'px';
    kutu.style.top = top + 'px';
  }
  function ipucuGizle() { if (kutu) kutu.hidden = true; }
  document.addEventListener('mousemove', function (e) {
    var el = e.target.closest ? e.target.closest('[data-ipucu]') : null;
    if (el) ipucuGoster(el, e.clientX, e.clientY); else ipucuGizle();
  });
  document.addEventListener('focusin', function (e) {
    var el = e.target.closest ? e.target.closest('[data-ipucu]') : null;
    if (el) { var r = el.getBoundingClientRect(); ipucuGoster(el, r.left, r.bottom - 10); }
  });
  document.addEventListener('focusout', ipucuGizle);
  document.addEventListener('scroll', ipucuGizle, { passive: true });

  /* ---------------------------------------------------------------- kaydırıcı dolgusu */
  function dolgu(r) {
    var min = +r.min || 0, max = +r.max || 100;
    r.style.setProperty('--p', ((r.value - min) / (max - min) * 100) + '%');
  }
  $$('input[type=range]').forEach(function (r) { dolgu(r); r.addEventListener('input', function () { dolgu(r); }); });

  /* ---------------------------------------------------------------- oyun formülleri */
  var F = veri('zc-formul');
  function carpanlar(dalga, zIdx, gece) {
    var z = (F.zorluklar[zIdx] || F.zorluklar[0]);
    var dalgaCan = (1 + F.dalgaCan * (dalga - 1)) * (gece ? F.geceCan : 1);
    return {
      can: dalgaCan * z.can,
      hasar: (1 + (dalgaCan - 1) / F.hasarBolen) * F.hasarCarpan * z.hasar,
      hiz: Math.min(1 + F.dalgaHiz * (dalga - 1), F.hizTavan) * z.hiz * (gece ? F.geceHiz : 1),
      para: z.para * (gece ? F.gecePara : 1),
      zorluk: z
    };
  }
  function hesapDurumu(kok) {
    var d = $('[data-dalga]', kok), z = $('[data-zorluk]', kok), g = $('[data-gece]', kok);
    return { dalga: d ? +d.value : 1, zorluk: z ? +z.value : 0, gece: g ? g.checked : false };
  }
  function hesapBagla(kok, fn) {
    if (!kok) return;
    var d = $('[data-dalga]', kok), cikti = $('[data-dalga-cikti]', kok);
    var calis = function () {
      if (d && cikti) cikti.innerHTML = '<small>DALGA</small>' + d.value;
      fn(hesapDurumu(kok));
    };
    $$('input, select', kok).forEach(function (el) { el.addEventListener('input', calis); el.addEventListener('change', calis); });
    calis();
  }

  /* ---------------------------------------------------------------- liste filtreleri (ortak) */
  function listeFiltresi(sayfa, ayar) {
    var liste = $('[data-liste]', sayfa);
    if (!liste) return;
    var ogeler = $$(ayar.oge, liste);
    var filtre = 'hepsi', aranan = '';
    var bos = $('[data-bos]', sayfa);
    function uygula() {
      var gorunen = 0;
      ogeler.forEach(function (el) {
        var uygun = (filtre === 'hepsi' || el.getAttribute('data-kategori') === filtre) &&
          (aranan === '' || (el.getAttribute('data-ara') || el.getAttribute('data-ad') || '').indexOf(aranan) !== -1);
        el.hidden = !uygun;
        if (uygun) gorunen++;
      });
      if (ayar.ekstra) ayar.ekstra(filtre, aranan);
      if (bos) bos.hidden = gorunen > 0;
    }
    $$('[data-filtre]', sayfa).forEach(function (b) {
      b.addEventListener('click', function () {
        filtre = b.getAttribute('data-filtre');
        $$('[data-filtre]', sayfa).forEach(function (x) { x.setAttribute('aria-pressed', x === b ? 'true' : 'false'); });
        uygula();
      });
    });
    var ara = $('[data-ara]', sayfa.querySelector('.arac') || sayfa);
    if (ara && ara.tagName === 'INPUT') ara.addEventListener('input', function () { aranan = trKucuk(ara.value.trim()); uygula(); });
    var sirala = $('[data-sirala]', sayfa);
    if (sirala) sirala.addEventListener('change', function () {
      var k = sirala.value;
      var sirali = ogeler.slice().sort(function (a, b) {
        if (k === 'ad') return a.getAttribute('data-ad').localeCompare(b.getAttribute('data-ad'), 'tr');
        if (k === 'sira' || k === 'ilk' || (ayar.artan && ayar.artan.indexOf(k) !== -1)) return (+a.getAttribute('data-' + k) - +b.getAttribute('data-' + k)) || (+a.getAttribute('data-sira') - +b.getAttribute('data-sira'));
        return +b.getAttribute('data-' + k) - +a.getAttribute('data-' + k);
      });
      sirali.forEach(function (el) { liste.appendChild(el); });
    });
  }

  /* ---------------------------------------------------------------- yaratıklar */
  var ySayfa = $('[data-sayfa="yaratiklar"]');
  if (ySayfa && F) {
    listeFiltresi(ySayfa, { oge: '.dosya' });
    var kartlar = $$('.dosya', ySayfa);
    hesapBagla($('[data-hesap]', ySayfa), function (h) {
      var c = carpanlar(h.dalga, h.zorluk, h.gece);
      kartlar.forEach(function (k) {
        if (k.hasAttribute('data-sabit')) return;
        var yaz = function (ad, v) { var el = k.querySelector('[data-deger="' + ad + '"]'); if (el) el.textContent = v; };
        yaz('can', sayi(+k.getAttribute('data-can') * c.can));
        yaz('hasar', sayi(+k.getAttribute('data-hasar') * c.hasar, 1));
        yaz('hiz', sayi(+k.getAttribute('data-hiz') * c.hiz, 2));
        yaz('odul', para(+k.getAttribute('data-odul') * c.para));
      });
    });
  }

  /* ---------------------------------------------------------------- yaratık ayrıntı */
  var yDetay = $('[data-sayfa="yaratik"]');
  if (yDetay && F && !yDetay.hasAttribute('data-sabit')) {
    var taban = { can: +yDetay.dataset.can, hasar: +yDetay.dataset.hasar, hiz: +yDetay.dataset.hiz, odul: +yDetay.dataset.odul };
    var silahlar = veri('zc-silahlar') || [];
    var km = $('[data-kilometre] tbody', yDetay), atis = $('[data-atis-tablo] tbody', yDetay);
    var ilk = +yDetay.dataset.ilk || 1;
    hesapBagla($('[data-hesap]', yDetay), function (h) {
      var c = carpanlar(h.dalga, h.zorluk, h.gece);
      var yaz = function (ad, v) { $$('[data-deger="' + ad + '"]', yDetay).forEach(function (el) { el.textContent = v; }); };
      var can = taban.can * c.can;
      yaz('can', sayi(can)); yaz('hasar', sayi(taban.hasar * c.hasar, 1)); yaz('hiz', sayi(taban.hiz * c.hiz, 2)); yaz('odul', para(taban.odul * c.para));

      if (km) {
        var dalgalar = yDetay.hasAttribute('data-boss')
          ? [ilk, ilk + 30, ilk + 60, ilk + 90]   // bosslar her 30 dalgada bir döner
          : [1, 5, 10, 15, 20, 30, 40, 50, 60].filter(function (d) { return d >= ilk; });
        if (dalgalar.indexOf(ilk) === -1) dalgalar.unshift(ilk);
        if (dalgalar.indexOf(h.dalga) === -1) { dalgalar.push(h.dalga); dalgalar.sort(function (a, b) { return a - b; }); }
        km.innerHTML = dalgalar.map(function (d) {
          var cc = carpanlar(d, h.zorluk, h.gece);
          return '<tr' + (d === h.dalga ? ' class="vurgu"' : '') + '><td>' + d + '. dalga</td><td class="s">' + sayi(taban.can * cc.can) + '</td><td class="s">' + sayi(taban.hasar * cc.hasar, 1) +
            '</td><td class="s">' + sayi(taban.hiz * cc.hiz, 2) + '</td><td class="s">' + para(taban.odul * cc.para) + '</td></tr>';
        }).join('');
      }
      if (atis) {
        atis.innerHTML = silahlar.map(function (s) {
          var vurus = (+s.hasar) * Math.max(1, +s.sacma) + (+s.alan_hasari || 0);
          var kafa = (+s.hasar) * Math.max(1, +s.sacma) * F.kafa + (+s.alan_hasari || 0);
          if (vurus <= 0) return '';
          var govde = Math.ceil(can / vurus), kafaA = Math.ceil(can / kafa);
          var sure = (govde - 1) / Math.max(0.01, +s.atis_hizi);
          if (+s.sarjor > 0 && +s.doldurma > 0) sure += Math.floor((govde - 1) / +s.sarjor) * +s.doldurma;
          return '<tr><td><a href="silah.php?s=' + encodeURIComponent(s.slug) + '">' + s.ad.replace(/[<>&"]/g, '') + '</a></td><td class="s">' + sayi(vurus, 1) + '</td><td class="s">' + govde +
            '</td><td class="s">' + kafaA + '</td><td class="s">' + sayi(sure, 1) + ' sn</td></tr>';
        }).join('');
      }
    });
  }

  /* ---------------------------------------------------------------- silahlar */
  var sSayfa = $('[data-sayfa="silahlar"]');
  if (sSayfa) {
    var tabloKap = $('[data-tablo-gorunum]', sSayfa);
    var izgara = $('[data-liste]', sSayfa);
    listeFiltresi(sSayfa, {
      oge: '.cephane',
      artan: ['fiyat'],
      ekstra: function (filtre) {
        $$('tbody tr', tabloKap).forEach(function (tr) { tr.hidden = !(filtre === 'hepsi' || tr.getAttribute('data-kategori') === filtre); });
      }
    });
    $$('[data-goruntu]', sSayfa).forEach(function (b) {
      b.addEventListener('click', function () {
        var tablo = b.getAttribute('data-goruntu') === 'tablo';
        $$('[data-goruntu]', sSayfa).forEach(function (x) { x.setAttribute('aria-pressed', x === b ? 'true' : 'false'); });
        izgara.hidden = tablo; tabloKap.hidden = !tablo;
        try { localStorage.setItem('zc-silah-gorunum', tablo ? 'tablo' : 'kart'); } catch (e) {}
      });
    });
    try { if (localStorage.getItem('zc-silah-gorunum') === 'tablo') { var tb = $('[data-goruntu="tablo"]', sSayfa); if (tb) tb.click(); } } catch (e) {}
  }

  // sıralanabilir tablolar
  $$('table[data-siralanabilir]').forEach(function (t) {
    var govde = t.tBodies[0];
    $$('th button[data-anahtar]', t).forEach(function (b) {
      b.addEventListener('click', function () {
        var th = b.parentNode, k = b.getAttribute('data-anahtar'), sayisal = b.hasAttribute('data-sayi');
        var yon = th.getAttribute('aria-sort') === 'descending' ? 'ascending' : 'descending';
        if (!sayisal && th.getAttribute('aria-sort') === 'none') yon = 'ascending';
        $$('th', t).forEach(function (x) { if (x.hasAttribute('aria-sort')) x.setAttribute('aria-sort', 'none'); });
        th.setAttribute('aria-sort', yon);
        var satirlar = $$('tr', govde).sort(function (a, c) {
          var x = a.getAttribute('data-' + k), y = c.getAttribute('data-' + k);
          var r = sayisal ? (+x - +y) : String(x).localeCompare(String(y), 'tr');
          return yon === 'ascending' ? r : -r;
        });
        satirlar.forEach(function (s) { govde.appendChild(s); });
      });
    });
  });

  /* ---------------------------------------------------------------- silah ayrıntı */
  var wDetay = $('[data-sayfa="silah"]');
  if (wDetay && F) {
    var d = wDetay.dataset;
    var yaratiklar = veri('zc-yaratiklar') || [];
    var hk = $('[data-hesap]', wDetay);
    var guc = $('[data-guc]', wDetay), gucCikti = $('[data-guc-cikti]', wDetay);
    var ttk = $('[data-ttk] tbody', wDetay);
    hesapBagla(hk, function (h) {
      var seviye = guc ? +guc.value : 0;
      if (gucCikti) gucCikti.innerHTML = '<small>MERMİ GÜCÜ</small>' + seviye;
      var carp = 1 + 0.12 * seviye;
      var tek = (+d.hasar) * carp, sacma = Math.max(1, +d.sacma), alan = (+d.alan || 0) * carp;
      var vurus = tek * sacma + alan, kafa = tek * sacma * F.kafa + alan;
      var gh = $('[data-guclu-hasar]', wDetay), gd = $('[data-guclu-dps]', wDetay);
      if (gh) gh.textContent = (sacma > 1 ? sacma + '×' : '') + sayi(tek, 1) + (alan > 0 ? ' + ' + sayi(alan, 0) : '');
      if (gd) gd.textContent = sayi(tek * sacma * (+d.atis), 0);
      var c = carpanlar(h.dalga, h.zorluk, false);
      if (ttk) ttk.innerHTML = yaratiklar.map(function (y) {
        var can = (+y.can) * c.can;
        var govde = Math.ceil(can / vurus), kafaA = Math.ceil(can / kafa);
        var sure = (govde - 1) / Math.max(0.01, +d.atis);
        if (+d.sarjor > 0 && +d.doldurma > 0) sure += Math.floor((govde - 1) / +d.sarjor) * +d.doldurma;
        var etiket = y.kategori === 'boss' ? ' <span class="cip" style="padding:2px 5px;font-size:10px">BOSS</span>' : '';
        return '<tr><td><a href="yaratik.php?s=' + encodeURIComponent(y.slug) + '">' + String(y.ad).replace(/[<>&"]/g, '') + '</a>' + etiket + '</td><td class="s">' + govde + '</td><td class="s">' + kafaA + '</td><td class="s">' + sayi(sure, 1) + ' sn</td></tr>';
      }).join('');
    });
  }

  /* ---------------------------------------------------------------- görevler */
  var gSayfa = $('[data-sayfa="gorevler"]');
  if (gSayfa && F) {
    var emirler = $$('.emir', gSayfa);
    var uyari = $('[data-boss-uyari]', gSayfa);
    var bes = function (x) { return Math.round(x / 5) * 5; };
    hesapBagla($('[data-hesap]', gSayfa), function (h) {
      var z = F.zorluklar[h.zorluk] || F.zorluklar[0];
      var boss = h.dalga % 5 === 0;
      if (uyari) uyari.hidden = !boss;
      var ham = (F.gorevTaban + h.dalga * F.gorevDalga) * z.para;
      emirler.forEach(function (e) {
        var ds = e.dataset;
        var n = (+ds.taban) + ((+ds.bolen) > 0 ? Math.floor(h.dalga / (+ds.bolen)) : 0) + Math.round((+ds.carpan) * h.dalga);
        if ((+ds.tavan) > 0) n = Math.min(n, +ds.tavan);
        var hedef = e.querySelector('[data-hedef]'); if (hedef) hedef.textContent = n;
        var p = e.querySelector('[data-odul-para]'); if (p) p.textContent = para(bes(ham));
        var a = e.querySelector('[data-odul-anahtar]'); if (a) a.textContent = para(bes(ham * F.gorevAnahtarPara));
        e.style.opacity = boss ? '.55' : '';
      });
    });
  }

  /* ---------------------------------------------------------------- kasa simülatörü */
  var kSayfa = $('[data-sayfa="skinler"]');
  var K = veri('zc-kasa');
  if (kSayfa && K && K.skinler.length) {
    var serit = $('[data-serit]', kSayfa), dugme = $('[data-kasa-ac]', kSayfa), sonuc = $('[data-sonuc]', kSayfa), kolSay = $('[data-koleksiyon]', kSayfa);
    var nadirSinif = { 'Yaygın': 'n-yaygin', 'Destansı': 'n-destansi', 'Efsanevi': 'n-efsanevi' };
    var koleksiyon = [];
    try { koleksiyon = JSON.parse(localStorage.getItem('zc-koleksiyon') || '[]'); } catch (e) { koleksiyon = []; }
    var kolYaz = function () { if (kolSay) kolSay.textContent = koleksiyon.length; };
    kolYaz();

    var cek = function () {
      var r = Math.random() * 100, s = K.sans;
      var nad = r < s['Efsanevi'] ? 'Efsanevi' : (r < s['Efsanevi'] + s['Destansı'] ? 'Destansı' : 'Yaygın');
      var havuz = K.skinler.filter(function (k) { return k.nadirlik === nad; });
      if (!havuz.length) havuz = K.skinler;
      var skin = havuz[Math.floor(Math.random() * havuz.length)];
      var esya;
      if (skin.bicak) esya = K.bicak;
      else { var i = Math.floor(Math.random() * (K.esyalar.length + 1)); esya = i === K.esyalar.length ? K.bicak : K.esyalar[i]; }
      return { skin: skin, esya: esya };
    };
    var kart = function (c) {
      var el = document.createElement('div');
      el.className = 'kasa-kart ' + (nadirSinif[c.skin.nadirlik] || '');
      if (c.skin.gorsel) { var im = document.createElement('img'); im.src = c.skin.gorsel; im.alt = ''; el.appendChild(im); }
      var b = document.createElement('b'); b.textContent = c.skin.ad; el.appendChild(b);
      var sm = document.createElement('small'); sm.textContent = c.esya; el.appendChild(sm);
      return el;
    };
    var doldur = function () {
      serit.innerHTML = '';
      serit.style.transition = 'none';
      serit.style.transform = 'translateX(0)';
      for (var i = 0; i < 12; i++) serit.appendChild(kart(cek()));
    };
    doldur();
    var donuyor = false;
    dugme.addEventListener('click', function () {
      if (donuyor) return;
      donuyor = true; dugme.disabled = true;
      var kazanan = cek(), adet = 58, hedef = 50;
      serit.style.transition = 'none';
      serit.style.transform = 'translateX(0)';
      serit.innerHTML = '';
      for (var i = 0; i < adet; i++) serit.appendChild(kart(i === hedef ? kazanan : cek()));
      var kk = serit.children[hedef];
      var pencere = serit.parentNode.getBoundingClientRect().width;
      var en = kk.offsetWidth, adim = kk.offsetLeft;
      var sapma = (Math.random() - 0.5) * en * 0.7;
      var x = -(adim + en / 2 - pencere / 2 + sapma);
      var hizli = window.matchMedia && window.matchMedia('(prefers-reduced-motion: reduce)').matches;
      void serit.offsetWidth;
      serit.style.transition = hizli ? 'none' : 'transform 5.2s cubic-bezier(.08,.6,.1,1)';
      serit.style.transform = 'translateX(' + x + 'px)';
      var bitti = function () {
        serit.removeEventListener('transitionend', bitti);
        kk.style.outline = '2px solid var(--sun)';
        var anahtar = kazanan.esya + '|' + kazanan.skin.slug;
        var yeni = koleksiyon.indexOf(anahtar) === -1;
        if (yeni) { koleksiyon.push(anahtar); try { localStorage.setItem('zc-koleksiyon', JSON.stringify(koleksiyon)); } catch (e) {} }
        kolYaz();
        sonuc.innerHTML = '';
        var b = document.createElement('b'); b.textContent = kazanan.esya + ' | ' + kazanan.skin.ad;
        sonuc.appendChild(b);
        sonuc.appendChild(document.createTextNode(' — ' + kazanan.skin.nadirlik + ' '));
        var e2 = document.createElement('span'); e2.className = 'yeni';
        e2.textContent = yeni ? 'YENİ!' : 'KOPYA: +' + para(K.kopya[kazanan.skin.nadirlik] || 0);
        if (!yeni) e2.style.color = 'var(--sun)';
        sonuc.appendChild(e2);
        var hedefKart = document.getElementById('skin-' + kazanan.skin.slug);
        $$('.skin.parlak', kSayfa).forEach(function (x) { x.classList.remove('parlak'); });
        if (hedefKart) hedefKart.classList.add('parlak');
        donuyor = false; dugme.disabled = false;
      };
      if (hizli) bitti(); else serit.addEventListener('transitionend', bitti);
    });
  }

  /* ---------------------------------------------------------------- içindekiler vurgusu */
  var tocLinkler = $$('[data-toc]');
  if (tocLinkler.length && 'IntersectionObserver' in window) {
    var harita = {};
    tocLinkler.forEach(function (a) { harita[decodeURIComponent(a.getAttribute('href').slice(1))] = a; });
    var gozlemci = new IntersectionObserver(function (girdiler) {
      girdiler.forEach(function (g) {
        if (g.isIntersecting && harita[g.target.id]) {
          tocLinkler.forEach(function (a) { a.classList.remove('aktif'); });
          harita[g.target.id].classList.add('aktif');
        }
      });
    }, { rootMargin: '-80px 0px -70% 0px' });
    Object.keys(harita).forEach(function (id) { var h = document.getElementById(id); if (h) gozlemci.observe(h); });
  }
})();
